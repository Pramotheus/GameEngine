
#pragma once

//windows headers
#include <windows.h>

//opengl headers
#include <glad/glad.h> 
#include <GLFW/glfw3.h>