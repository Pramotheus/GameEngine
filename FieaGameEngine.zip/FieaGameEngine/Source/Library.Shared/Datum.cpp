#include "pch.h"
#include "RTTI.h"
#include "Datum.h"
#include "Scope.h"

using namespace FieaGameEngine;
using namespace std;

//!Hash map with Datum type and size
/*!
*	Hash map holding type of element and associated size as key value pairs
*	Used for internal memory management and not available to users
*/
namespace FieaGameEngine
{
	HashMap<Datum::DatumType, size_t> mDatumMap = { { Datum::DatumType::Unknown, sizeof(0) }, { Datum::DatumType::Integer, sizeof(int32_t) },
	{ Datum::DatumType::Float, sizeof(float) },	{ Datum::DatumType::Vector, sizeof(glm::vec4) },{ Datum::DatumType::Matrix, sizeof(glm::mat4x4) },
	{ Datum::DatumType::Table, sizeof(Scope) },	{ Datum::DatumType::String, sizeof(std::string) },{ Datum::DatumType::Pointer, sizeof(RTTIPointer) } };
}

Datum::Datum() : mType(DatumType::Unknown), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.voidPointer = nullptr;
}

FieaGameEngine::Datum::Datum(const Datum & copyDatum)
	: mType(DatumType::Unknown), mIsInternal(true), mSize(0), mCapacity(0)
{
	mData.voidPointer = nullptr;
	operator=(copyDatum);
}

FieaGameEngine::Datum::Datum(Datum && moveDatum)
	: mType(moveDatum.mType), mIsInternal(moveDatum.mIsInternal), mSize(moveDatum.mSize), mCapacity(moveDatum.mSize), mData(std::move(moveDatum.mData))
{
	moveDatum.mType = DatumType::Unknown;
	moveDatum.mData.voidPointer = nullptr;
	moveDatum.mSize = 0;
	moveDatum.mCapacity = 0;
}

FieaGameEngine::Datum::Datum(int32_t value)
	: mType(DatumType::Integer), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.integerPointer = nullptr;
	PushBack(value);
}

FieaGameEngine::Datum::Datum(float value)
	: mType(DatumType::Float), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.floatPointer = nullptr;
	PushBack(value);
}

FieaGameEngine::Datum::Datum(const glm::vec4 & value)
	: mType(DatumType::Vector), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.vectorPointer = nullptr;
	PushBack(value);
}

FieaGameEngine::Datum::Datum(const glm::mat4x4 & value)
	: mType(DatumType::Matrix), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.matrixPointer = nullptr;
	PushBack(value);
}

FieaGameEngine::Datum::Datum(Scope *& value)
	: mType(DatumType::Table), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.scopePointer = nullptr;
	PushBack(value);
}

FieaGameEngine::Datum::Datum(const std::string & value)
	: mType(DatumType::String), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.stringPointer = nullptr;
	PushBack(value);
}

FieaGameEngine::Datum::Datum(RTTIPointer & value)
	: mType(DatumType::Pointer), mSize(0), mCapacity(0), mIsInternal(true)
{
	mData.rttiPointer = nullptr;
	PushBack(value);
}

Datum::DatumType FieaGameEngine::Datum::Type() const
{
	return mType;
}

void FieaGameEngine::Datum::SetType(DatumType type)
{
	if ((mType != DatumType::Unknown) && (mType != type || type == DatumType::EndValue))
	{
		throw::std::exception("Can not reset datum type");
	}

	mType = type;
}

uint32_t FieaGameEngine::Datum::Size() const
{
	return mSize;
}

void FieaGameEngine::Datum::SetSize(uint32_t newSize)
{
	if (mIsInternal)
	{
		if (newSize < mSize)
		{
			if (mType == DatumType::String)
			{
				for (uint32_t i = newSize; i < mSize; i++)
					mData.stringPointer[i].~string();
			}
		}
		Reserve(newSize);

		if (newSize > mSize)
		{
			if (mType == DatumType::String)
			{
				for (uint32_t i = mSize; i < newSize; i++)
					new(mData.stringPointer + i) string();
			}
		}
		mSize = newSize;
	}
}

void FieaGameEngine::Datum::Reserve(uint32_t newCapacity)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if(mType == DatumType::Unknown)
		throw::std::exception("Datum needs type to be set");

	mCapacity = newCapacity;
	mData.voidPointer = static_cast<void*>(realloc(mData.voidPointer, (mCapacity * mDatumMap.At(mType))));
}

void FieaGameEngine::Datum::Clear()
{
	if (mIsInternal || mSize != 0)
	{
		if (mType == DatumType::String)
		{
			for (uint32_t i = 0; i < mSize; i++)
				mData.stringPointer[i].~string();
		}
		mSize = 0;
	}
}

void FieaGameEngine::Datum::SetStorage(int32_t * inputArray, uint32_t numberOfElements)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Integer;
	}
	else if (mType != DatumType::Integer)
	{
		throw::exception("Invalid data type");
	}

	if (mSize != 0 && mIsInternal)
	{
		Clear();
		free(mData.integerPointer);
		mData.integerPointer = nullptr;
	}

	mIsInternal = false;
	mData.integerPointer = inputArray;
	mSize = numberOfElements;
	mCapacity = mSize;
}

void FieaGameEngine::Datum::SetStorage(float * inputArray, uint32_t numberOfElements)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Float;
	}
	else if (mType != DatumType::Float)
	{
		throw::exception("Invalid data type");
	}
	if (mSize != 0 && mIsInternal)
	{
		Clear();
		free(mData.floatPointer);
		mData.floatPointer = nullptr;
	}

	mIsInternal = false;
	mData.floatPointer = inputArray;
	mSize = numberOfElements;
	mCapacity = mSize;
}

void FieaGameEngine::Datum::SetStorage(glm::vec4 * inputArray, uint32_t numberOfElements)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Vector;
	}
	else if (mType != DatumType::Vector)
	{
		throw::exception("Invalid data type");
	}
	if (mSize != 0 && mIsInternal)
	{
		Clear();
		free(mData.vectorPointer);
		mData.vectorPointer = nullptr;
	}

	mIsInternal = false;
	mData.vectorPointer = inputArray;
	mSize = numberOfElements;
	mCapacity = mSize;
}

void FieaGameEngine::Datum::SetStorage(glm::mat4x4 * inputArray, uint32_t numberOfElements)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Matrix;
	}
	else if (mType != DatumType::Matrix)
	{
		throw::exception("Invalid data type");
	}
	if (mSize != 0 && mIsInternal)
	{
		Clear();
		free(mData.matrixPointer);
		mData.matrixPointer = nullptr;
	}

	mIsInternal = false;
	mData.matrixPointer = inputArray;
	mSize = numberOfElements;
	mCapacity = mSize;
}

void FieaGameEngine::Datum::SetStorage(std::string * inputArray, uint32_t numberOfElements)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::String;
	}
	else if (mType != DatumType::String)
	{
		throw::exception("Invalid data type");
	}
	if (mSize != 0 && mIsInternal)
	{
		Clear();
		free(mData.stringPointer);
		mData.stringPointer = nullptr;
	}

	mIsInternal = false;
	mData.stringPointer = inputArray;
	mSize = numberOfElements;
	mCapacity = mSize;
}

void FieaGameEngine::Datum::SetStorage(RTTIPointer * inputArray, uint32_t numberOfElements)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Pointer;
	}
	else if (mType != DatumType::Pointer)
	{
		throw::exception("Invalid data type");
	}
	if (mSize != 0 && mIsInternal)
	{
		Clear();
		free(mData.rttiPointer);
		mData.rttiPointer = nullptr;
	}

	mIsInternal = false;
	mData.rttiPointer = inputArray;
	mSize = numberOfElements;
	mCapacity = mSize;
}

void FieaGameEngine::Datum::PopBack()
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mSize > 0)
	{
		--mSize;

		if (mType == DatumType::String)
		{
			mData.stringPointer[mSize].~string();
		}
		if (mType == DatumType::Table)
		{
			delete mData.scopePointer[mSize];
		}
	}
}

void FieaGameEngine::Datum::PushBack(int32_t value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Integer;
	}
	else if (mType != DatumType::Integer)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) +1);
	}

	mData.integerPointer[mSize] = value;
	++mSize;
}

void FieaGameEngine::Datum::PushBack(float value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Float;
	}
	else if (mType != DatumType::Float)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) +1);
	}

	mData.floatPointer[mSize] = value;
	++mSize;
}

void FieaGameEngine::Datum::PushBack(const glm::vec4 & value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Vector;
	}
	else if (mType != DatumType::Vector)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) +1);
	}

	new(mData.vectorPointer + mSize) glm::vec4(value);
	++mSize;
}

void FieaGameEngine::Datum::PushBack(const glm::mat4x4 & value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Matrix;
	}
	else if (mType != DatumType::Matrix)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) +1);
	}

	new(mData.matrixPointer + mSize) glm::mat4x4(value);
	++mSize;
}

void FieaGameEngine::Datum::PushBack(Scope* const & value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Table;
	}
	else if (mType != DatumType::Table)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) + 1);
	}

	mData.scopePointer[mSize] = value;
	++mSize;
}

void FieaGameEngine::Datum::PushBack(const std::string & value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::String;
	}
	else if (mType != DatumType::String)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) +1);
	}

	new(mData.stringPointer + mSize) string(value);
	++mSize;
}

void FieaGameEngine::Datum::PushBack(RTTIPointer & value)
{
	if (!mIsInternal)
		throw::std::exception("Can not modify external Datum");

	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Pointer;
	}
	else if (mType != DatumType::Pointer)
	{
		throw::exception("Invalid data type");
	}

	if (mCapacity == mSize)
	{
		Reserve((mCapacity * 2) +1);
	}

	mData.rttiPointer[mSize] = value;
	++mSize;
}

void FieaGameEngine::Datum::Set(int32_t value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (index >= mSize)
		throw::exception("Invalid index");

	if (mType != DatumType::Integer)
	{
		throw::exception("Invalid data type");
	}

	mData.integerPointer[index] = value;
}

void FieaGameEngine::Datum::Set(float value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (index >= mSize)
		throw::exception("Invalid index");

	if (mType != DatumType::Float)
	{
		throw::exception("Invalid data type");
	}

	mData.floatPointer[index] = value;
}

void FieaGameEngine::Datum::Set(const glm::vec4 & value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (index >= mSize)
		throw::exception("Invalid index");

	if (mType != DatumType::Vector)
	{
		throw::exception("Invalid data type");
	}

	new(mData.vectorPointer + index) glm::vec4(value);
}

void FieaGameEngine::Datum::Set(const glm::mat4x4 & value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (mType != DatumType::Matrix)
	{
		throw::exception("Invalid data type");
	}

	if (index >= mSize)
		throw::exception("Invalid index");

	new(mData.matrixPointer + index) glm::mat4x4(value);
}

void FieaGameEngine::Datum::Set(Scope * const & value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (index >= mSize)
		throw::exception("Invalid index");

	if (mType != DatumType::Table)
	{
		throw::exception("Invalid data type");
	}

	mData.scopePointer[index] = value;
}

void FieaGameEngine::Datum::Set(const std::string & value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (index >= mSize)
		throw::exception("Invalid index");

	if (mType != DatumType::String)
	{
		throw::exception("Invalid data type");
	}

	mData.stringPointer[index].~string();
	new(mData.stringPointer + index) string(value);
}

void FieaGameEngine::Datum::Set(RTTIPointer value, uint32_t index)
{
	if (mSize == 0)
		throw::exception("Can not set empty Datum");

	if (index >= mSize)
		throw::exception("Invalid index");

	if (mType != DatumType::Pointer)
	{
		throw::exception("Invalid data type");
	}

	mData.rttiPointer[index] = value;
}

template<>
int32_t & Datum::Get<int32_t>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.integerPointer[index];
}

template<>
float & Datum::Get<float>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.floatPointer[index];
}

template<>
glm::vec4 & Datum::Get<glm::vec4>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.vectorPointer[index];
}

template<>
glm::mat4x4 & Datum::Get<glm::mat4x4>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.matrixPointer[index];
}

template<>
Scope* & Datum::Get<Scope*>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.scopePointer[index];
}

template<>
string & Datum::Get<string>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.stringPointer[index];
}

template<>
RTTIPointer & Datum::Get<RTTIPointer>(uint32_t index)
{
	if (index >= mSize)
		throw::exception("Invalid index");

	return mData.rttiPointer[index];
}

void FieaGameEngine::Datum::SetFromString(std::string inputString, uint32_t index)
{
	switch (mType)
	{
	case FieaGameEngine::Datum::DatumType::Integer:
	{
		int32_t integer;
		sscanf_s(inputString.c_str(), "%d", &integer);
		Set(integer, index);
		break;
	}
	case FieaGameEngine::Datum::DatumType::Float:
	{
		float tempFloat;
		sscanf_s(inputString.c_str(), "%f", &tempFloat);
		Set(tempFloat, index);
		break;
	}
	case FieaGameEngine::Datum::DatumType::Vector:
	{
		glm::vec4 vector;
		sscanf_s(inputString.c_str(), "vec4(%f,%f,%f,%f)", &vector[0], &vector[1], &vector[2], &vector[3]);
		Set(vector, index);
		break;
	}
	case FieaGameEngine::Datum::DatumType::Matrix:
	{
		glm::mat4x4 matrix;
		sscanf_s(inputString.c_str(), "mat4x4((%f,%f,%f,%f), (%f,%f,%f,%f), (%f,%f,%f,%f), (%f,%f,%f,%f))", &matrix[0][0], &matrix[0][1], &matrix[0][2], &matrix[0][3], &matrix[1][0], &matrix[1][1], &matrix[1][2], &matrix[1][3], &matrix[2][0], &matrix[2][1], &matrix[2][2], &matrix[2][3], &matrix[3][0], &matrix[3][1], &matrix[3][2], &matrix[3][3]);
		Set(matrix, index);
		break;
	}

	case FieaGameEngine::Datum::DatumType::String:
		Set(inputString, index);
		break;

	default:
		throw::exception("Invalid Type");
		break;
	}
}

std::string FieaGameEngine::Datum::ToString(uint32_t index)
{
	string returnString;
	switch (mType)
	{
	case FieaGameEngine::Datum::DatumType::Integer:
		returnString = std::to_string(Get<int32_t>(index));
		break;

	case FieaGameEngine::Datum::DatumType::Float:
		returnString = std::to_string(Get<float>(index));
		break;

	case FieaGameEngine::Datum::DatumType::Vector:
		returnString = glm::to_string(Get<glm::vec4>(index));
		break;

	case FieaGameEngine::Datum::DatumType::Matrix:
		returnString = glm::to_string(Get<glm::mat4x4>(index));
		break;

	case FieaGameEngine::Datum::DatumType::String:
		returnString = Get<std::string>(index);
		break;

	case FieaGameEngine::Datum::DatumType::Pointer:
		returnString = (Get<RTTIPointer>(index))->ToString();
		break;

	default:
		throw::exception("Invalid Type");
		break;
	}

	return returnString;
}

Datum & FieaGameEngine::Datum::operator=(const Datum & copyDatum)
{
	if (this != &copyDatum)
	{
		if (copyDatum.mType != DatumType::Unknown)
		{
			Clear();

			mCapacity = 0;
			free(mData.voidPointer);
			mData.voidPointer = nullptr;

			mType = copyDatum.mType;
			mIsInternal = copyDatum.mIsInternal;

			if (copyDatum.mIsInternal)
			{
				Reserve(copyDatum.mSize);
				mSize = copyDatum.mSize;

				if (mType == DatumType::String)
				{
					for (uint32_t i = 0; i < mSize; ++i)
						new(mData.stringPointer + i) string(copyDatum.mData.stringPointer[i]);
				}
				else if (mType == DatumType::Table)
				{
					mSize = 0;
					for (uint32_t i = 0; i < copyDatum.mSize; ++i)
						PushBack(copyDatum.mData.scopePointer[i]);
				}
				else
				{
					memcpy_s(mData.voidPointer, (mDatumMap.At(mType) * mSize), copyDatum.mData.vectorPointer, (mDatumMap.At(mType) * mSize));
				}
			}
			else
			{
				mSize = copyDatum.mSize;
				mCapacity = copyDatum.mSize;
				mData = copyDatum.mData;
			}
		}
	}

	return *this;
}

Datum & FieaGameEngine::Datum::operator=(Datum && moveDatum)
{
	if (this != &moveDatum)
	{
		mIsInternal = moveDatum.mIsInternal;
		mType = moveDatum.mType;
		mData.voidPointer = moveDatum.mData.voidPointer;
		mSize = moveDatum.mSize;
		mCapacity = moveDatum.mCapacity;

		moveDatum.mType = DatumType::Unknown;
		moveDatum.mData.voidPointer = nullptr;
		moveDatum.mSize = 0;
		moveDatum.mCapacity = 0;
	}
	return *this;
}

int32_t & FieaGameEngine::Datum::operator=(int32_t copyInt)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Integer;
	}
	else if (mType != DatumType::Integer)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyInt);
	else
		mData.integerPointer[0] = (copyInt);

	return mData.integerPointer[0];
}

float & FieaGameEngine::Datum::operator=(float copyFloat)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Float;
	}
	else if (mType != DatumType::Float)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyFloat);
	else
		mData.floatPointer[0] = (copyFloat);

	return mData.floatPointer[0];
}

glm::vec4 & FieaGameEngine::Datum::operator=(const glm::vec4 & copyVector)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Vector;
	}
	else if (mType != DatumType::Vector)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyVector);
	else
		new(mData.vectorPointer) glm::vec4(copyVector);

	return mData.vectorPointer[0];
}

glm::mat4x4 & FieaGameEngine::Datum::operator=(const glm::mat4x4 & copyMatrix)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Matrix;
	}
	else if (mType != DatumType::Matrix)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyMatrix);
	else
		new(mData.matrixPointer) glm::mat4x4(copyMatrix);

	return mData.matrixPointer[0];
}

Scope* & FieaGameEngine::Datum::operator=(Scope * const & copyScope)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Table;
	}
	else if (mType != DatumType::Table)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyScope);
	else
		mData.scopePointer[0] = (copyScope);

	return mData.scopePointer[0];
}

std::string & FieaGameEngine::Datum::operator=(const std::string & copyString)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::String;
	}
	else if (mType != DatumType::String)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyString);
	else
	{
		mData.stringPointer[0].~string();
		new(mData.stringPointer) string(copyString);
	}

	return mData.stringPointer[0];
}

RTTIPointer & FieaGameEngine::Datum::operator=(RTTIPointer copyRTTIPointer)
{
	if (mType == DatumType::Unknown)
	{
		mType = DatumType::Pointer;
	}
	else if (mType != DatumType::Pointer)
	{
		throw::exception("Invalid data type");
	}

	if (mSize == 0)
		PushBack(copyRTTIPointer);
	else
		mData.rttiPointer[0] = (copyRTTIPointer);

	return mData.rttiPointer[0];
}

bool FieaGameEngine::Datum::operator==(const Datum & otherDatum) const
{
	if((mSize != otherDatum.mSize) || (mType != otherDatum.mType))
		return false;

	if (mType == DatumType::String)
	{
		for (uint32_t i = 0; i < mSize; ++i)
		{
			if (mData.stringPointer[i] != otherDatum.mData.stringPointer[i])
				return false;
		}
	}
	else if (mType == DatumType::Pointer || mType == DatumType::Table)
	{
		if (mData.rttiPointer == nullptr || otherDatum.mData.rttiPointer == nullptr)
		{
			return false;
		}
		if (mData.scopePointer == nullptr || otherDatum.mData.scopePointer == nullptr)
		{
			return false;
		}
		for (uint32_t i = 0; i < mSize; ++i)
		{
			if (!(mData.rttiPointer[i]->Equals( otherDatum.mData.rttiPointer[i])))
				return false;
		}
	}
	else
	{
		return (memcmp(otherDatum.mData.voidPointer, mData.voidPointer, mDatumMap.At(mType)* mSize) == 0);
	}
	return true;
}

bool FieaGameEngine::Datum::operator==(int32_t otherInt) const
{
	if (mSize == 0)
		return false;

	return (mData.integerPointer[0] == otherInt);
}

bool FieaGameEngine::Datum::operator==(float otherFloat) const
{
	if (mSize == 0)
		return false;

	return (mData.floatPointer[0] == otherFloat);
}

bool FieaGameEngine::Datum::operator==(const glm::vec4 & otherVector) const
{
	if (mSize == 0)
		return false;

	return (mData.vectorPointer[0] == otherVector);
}

bool FieaGameEngine::Datum::operator==(const glm::mat4x4 & otherMatrix) const
{
	if (mSize == 0)
		return false;

	return (mData.matrixPointer[0] == otherMatrix);
}

bool FieaGameEngine::Datum::operator==(Scope * const & otherScope) const
{
	if (mSize == 0)
		return false;

	return (mData.scopePointer[0] == otherScope);
}

bool FieaGameEngine::Datum::operator==(const std::string & otherString) const
{
	if (mSize == 0)
		return false;

	return (mData.stringPointer[0] == otherString);
}

bool FieaGameEngine::Datum::operator==(RTTIPointer otherRTTIPointer) const
{
	if (mSize == 0)
		return false;

	return (mData.rttiPointer[0] == otherRTTIPointer);
}

bool FieaGameEngine::Datum::operator!=(const Datum & otherDatum) const
{
	return !(operator==(otherDatum));
}

bool FieaGameEngine::Datum::operator!=(int32_t otherInt) const
{
	return !(operator==(otherInt));
}

bool FieaGameEngine::Datum::operator!=(float otherFloat) const
{
	return !(operator==(otherFloat));
}

bool FieaGameEngine::Datum::operator!=(const glm::vec4 & otherVector) const
{
	return !(operator==(otherVector));
}

bool FieaGameEngine::Datum::operator!=(const glm::mat4x4 & otherMatrix) const
{
	return !(operator==(otherMatrix));
}

bool FieaGameEngine::Datum::operator!=(Scope * const & otherScope) const
{
	return !(operator==(otherScope));
}

bool FieaGameEngine::Datum::operator!=(const std::string & otherString) const
{
	return !(operator==(otherString));
}

bool FieaGameEngine::Datum::operator!=(RTTIPointer otherRTTIPointer) const
{
	return !(operator==(otherRTTIPointer));
}

bool FieaGameEngine::Datum::Remove(const uint32_t & index)
{
	if (index < mSize)
	{
		memmove_s((mData.scopePointer + index), (sizeof(Scope *) * ((mSize) - index)), ((mData.scopePointer + index) + 1), (sizeof(Scope *) * ((mSize) - index)));
		--mSize;
		return true;
	}
	return false;
}

Scope & FieaGameEngine::Datum::operator[](std::uint32_t index)
{
	return *Get<Scope*>(index);
}

Datum::~Datum()
{
	Clear();
	if(mIsInternal)
		free(mData.voidPointer);
	mCapacity = 0;
	mData.voidPointer = nullptr;
}