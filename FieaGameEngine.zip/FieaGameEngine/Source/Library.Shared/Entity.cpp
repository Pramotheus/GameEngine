#include "pch.h"
#include "Sector.h"
#include "Entity.h"
#include "Action.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(Entity);

Entity::Entity()
	:Attributed(TypeIdInstance())
{
	InitializeMembers(TypeIdInstance());
}


FieaGameEngine::Entity::Entity(uint64_t typeID)
	:Attributed(typeID)
{
	InitializeMembers(typeID);
}

FieaGameEngine::Entity::Entity(Entity && moveEntity)
	: Attributed(std::move(moveEntity)), mName(std::move(moveEntity.mName))
{
	UpdateMembers();
}

Entity & FieaGameEngine::Entity::operator=(Entity && moveEntity)
{
	if (this != &moveEntity)
	{
		Attributed::operator=(std::move(moveEntity));
		mName = std::move(moveEntity.mName);
		UpdateMembers();
	}
	return *this;
}

std::string FieaGameEngine::Entity::Name() const
{
	return mName;
}

void FieaGameEngine::Entity::SetName(const std::string & entityName)
{
	mName = entityName;
}

Sector & FieaGameEngine::Entity::GetSector()
{
	return *mParent->As<Sector>();
}

void FieaGameEngine::Entity::SetSector(Sector * parentSector)
{
	parentSector->Adopt(*this, "Entities"s);
}

Action * FieaGameEngine::Entity::CreateAction(const std::string & actionClassName, const std::string & actionInstanceName)
{
	Action * createdAction = EngineFactory<Action>::Create(actionClassName);
	createdAction->SetName(actionInstanceName);
	createdAction->SetEntity(this);
	return createdAction;
}

Datum & FieaGameEngine::Entity::GetActions()
{
	return *Find("Actions"s);
}

void FieaGameEngine::Entity::Update(WorldState & worldState)
{
	worldState.CurrentEntity = this;

	Datum &actionDatum = GetActions();
	Scope *currentAction;
	uint32_t size = actionDatum.Size();

	for (uint32_t i = 0; i < size; ++i)
	{
		currentAction = actionDatum.Get<Scope*>(i);
		assert(currentAction->Is(Action::TypeIdClass()));
		static_cast<Action*>(currentAction)->Update(worldState);
	}

	worldState.CurrentEntity = nullptr;
}

void FieaGameEngine::Entity::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Name"s, &mName, 1);
	SetScope(typeID, "Actions"s);
	
}

void FieaGameEngine::Entity::UpdateMembers()
{
	(*this)["Name"s].SetStorage(&mName, 1);
}

Entity::~Entity()
{
}

