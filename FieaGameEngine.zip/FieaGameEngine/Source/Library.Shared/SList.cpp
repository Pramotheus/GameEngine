#include "pch.h"
#include "SList.h"

namespace FieaGameEngine
{

	SList::SList()
	{
	}


	SList::~SList()
	{
	}

}