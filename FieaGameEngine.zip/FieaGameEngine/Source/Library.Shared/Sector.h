#pragma once
#include "Attributed.h"
#include "WorldState.h"
#include "Entity.h"

namespace FieaGameEngine
{
	class World;

	//!Sector Class
	/*!
	*	The Sector class is a container for different entities present in the game, represnets a zone
	*	It inherits from atributed class
	*/
	class Sector final : public Attributed
	{
		RTTI_DECLARATIONS(Sector, Attributed)

	public:
		//!Sector default constructor
		/*!
		*	The Sector default constructor used to initialise members of base class and entity members
		*/
		Sector();
		//!Sector copy constructor
		/*!
		*	Constructor used to copy one Sector to other
		*/
		Sector(const Sector & copySector);
		//!Sector move constructor
		/*!
		*	Constructor used to move one Sector to other
		*/
		Sector(Sector && moveSector);
		//!Sector copy assignement operator
		/*!
		*	Assignement operator used to copy one Sector to other
		*/
		Sector & operator=(const Sector & copySector);
		//!Sector move assignement operator
		/*!
		*	Assignement operator used to move one Sector to other
		*/
		Sector & operator=(Sector && moveSector);

		//!Sector Get Name member function
		/*!
		*	function used to get the name of the current Sector
		*/
		std::string Name() const;
		//!Sector Set Name member function
		/*!
		*	function used to set the name of the current Sector
		*/
		void SetName(const std::string & sectorName);

		//!Sector Get Entities member function
		/*!
		*	function used to return the datum holding all entities
		*/
		Datum & GetEntities();
		//!Sector Create Entities member function
		/*!
		*	Function used to create a new Entity and attach to curent sector
		*	Returns a pointer to created entity
		*/
		Entity * CreateEntity(const std::string & entityClassName, const std::string & entityInstanceName);

		//!Sector Get Sector member function
		/*!
		*	function used to get the parent sector of the current Sector
		*/
		World & GetWorld();
		//!Sector Set Sector member function
		/*!
		*	function used to set the parent sector of the current Sector
		*/
		void SetWorld(World * parentSector);

		//!Sector Update function
		/*!
		*	Function that is called each frame from its parent
		*/
		void Update(WorldState & worldState);

		//!Sector default Destructor
		/*!
		*	Sector class default destructor
		*/
		~Sector();

	private:
		//!Sector Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Sector update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		std::string mName;									//!< Member variable holding the name of current variable
	};
}

