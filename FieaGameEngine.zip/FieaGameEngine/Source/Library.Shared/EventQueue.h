#pragma once
#include <memory>
#include <vector>
#include <mutex>
#include "GameTime.h"
#include "EventPublisher.h"

namespace FieaGameEngine
{
	//!Event Queue Class
	/*!
	*	The class is used to hold all active events untill they are ready to be fired
	*/
	class EventQueue
	{
	public:
		//!Enqueue function
		/*!
		*	Function that is used to add the event to the list of events waiting to be fired
		*/
		void Enqueue(shared_ptr<EventPublisher> publisher, GameTime & time, std::chrono::milliseconds delay = std::chrono::milliseconds::zero());
		//!Send function
		/*!
		*	Function that is to go call deliver on the event theat is already enqueued 
		*/
		void Send(shared_ptr<EventPublisher> publisher);
		//!Update function
		/*!
		*	Function that is to go through all events and call deliver if they have expired
		*/
		void Update(GameTime & time);

		//!Clear function
		/*!
		*	Used to clear out the queue
		*/
		void Clear();
		//!IsEmpty function
		/*!
		*	Used to check if the queue is empty
		*/
		bool IsEmpty();
		//!Size function
		/*!
		*	Used to check get the current size of the queue
		*/
		uint32_t Size();

	private:
		std::vector<std::shared_ptr<EventPublisher>> mEventQueue;								//!< Member vector holding all active events
		mutex mMutex;																			//!< Mutex variable to multi thread
	};
}
