#pragma once
#include "EngineFactory.h"
#include "Attributed.h"
#include "WorldState.h"

namespace FieaGameEngine
{
	//!Action Class
	/*!
	*	The Action class is used to define all verbs a.k.a components in the game
	*	It inherits from atributed class
	*/
	class Action : public Attributed
	{
		RTTI_DECLARATIONS(Action, Attributed)

	public:
		//!Action default constructor
		/*!
		*	Deleted as it can not have object of its own type
		*/
		Action() = delete;
		
		Action(const Action &) = delete;
		Action & operator=(const Action &) = delete;

		//!Action move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		Action(Action && moveAction);
		
		//!Action move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		Action & operator=(Action && moveAction);

		//!Action Get Name member function
		/*!
		*	function used to get the name of the current Action
		*/
		std::string Name() const;
		//!Action Set Name member function
		/*!
		*	function used to set the name of the current Action
		*/
		void SetName(const std::string & ActionName);

		//!Action Get Entity member function
		/*!
		*	function used to get the parent Entity of the current Action
		*/
		Entity & GetEntity();
		//!Action Set Entity member function
		/*!
		*	function used to set the parent Entity of the current Action
		*/
		void SetEntity(Entity * parentEntity);

		//!Action pure virtual Update function
		/*!
		*	Function that is called each frame from its parent
		*/
		virtual void Update(WorldState & worldState) = 0;

		//!Action Virtual Destructor
		/*!
		*	Virtual destructor for all classes that can derive from this class
		*/
		virtual ~Action();

	protected:
		//!Action inherited constructor for constructor
		/*!
		*	The Action constructor used to initialise members of base class and Action members while passing in the derived class type ID
		*/
		Action(uint64_t typeID);

	private:
		//!Action Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Action update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		std::string mName;									//!< Member variable holding the name of current variable
	};
}

