#include "pch.h"
#include "EventMessageAttributed.h"
#include "World.h"

using namespace FieaGameEngine;
using namespace std;

RTTI_DEFINITIONS(EventMessageAttributed)

EventMessageAttributed::EventMessageAttributed()
	:Attributed(TypeIdInstance()), mSubtype(), mWorldPointer()
{
	InitializeMembers(TypeIdInstance());
}

EventMessageAttributed::EventMessageAttributed(EventMessageAttributed && rhs)
	: Attributed(move(rhs)), mSubtype(move(rhs.mSubtype)), mWorldPointer(move(rhs.mWorldPointer))
{
	UpdateMembers();
}

EventMessageAttributed & FieaGameEngine::EventMessageAttributed::operator=(EventMessageAttributed && rhs)
{
	if (this != &rhs)
	{
		Attributed::operator=(move(rhs));
		mSubtype = move(rhs.mSubtype);
		mWorldPointer = move(rhs.mWorldPointer);

		UpdateMembers();
	}
	return *this;
}

const string & FieaGameEngine::EventMessageAttributed::GetSubtype() const
{
	return mSubtype;
}

World & FieaGameEngine::EventMessageAttributed::GetWorld() const
{
	return *mWorldPointer->As<World>();
}

void FieaGameEngine::EventMessageAttributed::SetSubtype(string & subtype)
{
	mSubtype = subtype;
}

void FieaGameEngine::EventMessageAttributed::SetWorld(World & world)
{
	mWorldPointer = &world;
}

void FieaGameEngine::EventMessageAttributed::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Subtype", &mSubtype, 1);
	SetExternalAttributes(typeID, "World", &mWorldPointer, 1);
}

void FieaGameEngine::EventMessageAttributed::UpdateMembers()
{
	(*this)["Subtype"].SetStorage(&mSubtype, 1);
	(*this)["World"].SetStorage(&mWorldPointer, 1);
}
