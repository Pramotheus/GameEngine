#include "pch.h"
#include "JsonParseHelperTable.h"
#include "World.h"
#include "IfAction.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(JsonParseHelperTable::SharedTableData);

JsonParseHelperTable::JsonParseHelperTable()
	:mTableSharedData(nullptr), mData()
{
}

void FieaGameEngine::JsonParseHelperTable::Initialize()
{
	while (!mData.empty())
	{
		mData.pop();
	}
	
}

bool FieaGameEngine::JsonParseHelperTable::DataHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData)
{
	if (mTableSharedData != nullptr && sharedData.Is(mTableSharedData->TypeIdInstance()))
	{
		mData.top().Insert({ key, data });
		return true;
	}

	return false;
}

bool FieaGameEngine::JsonParseHelperTable::StartHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData)
{
	mTableSharedData = sharedData.As<SharedTableData>();

	if (mTableSharedData != nullptr)
	{
		
		if (key == "Value")
		{
			if (mData.top().At("Type").asString() == "Scope")
			{
				mTableSharedData->mScope = &(mTableSharedData->mScope->AppendScope(mData.top().At("Key").asString()));
			}

			else if (mData.top().At("Type").asString() == "World")
			{
				World *world = new World();
				world->SetName(mData.top().At("Key").asString());
				Scope *worldHolder = world->As<Scope>();
				mTableSharedData->mScope->Adopt(*worldHolder, mData.top().At("Key").asString());
				mTableSharedData->mScope = worldHolder;
			}

			else if (mData.top().At("Type").asString() == "Sector")
			{
				assert(mTableSharedData->mScope->Is(World::TypeIdClass()));
				mTableSharedData->mScope = static_cast<World*>(mTableSharedData->mScope)->CreateSector(mData.top().At("Key").asString());
			}

			else if (mData.top().At("Type").asString() == "Entity")
			{
				assert(mTableSharedData->mScope->Is(Sector::TypeIdClass()));
				mTableSharedData->mScope = static_cast<Sector*>(mTableSharedData->mScope)->CreateEntity(mData.top().At("Class").asString(), mData.top().At("Key").asString());
			}

			else if (mData.top().At("Type").asString() == "Action")
			{
				if (mTableSharedData->mScope->Is(ActionList::TypeIdClass()))
				{
					mTableSharedData->mScope = static_cast<ActionList*>(mTableSharedData->mScope)->CreateActions(mData.top().At("Class").asString(), mData.top().At("Key").asString());
				}
				else
				{
					assert(mTableSharedData->mScope->Is(Entity::TypeIdClass()));
					mTableSharedData->mScope = static_cast<Entity*>(mTableSharedData->mScope)->CreateAction(mData.top().At("Class").asString(), mData.top().At("Key").asString());
				}
			}

			else if (mData.top().At("Type").asString() == "Reaction")
			{
				assert(mTableSharedData->mScope->Is(World::TypeIdClass()));
				mTableSharedData->mScope = static_cast<World*>(mTableSharedData->mScope)->CreateReactions(mData.top().At("Class").asString(), mData.top().At("Key").asString());
			}
		}

		mData.push(HashMap<string, Json::Value>());
		mData.top().Insert({ "Key", key });

		return true;
	}
	data;
	return false;
}

bool FieaGameEngine::JsonParseHelperTable::EndHandler(const JsonParseMaster::SharedData & sharedData)
{
	if (sharedData.Is(mTableSharedData->TypeIdInstance()))
	{
		if (mData.top().At("Key").asString() != "Value")
		{
			if (mData.top().Size() == 3 && !mData.top().ContainsKey("Class"))
			{
				Datum &currentDatum = mTableSharedData->mScope->Append((mData.top().At("Key")).asString());
				currentDatum.SetType(currentDatum.mDatumTypeMap.At(mData.top().At("Type").asString()));

				Json::Value datumValue = mData.top().At("Value");

				if (datumValue.isArray())
				{
					currentDatum.SetSize(datumValue.size());
					for (uint32_t i = 0; i < datumValue.size(); i++)
						currentDatum.SetFromString(datumValue[i].asString(), i);
				}
				else
				{
					currentDatum.SetSize(1);
					currentDatum.SetFromString(datumValue.asString());
				}
			}
		}
		else
		{
			mTableSharedData->mScope = mTableSharedData->mScope->GetParent();
		}
		mData.pop();
		return true;
	}

	return false;
}


JsonParseHelperTable * FieaGameEngine::JsonParseHelperTable::Clone()
{
	return new JsonParseHelperTable(*this);
}

JsonParseHelperTable::~JsonParseHelperTable()
{
}

JsonParseHelperTable::SharedTableData * FieaGameEngine::JsonParseHelperTable::SharedTableData::Clone()
{
	SharedTableData * cloneTableshare = new SharedTableData(*this);
	cloneTableshare->mScope = new Scope(*this->mScope);
	cloneTableshare->mParseMaster = nullptr;
	cloneTableshare->mIsClone = true;
	return cloneTableshare;
}

void FieaGameEngine::JsonParseHelperTable::SharedTableData::Initialize()
{
}

void FieaGameEngine::JsonParseHelperTable::SharedTableData::SetScope(Scope & baseScope)
{
	mScope = &baseScope;
}

Scope * FieaGameEngine::JsonParseHelperTable::SharedTableData::GetScope()
{
	return mScope;
}

FieaGameEngine::JsonParseHelperTable::SharedTableData::~SharedTableData()
{
	if (mIsClone)
		delete mScope;
}
