#pragma once
#include "Attributed.h"
#include "Sector.h"
#include "WorldState.h"
#include "GameClock.h"
#include "EventQueue.h"
#include "Reaction.h"

namespace FieaGameEngine
{
	//!World Class
	/*!
	*	The World class is a container for different sectors present in the game
	*	It is the overall container that holds all game content
	*	It inherits from atributed class
	*/
	class World final : public Attributed
	{
		RTTI_DECLARATIONS(World, Attributed)

	public:
		//!World default constructor
		/*!
		*	The World default constructor used to initialise members of base class and entity members
		*/
		World();
		//!World copy constructor
		/*!
		*	Constructor used to copy one World to other
		*/
		World(const World &) = delete;
		//!World move constructor
		/*!
		*	Constructor used to move one World to other
		*/
		World(World && moveWorld);
		//!World copy assignement operator
		/*!
		*	Assignement operator used to copy one World to other
		*/
		World & operator=(const World &) = delete;
		//!World move assignement operator
		/*!
		*	Assignement operator used to move one World to other
		*/
		World & operator=(World && moveWorld);

		//!World Get Name member function
		/*!
		*	function used to get the name of the current World
		*/
		std::string Name() const;
		//!World Set Name member function
		/*!
		*	function used to set the name of the current World
		*/
		void SetName(const std::string & sectorName);

		//!World Get Entities member function
		/*!
		*	function used to return the datum holding all entities
		*/
		Datum & GetSectors();
		//!World Create Sector member function
		/*!
		*	Function used to create a new Sector and attach to curent World
		*	Returns a pointer to created Sector
		*/
		Sector * CreateSector(const std::string & sectorInstanceName);

		//!World Create Reactions member function
		/*!
		*	Function used to create a new Reaction and attach to curent World
		*	Returns a pointer to created Reaction
		*/
		Reaction * CreateReactions(const std::string & reactionClassName, const std::string & reactionInstanceName);

		//!World Get World State member function
		/*!
		*	Helper function used to return the world state object reference
		*/
		WorldState & GetWorldState();

		EventQueue & GetEventQueue();

		//!World Update function
		/*!
		*	Function that is called each frame from its parent
		*/
		void Update();

		//!World default Destructor
		/*!
		*	World class default destructor
		*/
		~World() = default;

	private:
		//!World Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!World update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		std::string mName;									//!< Member variable holding the name of current variable
		WorldState mWorldState;								//!< Member variable holding the World state object
		EventQueue mEventQueue;
	};
}

