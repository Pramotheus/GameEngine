#include "pch.h"
#include <future>
#include <algorithm>
#include "EventQueue.h"

using namespace FieaGameEngine;
using namespace std;

void FieaGameEngine::EventQueue::Enqueue(shared_ptr<EventPublisher> publisher, GameTime & time, std::chrono::milliseconds delay)
{
	lock_guard<mutex> lock(mMutex);

	publisher->SetTime(time.CurrentTime(), delay);
	mEventQueue.push_back(publisher);
}

void FieaGameEngine::EventQueue::Send(shared_ptr<EventPublisher> publisher)
{
	for (auto & value : mEventQueue)
		if (value == publisher)
		{
			publisher->Deliver();
			break;
		}
}

void FieaGameEngine::EventQueue::Update(GameTime & time)
{
	vector<shared_ptr<EventPublisher>> removeVector;

	{
		lock_guard<mutex> lock(mMutex);

		vector<shared_ptr<EventPublisher>>::iterator it, removeIt;
		it = partition(mEventQueue.begin(), mEventQueue.end(), [&time](shared_ptr<EventPublisher> currentPublisher) { return !currentPublisher->IsExpired(time.CurrentTime()); });
		removeIt = it;

		std::move(it, mEventQueue.end(), back_inserter(removeVector));
		mEventQueue.erase(removeIt, mEventQueue.end());
	}

	vector<future<void>> futures;

	for (auto & value : removeVector)
	{
		futures.emplace_back(async(launch::async, [&value] {value->Deliver(); }));
	}

	for (auto& f : futures)
	{
		f.get();
	}

	removeVector.clear();
}

void FieaGameEngine::EventQueue::Clear()
{
	mEventQueue.clear();
}

bool FieaGameEngine::EventQueue::IsEmpty()
{
	return mEventQueue.empty();
}

uint32_t FieaGameEngine::EventQueue::Size()
{
	return static_cast<uint32_t>(mEventQueue.size());
}

