#pragma once
#include "ActionList.h"

namespace FieaGameEngine
{
	//!If Action Class
	/*!
	*	The If Action class is used to preform the work of a if else statement form the json script
	*	It inherits from action list class
	*/
	class IfAction final : public ActionList
	{
		RTTI_DECLARATIONS(IfAction, ActionList)

	public:
		//!Default constructor
		/*!
		*	Initialises the member variables for the class
		*/
		IfAction();

		IfAction(const IfAction &) = delete;
		IfAction & operator=(const IfAction &) = delete;

		//!Action List move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		IfAction(IfAction && moveIfAction);

		//!Action List move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		IfAction & operator=(IfAction && moveIfAction);

		//!Get passed Action member function
		/*!
		*	function used to return the action which passes the condition
		*/
		Action* GetPassedActions();

		//!Update function
		/*!
		*	Function that is called each frame from its parent
		*	Runs the update function for the action which passes the condition 
		*/
		void Update(WorldState & worldState);

		//!Default Destructor
		/*!
		*	Defaul destructor for destructing member variables, can be defaulted
		*/
		~IfAction();

	private:
		//!If Action Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!If Action update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		int mCondition;											//!< Member variable holding the condition for if else branch
	};

	ConcreteFactory(IfAction, Action)
}
