#pragma once
#include "GameTime.h"
#include "Vector.h"
#include "Scope.h"

namespace FieaGameEngine
{
	//Predefenitions for classes
	class World;
	class Sector;
	class Entity;
	class Action;

	//!World State Class
	/*!
	*	The World state class is used to hold the game time and pointer to different containers currently in use
	*/
	class WorldState
	{
	public:
		World * CurrentWorld{ nullptr };						//!< Pointer to the current world container
		Sector * CurrentSector{ nullptr };						//!< Pointer to the current Sector container
		Entity * CurrentEntity{ nullptr };						//!< Pointer to the current Entity
		Action * CurrentAction{ nullptr };						//!< Pointer to the current Action

		//!Get Game Time member function
		/*!
		*	Function used to get current game time object
		*/
		GameTime& GetGameTime();
		//!Set Game Time member function
		/*!
		*	Function used to set current game time object
		*/
		void SetGameTime(GameTime & gameTime);

		void ThrowTrash();
		void CollectTrash(Scope * & trash);

	private:
		GameTime * mGameTime{nullptr};							//!< Pointer to game time object
		Vector<Scope*> mTrashBin;
	};
}

