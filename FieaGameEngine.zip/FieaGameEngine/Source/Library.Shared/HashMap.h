#pragma once
#include <cstdint>
#include <string>
#include <utility>
#include "SList.h"
#include "Vector.h"

namespace FieaGameEngine
{
	//!Templated Default hash functor class
	/*!
	*	Class is for functor defenition which generates the hash  from passed in key value
	*/
	template <typename T>
	class DefaultHashFunctor
	{
	public:
		//!Templated Default hash functor
		/*!
		*	Default functor which runs for all data types that are not specialised and generates the hash
		*	Can be called from const functions
		*/
		uint32_t operator()(const T& key) const;
	};

	template <>
	class DefaultHashFunctor <char*>
	{
	public:
		//!Templated specialised hash functor for charecter pointer
		/*!
		*	Template specialised functor for handeling charecter pointer keys to generate hash values
		*	Can be called from const functions
		*/
		uint32_t operator()(const char* key) const;
	};

	template <>
	class DefaultHashFunctor <string>
	{
	public:
		//!Templated specialised hash functor for strings
		/*!
		*	Template specialised functor for handeling string keys to generate hash values
		*	Can be called from const functions
		*/
		uint32_t operator()(const string & key) const;
	};

	//!Templated Default compare functor class
	/*!
	*	The Class is used for functor defenition which provides equality between to two keys
	*/
	template <typename T>
	class DefaultCompareFunctor
	{
	public:
		//!Templated Default compare functor
		/*!
		*	Default functor which returns a bool when both the passed keys are equal
		*	Used for all data types that are not specialized
		*	Can be called from const functions
		*/
		bool operator()(const T& lhs, const T& rhs) const;
	};

	template<>
	class DefaultCompareFunctor <char*>
	{
	public:
		//!Template specialized compare functor
		/*!
		*	Template specialised functor forreturning equality between charecter pointers (string data)
		*	Can be called from const functions
		*/
		bool operator()(const char* lhs, const char* rhs) const;
	};

	//!Multi Templated HashMap Class
	/*!
	*	The class is used for generating hash maps
	*	 Accepts four templates for key, data, hash function and compare functions respectively
	*/
	template <typename TKey, typename TData, typename HashFunctor = DefaultHashFunctor<TKey>, typename CompareFunctor = DefaultCompareFunctor<TKey>>
	class HashMap
	{
	private:
		typedef pair<TKey, TData> PairType;							//!< Type defenition for key data pair, created using std:pair
		typedef SList<PairType> Chain;								//!< Type defenition for SLists holding the paired data
		typedef Vector<Chain> Bucket;								//!< Type defenition for vector holding the collection of SLists
		typedef typename Chain::Iterator ChainIterator;				//!< Type defenition for SList's Iterator

		uint32_t mSize;												//!< Number of elements stored in the list
		Bucket mBucket;												//!< Vector holding the slists
		HashFunctor mHashFunctor;									//!< Hash functor object used to generate the hash value
		CompareFunctor mComparitor;									//!< Compare functor object for finding equality between keys

	public:
		//!Iterator class for iterating through the HashMap 
		/*!
		*	The class is used for iterating through the HashMap values
		*	It holds a pointer to its owner, a index of vector and Slists iterator
		*/
		class Iterator
		{
		private:
			friend HashMap;

			const HashMap* mOwner;									//!< HashMap class pointer variable used to set the owner HashMap
			uint32_t mIndex;										//!< Index to the content of data in vector a.k.a buckets
			ChainIterator mChainIterator;							//!< SList's iterator object for navigating each slist a.k.a chains

			//!Iterator class parameterised constructor
			/*!
			*	Constructor used for initializing the Iterator class data members
			*/
			Iterator(const HashMap & owner, ChainIterator chainIterator, uint32_t index = 0);

		public:
			//!Iterator class default constructor
			/*!
			*	Constructor used for initializing the Iterator class data members to default
			*/
			Iterator();

			//!Iterator class copy constructor
			/*!
			*	Constructor used for copy from other iterator object
			*/
			Iterator(const Iterator & otherIterator) = default;

			//!Iterator relational equality operator overload
			/*!
			*	Checks for one:one comeparison of iterators data members
			*	Returns a bool based on comparison 
			*	Can be called from const functions
			*/
			bool operator==(const Iterator& rhs) const;

			//!Iterator relational equality operator overload
			/*!
			*	Checks for one:one comeparison of iterators data members
			*	Returns a bool based on comparison (inverse of equality operator)
			*	Can be called from const functions
			*/
			bool operator!=(const Iterator& rhs) const;

			//!Iterator pre increment operator overload
			/*!
			*	Move iterator to next available data in the hash map or the end of the map
			*/
			Iterator & operator++();

			//!Iterator post increment operator overload
			/*!
			*	Updates the iterator after returning current iterator value
			*/
			Iterator operator++(int);

			//!Iterator dereference operator overload const
			/*!
			*	Returns the actual value stored in the current position of iterator
			*	Can be used inside const functions
			*/
			const PairType & operator*() const;

			//!Iterator dereference operator overload
			/*!
			*	Returns the actual value stored in the current position of iterator
			*/
			PairType & operator*();

			//!Iterator dereference operator overload const
			/*!
			*	Returns a reference to the actual value stored in the current position of iterator
			*	Can be used inside const functions
			*/
			const PairType * operator->() const;

			//!Iterator dereference operator overload
			/*!
			*	Returns a reference to the actual value stored in the current position of iterator
			*/
			PairType * operator->();
			
			//!Iterator assignment operator overload
			/*!
			* used to copy from right side iterator object to left side iterator object
			*/
			Iterator& operator=(const Iterator & otherIterator);
			
			//!Iterator default destructor
			/*!
			*	Releases the memory of the stored iterator data
			*/
			~Iterator() = default;
		};

		//!HashMap constructor
		/*!
		*	Accepts one parameter for bucket size
		*	Reserves the buckets size as a vector and instanitates tall slists to default
		*/
		explicit HashMap(const uint32_t & hashTableSize = 10);

		//!HashMap default copy constructor
		/*!
		*	Performs a shallow copy for the hashmap data
		*/
		HashMap(const HashMap & copyHashMap) = default;
		HashMap(HashMap && moveHashMap);
		//!HashMap Initializer list constructor
		/*!
		*	Accepts a list of pair data and inserts them after initialising the buckets and chain
		*/
		HashMap(std::initializer_list<PairType> list);

		//!HashMap Find function
		/*!
		*	Returns a iterator pointing to the key passed in as reference
		*	Throws an exception if can fins the appropriate value
		*	Can be used within const functions
		*/
		Iterator Find(const TKey & key) const;

		//!HashMap Insert function
		/*!
		*	Inserts the pair passed in through reference and reters a iterator to it
		*	If pair already present passes a index to it
		*/
		Iterator Insert(const PairType & PairType, bool & Inserted);

		//!HashMap Insert function
		/*!
		*	Inserts the pair passed in through reference and reters a iterator to it
		*	If pair already present passes a index to it
		*/
		Iterator Insert(const PairType & PairType);

		//!HashMap Insert function
		/*!
		*	Returns the data stored in the pair
		*	can be used to assign data by passing in new key and data
		*/
		TData & operator[](const TKey & key);

		//!HashMap At function
		/*!
		*	Returns reference to the data stored in pair at specified key passed in as argument
		*/
		TData & At(const TKey & key);
		
		//!HashMap const At function
		/*!
		*	Returns const reference to the data stored in pair at specified key passed in as argument
		*	Can be used in const functions
		*/
		const TData & At(const TKey & key) const;

		//!HashMap Remove function
		/*!
		*	Deletes the stored in the location decided by the key
		*	Returns true if data was deleted
		*/
		bool Remove(const TKey & key);

		//!HashMap Clear function
		/*!
		*	Used to clearout all data stored in the hashmap
		*/
		void Clear();

		//!HashMap size function
		/*!
		*	Returns the number of elements stored in the hashmap
		*/
		uint32_t Size() const;

		//!HashMap contains key function
		/*!
		*	Returns true if able to find pair stored with passed in key
		*/
		bool ContainsKey(const TKey & key) const;

		//!HashMap const contains key function
		/*!
		*	Returns true if able to find pair stored with passed in key
		*	Sets the pair's data found based on the key on the passed parameter
		*/
		bool ContainsKey(const TKey & key, TData& data) const;

		//!Vector Begin function
		/*!
		*	Returns a iterator pointing to the first element of the hashmap
		*	Can be used in const functions
		*/
		Iterator begin() const;

		//!Vector Begin function
		/*!
		*	Returns a iterator pointing to the last element of the hashmap
		*	Can be used in const functions
		*/
		Iterator end() const;

		//!HashMap default copy operator
		/*!
		*	Performs a shallow copy for the hashmap data
		*/
		HashMap& operator=(const HashMap & copyHashMap) = default;

		//!HashMap default Move operator
		/*!
		*	Performs a shallow copy move for the hashmap data
		*/
		HashMap& operator=(HashMap && moveHashMap);

		//!HashMap default destructor
		/*!
		*	Releases the memory of the stored hashmap data
		*/
		~HashMap() = default;
	};

}
#include "HashMap.inl"
