#include "pch.h"
#include "Reaction.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(Reaction)

Reaction::Reaction(Reaction && rhs)
	:ActionList(std::move(rhs))
{
}

Reaction & FieaGameEngine::Reaction::operator=(Reaction && rhs)
{
	if (this != &rhs)
	{
		ActionList::operator=(std::move(rhs));
	}

	return *this;
}

Reaction::Reaction(uint64_t typeID)
	:ActionList(typeID)
{
}
