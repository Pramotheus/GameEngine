#pragma once
#include "Reaction.h"

namespace FieaGameEngine
{
	//!ReactionAttributed Class
	/*!
	*	The reaction class created for handiling events from attributed payloads
	*	It inherits from Reaction class
	*/
	class ReactionAttributed : public Reaction
	{
		RTTI_DECLARATIONS(ReactionAttributed, Reaction)
	public:
		//!Defaulted Constructor & Destructor
		/*!
		*	The constructer, copy constructor and virtual destructor are defaulted
		*/
		ReactionAttributed();
		~ReactionAttributed() = default;
		ReactionAttributed(const ReactionAttributed&) = delete;
		ReactionAttributed & operator=(const ReactionAttributed &) = delete;
		//!Move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		ReactionAttributed(ReactionAttributed && rhs);
		//!Move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		ReactionAttributed & operator=(ReactionAttributed && rhs);

		//!Action's pure virtual Update function
		/*!
		*	Function that is called each frame from its parent
		*/
		virtual void Update(WorldState & worldState) override;

		//!Notify function
		/*!
		*	pure vertual function that is called whrn the event to ehich this is subscribed to is fired
		*/
		virtual void Notify(EventPublisher & publisher) override;

	public:
		//!Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		string mSubtype;												//Subtype used to specify the type of message on the event
	};

	ConcreteFactory(ReactionAttributed, Reaction)
}
