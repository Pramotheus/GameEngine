#pragma once
#include "EngineFactory.h"
#include "Attributed.h"
#include "WorldState.h"

namespace FieaGameEngine
{
	class Sector;

	//!Entity Class
	/*!
	*	The Entity class is used to define all nouns a.k.a objects in the game
	*	It inherits from atributed class
	*/
	class Entity : public Attributed
	{
		RTTI_DECLARATIONS(Entity, Attributed)

	public:
		//!Entity default constructor
		/*!
		*	The entity default constructor used to initialise members of base class and entity members
		*/
		Entity();
		
		Entity(const Entity &) = delete;
		Entity & operator=(const Entity &) = delete;

		//!Entity move constructor
		/*!
		*	Constructor used to move one entity to other
		*/
		Entity(Entity && moveEntity);
		//!Entity move assignement operator
		/*!
		*	Assignement operator used to move one entity to other
		*/
		Entity & operator=(Entity && moveEntity);

		//!Entity Get Name member function
		/*!
		*	function used to get the name of the current entity
		*/
		std::string Name() const;
		//!Entity Set Name member function
		/*!
		*	function used to set the name of the current entity
		*/
		void SetName(const std::string & entityName);

		//!Entity Get Sector member function
		/*!
		*	function used to get the parent sector of the current entity
		*/
		Sector & GetSector();
		//!Entity Set Sector member function
		/*!
		*	function used to set the parent sector of the current entity
		*/
		void SetSector(Sector * parentSector);

		//!Entity Create Action member function
		/*!
		*	Function used to create a new Action and attach to curent Action List
		*	Returns a pointer to created entity
		*/
		Action * CreateAction(const std::string & actionClassName, const std::string & actionInstanceName);

		//!Entity Get Actions member function
		/*!
		*	function used to return the datum holding all actions
		*/
		Datum & GetActions();

		//!Entity Update function
		/*!
		*	Function that is called each frame from its parent
		*/
		void Update(WorldState & worldState);

		//!Entity Virtual Destructor
		/*!
		*	Virtual destructor for all classes that can derive from attributed
		*/
		virtual ~Entity();

	protected:
		//!Entity inherited constructor for constructor
		/*!
		*	The entity constructor used to initialise members of base class and entity members while passing in the derived class type ID
		*/
		Entity(uint64_t typeID);

	private:
		//!Entity Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Entity update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		std::string mName;									//!< Member variable holding the name of current variable
	};

	ConcreteFactory(Entity, Entity)
}

