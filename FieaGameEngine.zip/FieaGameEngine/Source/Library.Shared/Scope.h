#pragma once
#include "RTTI.h"
#include "Datum.h"

namespace FieaGameEngine
{
	//!Scope Class
	/*!
	*	The Scope class behaves as a table with a ordered hashmap of string datum pairs
	*	It inherits from RTTI
	*/
	class Scope : public RTTI
	{
		RTTI_DECLARATIONS(Scope, RTTI)										//RTTI Declaration

	public:
		//!Scope default constructor
		/*!
		*	The default constructor initializes its members
		*	By defaults allocates 5 capacity to the scope
		*/
		explicit Scope(uint32_t capacity = 5);
		//!Scope default copy constructor
		/*!
		*	Performs deep copy on the scopes datum values
		*	Does not copy information of parent scope
		*/
		Scope(const Scope & copyScope);
		Scope(Scope && moveScope);

		void Reparent(Scope & scopeReference);

		//!Scope find function
		/*!
		*	Used for finding datums within the scope table
		*	Accepts a string as key to the datum string pair
		*/
		Datum* Find(const std::string & key) const;
		//!Scope Search function
		/*!
		*	Used for finding datums and scopes containg the datum up the chain (child -> parent)
		*	Scope pointer has to be passed in as paramaeter to get information of scope containg the requested datum
		*/
		Datum* Search(const std::string & key, Scope ** foundScope = nullptr);
		//!Scope Append function
		/*!
		*	Used for creating a new datum or getting reference to datum already present in the scope
		*	use string passed in as key to the hash map
		*/
		Datum& Append(const std::string & key);
		//!Scope Append Scope function
		/*!
		*	Used for creating a new scope and appending to a already existant or new datum
		*	use string passed in as key to the hash map
		*/
		Scope& AppendScope(const std::string & key);

		//!Scope Adopt function
		/*!
		*	Used for adding a new scope as the child of current scope
		*	use string passed in as key to the hash map 
		*/
		void Adopt(Scope & newChild, const std::string & childName);
		//!Scope get parent function
		/*!
		*	returns the parent scope o the current scope
		*/
		Scope* GetParent();
		//!Scope Find Name function
		/*!
		*	Used for fetching the key a.k.a string assocoiated with scope (on the datum)
		*	requested scope is passed in as argument
		*/
		std::string FindName(const Scope & scopeAddress);

		//!Scope clear function
		/*!
		*	Used for clearing the scope
		*/
		void Clear();
		//!Scope ophan function
		/*!
		*	Used for removing a specific scope from its childers
		*/
		void Orphan(Scope & Leaver);

		//!Scope operator [] overlad
		/*!
		*	Used for getting refence to datum using a string
		*	Behaves similar to append
		*/
		Datum& operator[](const std::string & key);
		//!Scope operator [] overlad
		/*!
		*	Used for getting refence to datum using a integer index
		*	Behaves find with Datum reference
		*/
		Datum& operator[](uint32_t index);
		//!Scope equality operator overlad
		/*!
		*	Used for verifying equality between two scopes
		*/
		bool operator==(const Scope& otherScope) const;
		//!Scope inequality operator overlad
		/*!
		*	Used for verifying inequality between two scopes
		*/
		bool operator!=(const Scope& otherScope) const;
		//!Scope assignment overlad
		/*!
		*	Used for assigning values from one scope to other
		*/
		Scope& operator=(const Scope & copyScope);
		Scope& operator=(Scope && copyScope);
		//!Scope default distructor
		/*!
		*	Used for orphaning the scope and clearing out hte data
		*/
		virtual ~Scope();

		//!RTTI equals function overlad
		/*!
		*	Used checking for equality
		*	calls scopes' equality operator
		*/
		virtual bool Equals(const RTTI* rhs) const override;
		//!RTTI To string function overlad
		/*!
		*	Used returning string value associated with the class
		*/
		virtual std::string ToString() const override;

	protected:
		typedef std::pair<std::string, Datum> OrderPair;

		Scope* mParent;													//!< Pointer to the parent scope
		HashMap<std::string, Datum> mData;								//!< Hashmap holding the string Datum pairs
		Vector<OrderPair*> mOrderVector;									//!< Vector with string Datum pointer pairts to hold order of data

	};
}

