#pragma once
#include "JsonParseMaster.h"
#include <json/json.h>

namespace FieaGameEngine
{
	//!Abstract Json Parse Helper Class
	/*!
	*	The class provides base layout for json parse handlers to derive from
	*	Consists only of pure vertual functions
	*	Each of derived classs handle one particular type of data from parsed Json values called from parse manager
	*/
	class IJsonParseHelper abstract
	{
	public:
		//!Default constructor
		/*!
		*	Json class default constructor
		*/
		IJsonParseHelper() = default;

		//!Initialize member function
		/*!
		*	Used to initialize any state variables the handlers hold
		*/
		virtual void Initialize() = 0;

		//!Data handler member function
		/*!
		*	Takes care of the actual parsing and storing of data passed in from parse master working with the other two handlers
		*	Returns true if Able to handle the data
		*/
		virtual bool DataHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData) = 0;

		//!Start handler member function
		/*!
		*	Takes care of the actual parsing and storing of data passed in from parse master working with the other two handlers
		*	Returns true if Able to handle the data
		*/
		virtual bool StartHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData) = 0;

		//!End handler member function
		/*!
		*	Takes care of the actual parsing and storing of data passed in from parse master working with the other two handlers
		*	Returns true if Able to handle the data
		*/
		virtual bool EndHandler(const JsonParseMaster::SharedData & sharedData) = 0;

		//!Clone member function
		/*!
		*	Used for creating a copy of itself on the heap and return a pointer to the created helper
		*/
		virtual IJsonParseHelper* Clone() = 0;

		//!virtual destructor
		/*!
		*	defaulted for the base class
		*/
		virtual ~IJsonParseHelper() = default;
	};
}

