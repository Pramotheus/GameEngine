#include "pch.h"
#include "Scope.h"
#include "HashMap.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(Scope);

FieaGameEngine::Scope::Scope(uint32_t capacity)
	:mData(capacity),mOrderVector(capacity), mParent(nullptr)
{
}

FieaGameEngine::Scope::Scope(const Scope & copyScope)
{
	operator=(copyScope);
}

FieaGameEngine::Scope::Scope(Scope && moveScope)
	:mData(std::move(moveScope.mData)), mOrderVector(std::move(moveScope.mOrderVector)), mParent(moveScope.mParent)
{
	Reparent(moveScope);
}

void FieaGameEngine::Scope::Reparent(Scope & scopeReference)
{
	if (mParent != nullptr)
	{
		for (auto & value : mParent->mOrderVector)
		{
			if (value->second.Type() == Datum::DatumType::Table)
			{
				for (uint32_t j = 0; j < value->second.Size(); ++j)
				{
					if (&scopeReference == value->second.Get<Scope*>(j))
					{
						value->second.Get<Scope*>(j) = this;
						scopeReference.mParent = nullptr;
						break;
					}
				}
			}
			
		}
	}

	for (auto & value : mOrderVector)
	{
		if (value->second.Type() == Datum::DatumType::Table)
		{
			for (uint32_t j = 0; j < value->second.Size(); ++j)
			{
				value->second.Get<Scope*>(j)->mParent = this;
			}
		}
	}
}

Datum * FieaGameEngine::Scope::Find(const std::string & key) const
{
	HashMap<std::string, Datum>::Iterator it = mData.Find(key);

	if (it == mData.end())
		return nullptr;

	return &(it->second);
}

Datum * FieaGameEngine::Scope::Search(const std::string & key, Scope ** foundScope)
{
	Datum * referenceDatum = Find(key);

	if (referenceDatum != nullptr)
	{
		if(foundScope != nullptr)
			*foundScope = this;

		return referenceDatum;
	}

	if (mParent != nullptr)
		referenceDatum = mParent->Search(key, foundScope);

	if (referenceDatum == nullptr)
	{
		*foundScope = nullptr;
	}

	return referenceDatum;
}

Datum & FieaGameEngine::Scope::Append(const std::string & key)
{
	if (key == "")
		throw exception("Invalid key string");

	bool inserted;
	OrderPair &tempPair = *(mData.Insert(make_pair(key, Datum()), inserted));

	if(inserted)
		mOrderVector.PushBack(&tempPair);

	return tempPair.second;
}

Scope & FieaGameEngine::Scope::AppendScope(const std::string & key)
{
	Datum & tempDatum = Append(key);


	if (!(tempDatum.Type() == Datum::DatumType::Unknown || tempDatum.Type() == Datum::DatumType::Table))
	{
		throw exception(" Datum of diferent type already present");
	}

	Scope* tempScope = new Scope();
	tempScope->mParent = this;
	tempDatum.PushBack(tempScope);
	return *tempScope;
}

void FieaGameEngine::Scope::Adopt(Scope & newChild, const std::string & childName)
{
	if (this != &newChild)
	{
		Datum & tempDatum = Append(childName);

		if (!(tempDatum.Type() == Datum::DatumType::Unknown || tempDatum.Type() == Datum::DatumType::Table))
		{
			throw exception(" Datum of diferent type already present");
		}

		if (newChild.mParent != nullptr)
			newChild.mParent->Orphan(newChild);

		newChild.mParent = this;
		tempDatum.PushBack(&newChild);
	}
}

Scope * FieaGameEngine::Scope::GetParent()
{
	return mParent;
}

std::string FieaGameEngine::Scope::FindName(const Scope & scopeAddress)
{
	for (auto & value : mOrderVector)
	{
		if (value->second.Type() == Datum::DatumType::Table)
		{
			for (uint32_t j = 0; j < value->second.Size(); ++j)
				if (&scopeAddress == value->second.Get<Scope*>(j))
					return value->first;
		}
	}

	return "";
}

void FieaGameEngine::Scope::Clear()
{
	for (auto & value : mOrderVector)
	{
		if (value->second.Type() == Datum::DatumType::Table)
		{
			for (uint32_t j = 0; j < value->second.Size(); ++j)
			{
				value->second[j].mParent = nullptr;
				delete &value->second[j];
			}
		}
	}

	mData.Clear();
	mOrderVector.Clear();
}

void FieaGameEngine::Scope::Orphan(Scope & leaver)
{
	for (auto & value : mOrderVector)
	{
		if (value->second.Type() == Datum::DatumType::Table)
		{
			for (uint32_t j = 0; j < value->second.Size(); ++j)
			{
				if (&leaver == value->second.Get<Scope*>(j))
				{
					value->second.Remove(j);
					leaver.mParent = nullptr;
				}
			}
		}
	}
}

Datum & FieaGameEngine::Scope::operator[](const std::string & key)
{
	return Append(key);
}

Datum & FieaGameEngine::Scope::operator[](uint32_t index)
{
	if(index > mOrderVector.Size())
		throw exception("Invalid index");

	return (mOrderVector[index]->second);
}

bool FieaGameEngine::Scope::operator==(const Scope & otherScope) const
{
	if (mData.Size() != otherScope.mData.Size())
	{
		return false;
	}
	uint32_t size = mOrderVector.Size();
	for (uint32_t i = 0; i < size; ++i)
	{
		if ((mOrderVector.At(i)->first != otherScope.mOrderVector.At(i)->first) || (mOrderVector.At(i)->second != otherScope.mOrderVector.At(i)->second))
			return false;
	}
	return true;
}

bool FieaGameEngine::Scope::operator!=(const Scope & otherScope) const
{
	return !(operator==(otherScope));
}

Scope & FieaGameEngine::Scope::operator=(const Scope & copyScope)
{
	if (this != &copyScope)
	{
		Clear();
		mParent = nullptr;
		mOrderVector.Reserve(copyScope.mOrderVector.Size());

		for (auto & value : copyScope.mOrderVector)
		{
			if (value->second.Type() == Datum::DatumType::Table)
			{
				uint32_t size = value->second.Size();
				for (uint32_t i = 0; i < size; ++i)
				{
					Scope *tempScope = new Scope(*(value->second.Get<Scope*>(i)));
					Adopt(*tempScope, value->first);
				}
			}
			else
			{
				Append(value->first) = (value->second);
			}
		}
	}

	return *this;
}

Scope & FieaGameEngine::Scope::operator=(Scope && moveScope)
{
	if (this != &moveScope)
	{
		Clear();
		mData = std::move(moveScope.mData);
		mParent = moveScope.mParent;
		Reparent(moveScope);
		mOrderVector = std::move(moveScope.mOrderVector);
	}
	return *this;
}

Scope::~Scope()
{
	Clear();
	if (mParent != nullptr)
		mParent->Orphan(*this);
}

bool FieaGameEngine::Scope::Equals(const RTTI * rhs) const
{
	Scope *temp = rhs->As<Scope>();
	if (temp != nullptr)
		return operator==(*temp);

	return false;
}

std::string FieaGameEngine::Scope::ToString() const
{
	if (mOrderVector.Size() > 0)
		return (mOrderVector.At(0)->first);

	return "Unknown Scope";
}
