#pragma once
#include "ActionList.h"
#include "EventSubscriber.h"

namespace FieaGameEngine
{
	//!Reaction Class
	/*!
	*	The Reaction class is used to define all responses obtained due to events
	*	It inherits from Action list class
	*/
	class Reaction : public ActionList, public EventSubscriber
	{
		RTTI_DECLARATIONS(Reaction, ActionList)

	public:
		//!Defaulted Constructor & Destructor
		/*!
		*	The constructer, copy constructor and virtual destructor are defaulted
		*/
		virtual ~Reaction() = default;
		Reaction(const Reaction &) = default;
		Reaction & operator=(const Reaction &) = default;

		//!Move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		Reaction(Reaction && rhs);
		//!Move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		Reaction & operator=(Reaction && rhs);

		//!Action's pure virtual Update function
		/*!
		*	Function that is called each frame from its parent
		*/
		virtual void Update(WorldState & worldState) = 0;

		//!Notify function
		/*!
		*	pure vertual function that is called whrn the event to ehich this is subscribed to is fired
		*/
		virtual void Notify(EventPublisher & publisher) = 0;

	protected:
		//!Parameterised constructor
		/*!
		*	Constructor used by derived class to be initialised with type ID
		*/
		Reaction(uint64_t typeID);
	};
}