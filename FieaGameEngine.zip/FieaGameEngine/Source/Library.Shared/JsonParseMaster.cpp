#include "pch.h"
#include <fstream>
#include "JsonParseMaster.h"
#include "IJsonParseHelper.h"
#include <algorithm>
#include <iterator>

using namespace FieaGameEngine;

RTTI_DEFINITIONS(JsonParseMaster::SharedData);

JsonParseMaster::SharedData::SharedData()
	:mDepth(0), mParseMaster(nullptr)
{
}

void JsonParseMaster::SharedData::SetJsonParseMaster(JsonParseMaster * parseMaster)
{
	if (parseMaster != nullptr)
	{
		mParseMaster = parseMaster;
	}
}

JsonParseMaster * FieaGameEngine::JsonParseMaster::SharedData::GetJsonParseMaster()
{
	return mParseMaster;
}

void FieaGameEngine::JsonParseMaster::SharedData::IncrementDepth()
{
	++mDepth;
}

void FieaGameEngine::JsonParseMaster::SharedData::DecrementDepth()
{
	if (mDepth > 0)
	{
		--mDepth;
	}
}

uint32_t FieaGameEngine::JsonParseMaster::SharedData::GetDepth()
{
	return mDepth;
}

JsonParseMaster::JsonParseMaster(SharedData & sharedData)
	:mFileName(), mHelpersVector(), mSharedData(&sharedData), mIsClone(false)
{
	mSharedData->SetJsonParseMaster(this);
}

JsonParseMaster * FieaGameEngine::JsonParseMaster::Clone()
{
	SharedData *cloneShare = mSharedData->Clone();
	JsonParseMaster *clone = new JsonParseMaster(*cloneShare);
	cloneShare->SetJsonParseMaster(clone);

	for (auto & value : mHelpersVector)
	{
		clone->AddHelper(*(value->Clone()));
	}

	clone->mIsClone = true;

	return clone;
}

bool FieaGameEngine::JsonParseMaster::IsClone() const
{
	return mIsClone;
}

void JsonParseMaster::AddHelper(IJsonParseHelper & parseHelper)
{
	if (mIsClone)
	{
		throw exception("Unable to add helpers to clone");
	}
	mHelpersVector.PushBack(&parseHelper);
}

void JsonParseMaster::RemoveHelper(IJsonParseHelper & parseHelper)
{
	if (mIsClone)
	{
		throw exception("Unable to remove helpers from clone");
	}
	mHelpersVector.Remove(&parseHelper);
}

void JsonParseMaster::Parse(const std::string & buffer)
{
	if (!buffer.empty())
	{
		stringstream inputStringStream;
		inputStringStream << buffer;
		Parse(inputStringStream);
	}
}

void JsonParseMaster::Parse(stringstream & inputStream)
{
	if (!inputStream.fail())
	{
		Json::Value jsonObject;
		inputStream >> jsonObject;
		CallHandlers(jsonObject);
	}
}

void FieaGameEngine::JsonParseMaster::ParseFromFile(const std::string & fileName)
{
	mFileName = fileName;
	ifstream inputFileStream(mFileName, ifstream::binary);
	
	if (inputFileStream.fail())
	{
		throw exception("Unable to find file");
	}

	stringstream inputStream;
	inputStream << inputFileStream.rdbuf();
	Parse(inputStream);
}

std::string FieaGameEngine::JsonParseMaster::GetFileName()
{
	return mFileName;
}

JsonParseMaster::SharedData * JsonParseMaster::GetSharedData()
{
	return mSharedData;
}

void JsonParseMaster::SetSharedData(SharedData & sharedData)
{
	if (mIsClone)
	{
		throw exception("Unable to add helpers to clone");
	}

	mSharedData = &sharedData;

}

void FieaGameEngine::JsonParseMaster::Reset()
{
	mSharedData->Initialize();

	for (auto & value : mHelpersVector)
	{
		value->Initialize();
	}
}

JsonParseMaster::~JsonParseMaster()
{
	if (mIsClone)
	{
		delete mSharedData;
		for (auto & value : mHelpersVector)
		{
			delete value;
		}
	}
}

void FieaGameEngine::JsonParseMaster::CallHandlers(Json::Value currentJsonObject)
{
	Json::Value::Members jsonValues = currentJsonObject.getMemberNames();
	bool startParseFlag = false;
	for (auto & key : jsonValues)
	{
		if (currentJsonObject[key].isObject())
		{
 			mSharedData->IncrementDepth();

			for (auto & helper : mHelpersVector)
			{
				if (helper->StartHandler(key, currentJsonObject[key], *mSharedData))
				{
					startParseFlag = true;
					break;
				}
			}

			CallHandlers(currentJsonObject[key]);
			mSharedData->DecrementDepth();
		}
		else
		{
			for (auto & helper : mHelpersVector)
			{
				if (helper->DataHandler(key, currentJsonObject[key], *mSharedData))
					break;
			}
		}

		if (startParseFlag)
		{
			for (auto & helper : mHelpersVector)
			{
				if (helper->EndHandler(*mSharedData))
					break;
			}
		}
	}
}
