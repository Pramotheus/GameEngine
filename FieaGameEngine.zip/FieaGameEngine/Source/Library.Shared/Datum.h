#pragma once
#pragma warning (push)
#pragma warning (disable : 4201)
#include "glm\glm.hpp"
#include "glm\gtx\string_cast.hpp"
#pragma warning (pop)
#include "HashMap.h"

namespace FieaGameEngine
{
	typedef RTTI* RTTIPointer;								//!< Type defenition for Pointer to RTTI pointers

	class Scope;

	//!Datum Class
	/*!
	*	The Datum class holds pointer to a array of homogenious type of objects.
	*	It can have objects of any one of the mentioned Datum Value types.
	*/
	class Datum final
	{
	public:
		//!Datum type enumeration
		/*!
		*	The Enum holds various types of data that can be stored in the Datum
		*	It also has a first Unknown element and last end value element as place holders to mark index
		*/
		enum class DatumType
		{
			Unknown,
			Integer,
			Float,
			Vector,
			Matrix,
			Table,
			String,
			Pointer,
			EndValue
		};

		HashMap<string, Datum::DatumType> mDatumTypeMap = { { "Unknown" , Datum::DatumType::Unknown },{ "Integer", Datum::DatumType::Integer },
		{ "Float", Datum::DatumType::Float },{ "Vector", Datum::DatumType::Vector },{ "Matrix", Datum::DatumType::Matrix },
		{ "Table", Datum::DatumType::Table },{ "String", Datum::DatumType::String },{ "Pointer", Datum::DatumType::Pointer, } };

		//!Datum default constructor
		/*!
		*	Initializes the data members to zero but does not allocate memory for data
		*/
		Datum();
		//!Datum copy constructor
		/*!
		*	Initialises current object data to default and copy data from other object
		*	Performs call to the copy assignment operator
		*/
		Datum(const Datum & copyDatum);
		//!Datum move constructor
		/*!
		*	Similar to copy constructor but after copy data, nulls out the other object's data
		*	Performs call to the move assignment operator
		*/
		Datum(Datum && moveDatum);


		//!Datum int scalar copy constructor
		/*!
		*	copys the int value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(int32_t value);
		//!Datum float scalar copy constructor
		/*!
		*	copys the float value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(float value);
		//!Datum glm::Vector scalar copy constructor
		/*!
		*	copys the Vector value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(const glm::vec4 & value);
		//!Datum glm::matrix scalar copy constructor
		/*!
		*	copys the matrix value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(const glm::mat4x4 & value);
		//!Datum Table (scope pointer) scalar copy constructor
		/*!
		*	copys the Table value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(Scope* & value);
		//!Datum string scalar copy constructor
		/*!
		*	copys the string value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(const std::string & value);
		//!Datum RTTI pointer scalar copy constructor
		/*!
		*	copys the RTTI pointer value as the first element of the array
		*	Performs call to the copy assignment operator
		*/
		Datum(RTTIPointer & value);

		//!Datum Type methiod
		/*!
		*	Returns the Datum's Type
		*/
		DatumType Type() const;
		//!Datum  set Type methiod
		/*!
		*	Sets the Datum type if it has not already been set
		*/
		void SetType(DatumType type);
		//!Datum  size methiod
		/*!
		*	Returns number of elements in the datum
		*/
		uint32_t Size() const;
		//!Datum set size methiod
		/*!
		*	Sets the Datum's size equal to the size speified and shrinks capacity to fit it
		*/
		void SetSize(uint32_t newSize);
		//!Datum Reserve method
		/*!
		*	Allocates memory for internall Datums based on the requested capacity passed
		*/
		void Reserve(uint32_t newCapacity);
		//!Datum clear methiod
		/*!
		*	clears the contenet of the datum in case of internally stoored datums
		*	Does not work for externally stored datums
		*/
		void Clear();
		
		//!Datum set storage integer method
		/*!
		*	Used for defining externally stored integer datums
		*	Memory is not allocated for externally stored Datums
		*	Holds a pointer to memory location of already existing array
		*/
		void SetStorage(int32_t * inputArray, uint32_t numberOfElements);
		//!Datum set storage float method
		/*!
		*	Used for defining externally stored float datums
		*	Memory is not allocated for externally stored Datums
		*	Holds a pointer to memory location of already existing array
		*/
		void SetStorage(float * inputArray, uint32_t numberOfElements);
		//!Datum set storage glm::vector method
		/*!
		*	Used for defining externally stored vector datums
		*	Memory is not allocated for externally stored Datums
		*	Holds a pointer to memory location of already existing array
		*/
		void SetStorage(glm::vec4 * inputArray, uint32_t numberOfElements);
		//!Datum set storage glm::matrix method
		/*!
		*	Used for defining externally stored matrix datums
		*	Memory is not allocated for externally stored Datums
		*	Holds a pointer to memory location of already existing array
		*/
		void SetStorage(glm::mat4x4 * inputArray, uint32_t numberOfElements);
		//!Datum set storage string method
		/*!
		*	Used for defining externally stored string datums
		*	Memory is not allocated for externally stored Datums
		*	Holds a pointer to memory location of already existing array
		*/
		void SetStorage(std::string * inputArray, uint32_t numberOfElements);
		//!Datum set storage RTTI pointer method
		/*!
		*	Used for defining externally stored RTTI pointer datums
		*	Memory is not allocated for externally stored Datums
		*	Holds a pointer to memory location of already existing array
		*/
		void SetStorage(RTTIPointer * inputArray, uint32_t numberOfElements);

		//!Datum pop back method
		/*!
		*	Used for removing the last element stored in the array
		*	Can not be used on externally stored Datums
		*/
		void PopBack();

		//!Datum int push back method
		/*!
		*	Used for adding the passed in int value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(int32_t value);
		//!Datum float push back method
		/*!
		*	Used for adding the passed in float value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(float value);
		//!Datum glm::vector(4) push back method
		/*!
		*	Used for adding the passed in vector value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(const glm::vec4 & value);
		//!Datum glm::matrix(4x4) push back method
		/*!
		*	Used for adding the passed in matrix value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(const glm::mat4x4 & value);
		//!Datum scope push back method
		/*!
		*	Used for adding the passed in scope pointer value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(Scope* const & value);
		//!Datum string push back method
		/*!
		*	Used for adding the passed in string value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(const std::string & value);
		//!Datum RTTI pointer push back method
		/*!
		*	Used for adding the passed in RTTI pointer value as the last element of the array
		*	Can not be used on externally stored Datums
		*/
		void PushBack(RTTIPointer & value);

		//!Datum set int value method
		/*!
		*	Used for setting int data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(int32_t value, uint32_t index = 0);
		//!Datum set float value method
		/*!
		*	Used for setting float data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(float value, uint32_t index = 0);
		//!Datum set glm::vector(4) value method
		/*!
		*	Used for setting vector data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(const glm::vec4 & value, uint32_t index = 0);
		//!Datum set glm::matrix(4x4) value method
		/*!
		*	Used for setting matrix data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(const glm::mat4x4 & value, uint32_t index = 0);
		//!Datum set scope pointer value method
		/*!
		*	Used for setting scope table data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(Scope* const & value, uint32_t index = 0);
		//!Datum set string value method
		/*!
		*	Used for setting string data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(const std::string & value, uint32_t index = 0);
		//!Datum set RTTI pointer value method
		/*!
		*	Used for setting RTTI pointer data at the specified index on the array
		*	Can not allocated new space in the array or increase the size
		*/
		void Set(RTTIPointer value, uint32_t index = 0);

		//!Datum templated Get method
		/*!
		*	Used for getting data at secified index from the Datum array
		*	Does not have default template and only specialised for DatumType values
		*/
		template <typename T>
		T & Get(uint32_t index = 0);

		//!Datum set from string method
		/*!
		*	Used for getting data in form of string and storing appropriate data type after conversion
		*	Does not work if the type has not already been set
		*	Does not work for RTTI pointer type
		*	Behaves similar to set method and can not increase size
		*/
		void SetFromString(std::string inputString, uint32_t index = 0);
		//!Datum To string method
		/*!
		*	Used for converting the data stored at the specified index to string and returning it to user
		*	Behaves similar to get function but returns data in std::string format
		*/
		std::string ToString(uint32_t index = 0);

		//!Datum assignement operator
		/*!
		*	Used for assigning data from one datum to other datum
		*	Does a deep copy if the RHS datum is a internal datum
		*	If the RHS datum is a external datum makes the pointer point to the external datum's data
		*/
		Datum & operator=(const Datum & copyDatum);
		//!Datum move operator
		/*!
		*	Used for moving data from one datum to other
		*	 works similar to assignement operator but nulls out data in the RHS Datum
		*/
		Datum & operator=(Datum && moveDatum);

		//!Datum scalar integer assignement operator
		/*!
		*	Used for assigning int data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		int32_t & operator=(int32_t copyInt);
		//!Datum scalar float assignement operator
		/*!
		*	Used for assigning float data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		float & operator=(float copyFloat);
		//!Datum scalar glm::vector(4) assignement operator
		/*!
		*	Used for assigning vector data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		glm::vec4 & operator=(const glm::vec4 & copyVector);
		//!Datum scalar glm::matrix(4x4) assignement operator
		/*!
		*	Used for assigning matrix data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		glm::mat4x4 & operator=(const glm::mat4x4 & copyMatrix);
		//!Datum scalar scope assignement operator
		/*!
		*	Used for assigning scope data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		Scope* & operator=(Scope* const & copyScope);
		//!Datum scalar string assignement operator
		/*!
		*	Used for assigning string data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		std::string & operator=(const std::string & copyString);
		//!Datum scalar RTTI pointer assignement operator
		/*!
		*	Used for assigning RTTI pointer data the first element of the datum
		*	performs a pushback if the datum has 0 elements
		*/
		RTTIPointer & operator=(RTTIPointer copyRTTIPointer);

		//!Datum equality operator
		/*!
		*	Used for checking for equality between two datums
		*/
		bool operator==(const Datum & otherDatum) const;
		//!Datum integer equality operator
		/*!
		*	Used for checking for equality between first element in the integer array and rhs element
		*/
		bool operator==(int32_t otherInt) const ;
		//!Datum float equality operator
		/*!
		*	Used for checking for equality between first element in the float array and rhs element
		*/
		bool operator==(float otherFloat) const ;
		//!Datum glm::vector(4) equality operator
		/*!
		*	Used for checking for equality between first element in the vector array and rhs element
		*/
		bool operator==(const glm::vec4 & otherVector) const;
		//!Datum glm::matrix(4x4) equality operator
		/*!
		*	Used for checking for equality between first element in the matrix array and rhs element
		*/
		bool operator==(const glm::mat4x4 & otherMatrix) const;
		//!Datum string equality operator
		/*!
		*	Used for checking for equality between first element in the string array and rhs element
		*/
		bool operator==(Scope* const & otherScope) const;
		//!Datum string equality operator
		/*!
		*	Used for checking for equality between first element in the string array and rhs element
		*/
		bool operator==(const std::string & otherString) const;
		//!Datum RTTI pointer equality operator
		/*!
		*	Used for checking for equality between first element in the RTTI pointer array and rhs element
		*/
		bool operator==(RTTIPointer otherRTTIPointer) const;

		//!Datum inequality operator
		/*!
		*	Used for checking for inequality between two datums
		*	Returns inverse of equality operator
		*/
		bool operator!=(const Datum & otherDatum) const;
		//!Datum integer inequality operator
		/*!
		*	Used for checking for inequality between first element in the integer array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(int32_t otherInt) const;
		//!Datum float inequality operator
		/*!
		*	Used for checking for inequality between first element in the float array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(float otherFloat) const;
		//!Datum glm::vector(4) inequality operator
		/*!
		*	Used for checking for inequality between first element in the vector array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(const glm::vec4 & otherVector) const;
		//!Datum glm::matrix(4x4) inequality operator
		/*!
		*	Used for checking for inequality between first element in the matrix array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(const glm::mat4x4 & otherMatrix) const;
		//!Datum RTTI pointer inequality operator
		/*!
		*	Used for checking for inequality between first element in the RTTI pointer array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(Scope* const & otherScope) const;
		//!Datum string inequality operator
		/*!
		*	Used for checking for inequality between first element in the string array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(const std::string & otherString) const;
		//!Datum RTTI pointer inequality operator
		/*!
		*	Used for checking for inequality between first element in the RTTI pointer array and rhs element
		*	Returns the inverse of equality operatior
		*/
		bool operator!=(RTTIPointer otherRTTIPointer) const;

		bool Remove(const uint32_t & index);

		Scope& operator[](std::uint32_t index);

		//!Datum destructor
		/*!
		*	Clears out the datum if it has any data
		*	Frees the memory if it was a interally stored datum
		*/
		~Datum();

	private:
		//!Datum Values Union
		/*!
		*	The Union holds the list of data type pointers that are used by the Datum class
		*/
		union DatumValues
		{
			int32_t* integerPointer;
			float* floatPointer;
			glm::vec4 * vectorPointer;
			glm::mat4x4 * matrixPointer;
			Scope** scopePointer;
			std::string * stringPointer;
			RTTIPointer * rttiPointer;
			void * voidPointer;									//!< Void pointer present for internal use and can not be used to define Datum of void pointer type
		};

		DatumValues mData;									//!< Union pointer to the data stored
		DatumType mType;									//!< Type of elements stored in the Datum
		uint32_t mSize;										//!< Number of elements stored in the Datum
		uint32_t mCapacity;									//!< Memory allocated according to number of elements that can be stored at this time
		bool mIsInternal;									//!< Flag for specifiying type of datum - internal or external
	};
}
