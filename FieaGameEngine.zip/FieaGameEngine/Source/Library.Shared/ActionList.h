#pragma once
#include "Action.h"

namespace FieaGameEngine
{
	//!ActionList Class
	/*!
	*	The Action list class is used hold a list of actions under one container
	*	It inherits from action class
	*/
	class ActionList : public Action
	{
		RTTI_DECLARATIONS(ActionList, Action)

	public:
		//!Default constructor
		/*!
		*	Initialises the member variables for the class
		*/
		ActionList();
		
		ActionList(const ActionList &) = delete;
		ActionList & operator=(const ActionList &) = delete;

		//!Action List move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		ActionList(ActionList && moveActionList);

		//!Action List move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		ActionList & operator=(ActionList && moveActionList);

		//!Action List Update function
		/*!
		*	Function that is called each frame from its parent
		*	Goes through each action on the list and calls update on them
		*/
		virtual void Update(WorldState & worldState);

		//!Action List Get Actions member function
		/*!
		*	function used to return the datum holding all actions
		*/
		Datum & GetActions();
		//!Action List add Actions membe function
		/*!
		*	function used to add actions to the list of actions
		*/
		void AddActions(Action & childAction);
		//!Action List Create Action member function
		/*!
		*	Function used to create a new Action and attach to curent Action List
		*	Returns a pointer to created entity
		*/
		Action * CreateActions(const std::string & actionClassName, const std::string & actionInstanceName);

		//!Virtual Destructor
		/*!
		*	defaul Virtual destructor for all classes that can derive from this class
		*/
		virtual ~ActionList();

	protected:
		//!Parameterised constructor
		/*!
		*	Constructor used by derived class to be initialised with type ID
		*/
		ActionList(uint64_t typeID);

	private:
		//!Action List Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Action List update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();
	};

	ConcreteFactory(ActionList, Action)
}
