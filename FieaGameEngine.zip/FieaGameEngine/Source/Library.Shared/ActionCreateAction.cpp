#include "pch.h"
#include "ActionCreateAction.h"
#include "ActionList.h"
#include "Entity.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(ActionCreateAction);

ActionCreateAction::ActionCreateAction()
	:Action(TypeIdInstance()), mNewActionClass(), mNewActionName()
{
	InitializeMembers(TypeIdInstance());
}

ActionCreateAction::ActionCreateAction(ActionCreateAction && rhs)
	: Action(std::move(rhs)), mNewActionClass(std::move(rhs.mNewActionClass)), mNewActionName(std::move(rhs.mNewActionName))
{
	UpdateMembers();
}

ActionCreateAction & ActionCreateAction::operator=(ActionCreateAction && rhs)
{
	if (this != &rhs)
	{
		Action::operator=(std::move(rhs));
		mNewActionClass = std::move(rhs.mNewActionClass);
		mNewActionName = std::move(rhs.mNewActionName);

		UpdateMembers();
	}
	return *this;
}

void FieaGameEngine::ActionCreateAction::Update(WorldState & worldState)
{
	worldState.CurrentAction = this;

	Scope *parent = GetParent();
	if (parent != nullptr)
	{
		if (parent->Is(ActionList::TypeIdClass()))
		{
			static_cast<ActionList*>(parent)->CreateActions(mNewActionClass, mNewActionName);
		}
		else
		{
			assert(parent->Is(Entity::TypeIdClass()));
			static_cast<Entity*>(parent)->CreateAction(mNewActionClass, mNewActionName);
		}
	}
	
	worldState.CurrentAction = nullptr;
}

ActionCreateAction::~ActionCreateAction()
{
}

void FieaGameEngine::ActionCreateAction::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "NewActionClass"s, &mNewActionClass, 1);
	SetExternalAttributes(typeID, "NewActionName"s, &mNewActionName, 1);
}

void FieaGameEngine::ActionCreateAction::UpdateMembers()
{
	(*this)["NewActionClass"s].SetStorage(&mNewActionClass, 1);
	(*this)["NewActionName"s].SetStorage(&mNewActionName, 1);
}
