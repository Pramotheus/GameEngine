#include "pch.h"
#include "IfAction.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(IfAction)

IfAction::IfAction()
	:ActionList(TypeIdInstance()), mCondition(0)
{
	InitializeMembers(TypeIdInstance());
}

IfAction::IfAction(IfAction && moveIfAction)
	: ActionList(std::move(moveIfAction)), mCondition(std::move(moveIfAction.mCondition))
{
	UpdateMembers();
}

IfAction & FieaGameEngine::IfAction::operator=(IfAction && moveIfAction)
{
	if (this != &moveIfAction)
	{
		ActionList::operator=(std::move(moveIfAction));
		mCondition = std::move(moveIfAction.mCondition);
		UpdateMembers();
	}
	return *this;
}

Action * FieaGameEngine::IfAction::GetPassedActions()
{
	Datum &actionDatum = GetActions();
	if (mCondition == 0)
	{
		return actionDatum.Get<Scope*>(0)->As<Action>();
	}
	else
	{
		return actionDatum.Get<Scope*>(1)->As<Action>();;
	}
}

void FieaGameEngine::IfAction::Update(WorldState & worldState)
{
	worldState.CurrentAction = this;

	GetPassedActions()->Update(worldState);
	
	worldState.CurrentAction = nullptr;
}

IfAction::~IfAction()
{
}

void FieaGameEngine::IfAction::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Condition"s, &mCondition, 1);
}

void FieaGameEngine::IfAction::UpdateMembers()
{
	(*this)["Condition"s].SetStorage(&mCondition, 1);
}
