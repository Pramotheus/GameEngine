#pragma once
#include "Attributed.h"

namespace FieaGameEngine
{
	class World;

	//!EventMessageAttributed Class
	/*!
	*	The EventMessageAttributed class is as a message used as payload for the events
	*	It inherits from Attributed class
	*/
	class EventMessageAttributed : public Attributed
	{
		RTTI_DECLARATIONS(EventMessageAttributed, Attributed)
	public:
		//!Defaulted Constructor & Destructor
		/*!
		*	The constructer, copy constructor and virtual destructor are defaulted
		*/
		EventMessageAttributed();
		~EventMessageAttributed() = default;
		EventMessageAttributed(const EventMessageAttributed &) = delete;
		EventMessageAttributed & operator=(const EventMessageAttributed &) = delete;
		//!Move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		EventMessageAttributed(EventMessageAttributed && rhs);
		//!Move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		EventMessageAttributed & operator=(EventMessageAttributed && rhs);

		//!GetSubtype method
		/*!
		*	Method used to get the subtype of message in event
		*/
		const string & GetSubtype() const;
		//!GetWorld method
		/*!
		*	Method used to get the current world object
		*/
		World & GetWorld() const;
		//!setSubtype method
		/*!
		*	Method used to set the subtype of message in event
		*/
		void SetSubtype(string & subtype);
		//!SetWorld method
		/*!
		*	Method used to set the current world object
		*/
		void SetWorld(World & world);

	private:
		//!Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		string mSubtype;											//Subtype used to specify the type of message on the event
		RTTI* mWorldPointer;										//Pointer to world object
	};
}

