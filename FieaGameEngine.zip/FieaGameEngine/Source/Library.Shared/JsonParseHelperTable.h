#pragma once
#include <stack>
#include "Scope.h"
#include "IJsonParseHelper.h"


namespace FieaGameEngine
{
	//!Json Parse Helper Class for Scopes
	/*!
	*	Used for parsing data into scopes or table data
	*	Called from parse master with suitable json values
	*	Inherits from the abstract helper class
	*/
	class JsonParseHelperTable final : public IJsonParseHelper
	{
	public:
		//!Shared Table Data Class
		/*!
		*	Used for passing scope data between various parse helpers
		*	Holds the final output object after parsing data
		*	Can work with JsonParseHelperTable class object
		*	Inherits from shared data abstract class
		*/
		class SharedTableData final : public JsonParseMaster::SharedData
		{
			RTTI_DECLARATIONS(SharedTableData, JsonParseMaster::SharedData)

			friend JsonParseHelperTable;

		public:
			//!Shared Table Data default constructor
			/*!
			*	It is defaulted to use compiler proveded version
			*/
			SharedTableData() = default;

			//!Clone member function
			/*!
			*	Creates a shared Table Data value with same value as current object and return it with master parses set to null
			*/
			virtual SharedTableData* Clone();
			//!Initialize member function
			/*!
			*	Used to initialize any state variables the sharded data hold
			*/
			virtual void Initialize();
			//!SetScope member function
			/*!
			*	Used to initialize scope pointer to appropriate scope
			*/
			void SetScope(Scope & baseScope);
			//!Get Scope member function
			/*!
			*	returns the currently stored scope pointer
			*/
			Scope * GetScope();

			//!Destructor
			/*!
			*	Deletes the contained data if the Table is a clone
			*/
			~SharedTableData();

		private:
			Scope * mScope {nullptr};								//!< Pointer to Scope that is currently being used, defauled to null
			bool mIsClone {false};									//!< Flag to specify if the current object is a clone
		};

		//!Default constructor
		/*!
		*	Initialises the member variables to default values
		*/
		JsonParseHelperTable();

		//!Initialize member function
		/*!
		*	Used to clear the hash map of currently read values
		*/
		virtual void Initialize() override;

		//!Data handler member function
		/*!
		*	Takes care of the gett indivijual values of dataums storing of data passed in from parse master
		*	Returns true if Able to handle the data
		*/
		virtual bool DataHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData) override;
		//!Start handler member function
		/*!
		*	Takes care of the getting the key for datums and storing in hashmap
		*	In case of nested scopes, appends a scope
		*	Returns true if Able to handle the data
		*/
		virtual bool StartHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData)  override;
		//!End handler member function
		/*!
		*	Takes care of appending a new dataum to the scoepe and addedng the obtained data
		*	Returns true if Able to handle the data
		*/
		virtual bool EndHandler(const JsonParseMaster::SharedData & sharedData)  override;

		//!Clone member function
		/*!
		*	Used for creating a copy of itself on the heap and return a pointer to the created helper
		*/
		virtual JsonParseHelperTable* Clone() override;

		//!destructor
		/*!
		*	frees the memory for the member variables
		*/
		~JsonParseHelperTable();

	private:
		SharedTableData * mTableSharedData;							//!< Pointer to currently used shared data object
		stack<HashMap<string, Json::Value>> mData;					//!< Hashmap holding the currently read values as a buffer
	};
}
