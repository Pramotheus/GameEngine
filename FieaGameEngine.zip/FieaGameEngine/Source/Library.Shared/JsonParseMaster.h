#pragma once
#include "RTTI.h"
#include <cstdint>
#include <json/json.h>
#include "Vector.h"

namespace FieaGameEngine
{
	class IJsonParseHelper;

	//!Json Parse Master Class
	/*!
	*	Used for getting data from Json script interprit it through Json.cpp and store to objects using the helper functions
	*	Does not handle storing of data on object directly, uses handlers and hence unaweare of actual parsing data
	*/
	class JsonParseMaster final
	{
	public:
		//!Shared Data Class
		/*!
		*	Used for passing between various parse helpers with object to store data in
		*	Holds the final output object after parsing data
		*	Used for deriving other shared data classes for various types
		*/
		class SharedData : public RTTI
		{
			RTTI_DECLARATIONS(SharedData, RTTI)

		public:
			//!Shared Data default constructor
			/*!
			*	Initialises the base shared class (this) variables
			*/
			SharedData();

			//!Clone member function
			/*!
			*	Provide a default clone function implementation for derived classes without clone function'
			*	Creates a shared Data value with same value as current object and return it with master parses set to null
			*/
			virtual SharedData* Clone() = 0;

			//!Initialize member function
			/*!
			*	Used to initialize any state variables the sharded data hold
			*/
			virtual void Initialize() = 0;

			//!Set parse master function
			/*!
			*	Used to set the parse master for the object
			*/
			void SetJsonParseMaster(JsonParseMaster * parseMaster);
			
			//!Get parse master function
			/*!
			*	Used to retrive the parse master of the object
			*/
			JsonParseMaster * GetJsonParseMaster();
			
			//!Increment Depth function
			/*!
			*	Increase depth of parse by one
			*/
			void IncrementDepth();

			//!Decrement Depth function
			/*!
			*	Decrease depth of parse by one
			*/
			void DecrementDepth();

			//!Get Depth function
			/*!
			*	Returns the current depth
			*/
			uint32_t GetDepth();

			//!Virtual destructor
			/*!
			*	Defaulted virtual destructor
			*/
			virtual ~SharedData() = default;

		protected:
			uint32_t mDepth;												//!< Depth variable for holding current level during parse
			JsonParseMaster* mParseMaster;									//!< Pointer to parse master of the shared data object
		};

		//!Json Parse Master Constructor
		/*!
		*	Accepts a shared data object and sets it to be the current object's shared data
		*/
		JsonParseMaster(SharedData & sharedData);

		//!Clone member function
		/*!
		*	Creates a heap allocated object with values same as the current object and returns a pointer to it
		*	Creates shared data clone as well as helper clones and hence the clone object owns the helper objects
		*/
		JsonParseMaster* Clone();

		//!Clone validation function
		/*!
		*	Used for checking if the current object is clone or not
		*	Returns true if clone
		*/
		bool IsClone() const;

		//!Add Helper function
		/*!
		*	Used for addeding json parse helper objects into the vector of parse helpers
		*/
		void AddHelper(IJsonParseHelper& parseHelper);
		
		//!Remove Helper function
		/*!
		*	Used for removing the passed in json parse helper object from the vector of parse helpers
		*/
		void RemoveHelper(IJsonParseHelper& parseHelper);

		//!Parse function
		/*!
		*	Used for Parsing the Json script passed in the form of a std::string
		*	Calls Data handler helper function to parse the data
		*/
		void Parse(const std::string & buffer);

		//!Parse function
		/*!
		*	Used for Parsing the Json script passed in the form of a std::string
		*	Calls Data handler helper function to parse the data
		*/
		void Parse(stringstream & inputStream);

		//!Parse From File function
		/*!
		*	Used for Parsing the Json script in file whose name is passed in the form of a std::string
		*	Calls Data handler helper function to parse the data
		*/
		void ParseFromFile(const std::string & fileName);

		//!Get File Name function
		/*!
		*	Used for getting the relative path to the file with the passed in file name
		*/
		std::string GetFileName();

		//!Get Shared Data function
		/*!
		*	Used for return a pointer to the current shared data object being used
		*/
		SharedData* GetSharedData();

		//!Set Shared Data function
		/*!
		*	Used for set the current shared data object to be used for parsing
		*/
		void SetSharedData(SharedData & sharedData);

		//!Reset helper function
		/*!
		*	Used for reset the helpers to its initial state
		*/
		void Reset();

		//!Json Parse Master Destructor
		/*!
		*	In case of current object, deletes all the owned handlers and shared data
		*/
		~JsonParseMaster();

	private:
		//!Data Handler Function
		/*!
		*	Used for calling the various parse handlers to handle the current Json Script
		*	Does a recursive call in case of nested Json objects
		*/
		void CallHandlers(Json::Value currentJsonObject);

		string mFileName;													//!< Json file currently beeing used
		Vector<IJsonParseHelper*> mHelpersVector;							//!< Vector of pointers to parse helpers available to parse data
		SharedData* mSharedData;											//!< Shared Data pointer used to pass between helpers and store data
		bool mIsClone;														//!< Identifier for checking if current object is a clone
		
	};
}
