#pragma once
namespace FieaGameEngine
{
	class EventPublisher;

	//!Event Subscriber Abstract Class
	/*!
	*	The class acts as an interface for all dubrcribers which would requie to get updates from events
	*/
	class EventSubscriber
	{
	public:

		//!Defaulted Constructor & Destructor
		/*!
		*	The constructer, copy constructor and virtual destructor are defaulted
		*/
		EventSubscriber() = default;
		EventSubscriber(const EventSubscriber &) = default;
		EventSubscriber& operator=(const EventSubscriber &) = default;
		virtual ~EventSubscriber() = default;

		//!Notify function
		/*!
		*	pure vertual function that is called whrn the event to ehich this is subscribed to is fired
		*/
		virtual void Notify(EventPublisher & publisher) = 0;
	};
}
