#include "pch.h"
#include "ReactionAttributed.h"
#include "World.h"
#include "Event.h"
#include "EventMessageAttributed.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(ReactionAttributed)

ReactionAttributed::ReactionAttributed()
	:Reaction(TypeIdInstance())
{
	InitializeMembers(TypeIdInstance());
	Event<EventMessageAttributed>::Subscribe(*this);
}

ReactionAttributed::ReactionAttributed(ReactionAttributed && rhs)
	:Reaction(move(rhs)), mSubtype(move(rhs.mSubtype))
{
	UpdateMembers();
	Event<EventMessageAttributed>::UnSubscribe(rhs);
	Event<EventMessageAttributed>::Subscribe(*this);
}

ReactionAttributed & FieaGameEngine::ReactionAttributed::operator=(ReactionAttributed && rhs)
{
	if (this != &rhs)
	{
		Reaction::operator=(move(rhs));
		mSubtype = move(rhs.mSubtype);

		UpdateMembers();

		Event<EventMessageAttributed>::UnSubscribe(rhs);
		Event<EventMessageAttributed>::Subscribe(*this);
	}
	return *this;
}

void FieaGameEngine::ReactionAttributed::Update(WorldState & worldState)
{
	worldState.CurrentAction = this;

	worldState.CurrentAction = nullptr;
}

void FieaGameEngine::ReactionAttributed::Notify(EventPublisher & publisher)
{
	Event<EventMessageAttributed> *eventHolder = publisher.As<Event<EventMessageAttributed>>();
	if (eventHolder != nullptr)
	{
		if (mSubtype == eventHolder->Message().GetSubtype())
		{
			Vector<pair<string, Datum>*> messageAuxilary = eventHolder->Message().GetAuxiliaryAttributes();

			for (auto & value : messageAuxilary)
			{
				if (value->second.Type() == Datum::DatumType::Table)
				{
					uint32_t size = value->second.Size();

					for(uint32_t i = 0; i < size; ++i)
					{
						Scope * tempScope = new Scope(value->second[i]);
						Adopt(*tempScope, value->first);
					}
				}
				else
				{
					AppendAuxiliaryAttribute(value->first) = value->second;
				}
			}

			Update(eventHolder->Message().GetWorld().GetWorldState());
		}
	}
}

void FieaGameEngine::ReactionAttributed::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Subtype", &mSubtype, 1);
}

void FieaGameEngine::ReactionAttributed::UpdateMembers()
{
	(*this)["Subtype"].SetStorage(&mSubtype, 1);
}
