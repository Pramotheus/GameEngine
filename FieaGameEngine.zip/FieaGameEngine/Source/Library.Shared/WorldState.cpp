#include "pch.h"
#include "WorldState.h"

using namespace FieaGameEngine;

GameTime & FieaGameEngine::WorldState::GetGameTime()
{
	return *mGameTime;
}

void FieaGameEngine::WorldState::SetGameTime(GameTime & gameTime)
{
	mGameTime = &gameTime;
}

void FieaGameEngine::WorldState::ThrowTrash()
{
	for (auto & value : mTrashBin)
	{
		delete value;
	}
	mTrashBin.Clear();
}

void FieaGameEngine::WorldState::CollectTrash(Scope *& trash)
{
	mTrashBin.PushBack(trash);
}
