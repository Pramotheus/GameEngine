#include "pch.h"
#include "ActionDeleteAction.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(ActionDeleteAction);

ActionDeleteAction::ActionDeleteAction()
	:Action(TypeIdInstance()), mDeleteActionName()
{
	InitializeMembers(TypeIdInstance());
}

ActionDeleteAction::ActionDeleteAction(ActionDeleteAction && rhs)
	: Action(std::move(rhs)), mDeleteActionName(std::move(rhs.mDeleteActionName))
{
	UpdateMembers();
}

ActionDeleteAction & ActionDeleteAction::operator=(ActionDeleteAction && rhs)
{
	if (this != &rhs)
	{
		Action::operator=(std::move(rhs));
		mDeleteActionName = std::move(rhs.mDeleteActionName);

		UpdateMembers();
	}
	return *this;
}


void FieaGameEngine::ActionDeleteAction::Update(WorldState & worldState)
{
	worldState.CurrentAction = this;
	Scope *currentScope = this;
	bool deletedAction = false;

	while (!deletedAction)
	{
		Scope *parent = currentScope->GetParent();
		if (parent != nullptr)
		{
			Datum* actionsDatum = parent->Find("Actions"s);
			if (actionsDatum == nullptr)
			{
				actionsDatum = parent->Find("ActionsList"s);
			}

			if (actionsDatum != nullptr)
			{
				for (uint32_t i = 0; i < actionsDatum->Size(); ++i)
				{
					if ((*actionsDatum)[i].As<Action>()->Name() == mDeleteActionName)
					{
						worldState.CollectTrash(actionsDatum->Get<Scope*>(i));
						deletedAction = true;
						break;
					}
				}
			}

			currentScope = parent;
		}
		else
			deletedAction = true;
	}

	worldState.CurrentAction = nullptr;
}

ActionDeleteAction::~ActionDeleteAction()
{
}

void FieaGameEngine::ActionDeleteAction::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "DeleteActionName", &mDeleteActionName, 1);
}

void FieaGameEngine::ActionDeleteAction::UpdateMembers()
{
	(*this)["DeleteActionName"].SetStorage(&mDeleteActionName, 1);
}
