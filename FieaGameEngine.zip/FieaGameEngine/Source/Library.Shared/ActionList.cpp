#include "pch.h"
#include "ActionList.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(ActionList);

ActionList::ActionList()
	:Action(TypeIdInstance())
{
	InitializeMembers(TypeIdInstance());
}

ActionList::ActionList(uint64_t typeID)
	:Action(typeID)
{
	InitializeMembers(typeID);
}

ActionList::ActionList(ActionList && moveActionList)
	: Action(std::move(moveActionList))
{
	UpdateMembers();
}

ActionList & FieaGameEngine::ActionList::operator=(ActionList && moveActionList)
{
	if (this != &moveActionList)
	{
		Action::operator=(std::move(moveActionList));
		UpdateMembers();
	}
	return *this;
}

void ActionList::Update(WorldState & worldState)
{
	worldState.CurrentAction = this;

	Datum actionDatum = GetActions();
	Scope *currentAction;
	uint32_t size = actionDatum.Size();

	for (uint32_t i = 0; i < size; ++i)
	{
		currentAction = actionDatum.Get<Scope*>(i);
		assert(currentAction->Is(Action::TypeIdClass()));
		static_cast<Action*>(currentAction)->Update(worldState);
	}

	worldState.CurrentAction = nullptr;
}

Datum & FieaGameEngine::ActionList::GetActions()
{
	return *Find("ActionsList"s);
}

void FieaGameEngine::ActionList::AddActions(Action & childAction)
{
	Adopt(childAction, "ActionsList"s);
}

void ActionList::InitializeMembers(uint64_t typeID)
{
	SetScope(typeID, "ActionsList"s);
}

void FieaGameEngine::ActionList::UpdateMembers()
{
}

Action * FieaGameEngine::ActionList::CreateActions(const std::string & actionClassName, const std::string & actionInstanceName)
{
	Action * createdAction = EngineFactory<Action>::Create(actionClassName);
	createdAction->SetName(actionInstanceName);
	AddActions(*createdAction);
	return createdAction;
}

ActionList::~ActionList()
{
}


