#include "pch.h"
#include "ActionEvent.h"
#include "World.h"
#include "EventMessageAttributed.h"

using namespace FieaGameEngine;
using namespace std;

RTTI_DEFINITIONS(ActionEvent)

ActionEvent::ActionEvent()
	:Action(TypeIdInstance()), mSubtype(), mDelay()
{
	InitializeMembers(TypeIdInstance());
}

ActionEvent::ActionEvent(ActionEvent && rhs)
	: Action(move(rhs)), mSubtype(move(rhs.mSubtype)), mDelay(move(rhs.mDelay))
{
	UpdateMembers();
}

ActionEvent & FieaGameEngine::ActionEvent::operator=(ActionEvent && rhs)
{
	if (this != &rhs)
	{
		Action::operator=(std::move(rhs));
		mSubtype = move(rhs.mSubtype);
		mDelay = move(rhs.mDelay);

		UpdateMembers();
	}
	return *this;
}

void FieaGameEngine::ActionEvent::Update(WorldState & worldState)
{
	worldState.CurrentAction = this;

	shared_ptr<Event<EventMessageAttributed>> eventPtr = make_shared<Event<EventMessageAttributed>>(Event<EventMessageAttributed>());
	EventMessageAttributed & message = eventPtr->Message();
	message.SetSubtype(mSubtype);
	message.SetWorld(*(worldState.CurrentWorld));

	Vector<pair<string, Datum>*> auxilary = GetAuxiliaryAttributes();

	for (auto & value : auxilary)
	{
		if (value->second.Type() == Datum::DatumType::Table)
		{
			uint32_t size = value->second.Size();

			for (uint32_t i = 0; i < size; ++i)
			{
				Scope * tempScope = new Scope(value->second[i]);
				message.Adopt(*tempScope, value->first);
			}
		}
		else
		{
			message.AppendAuxiliaryAttribute(value->first) = value->second;
		}
	}

	worldState.CurrentWorld->GetEventQueue().Enqueue(eventPtr, worldState.GetGameTime(),chrono::milliseconds(mDelay));

	worldState.CurrentAction = nullptr;
}

void FieaGameEngine::ActionEvent::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Subtype", &mSubtype, 1);
	SetExternalAttributes(typeID, "Delay", &mDelay, 1);
}

void FieaGameEngine::ActionEvent::UpdateMembers()
{
	(*this)["Subtype"].SetStorage(&mSubtype, 1);
	(*this)["Delay"].SetStorage(&mDelay, 1);
}
