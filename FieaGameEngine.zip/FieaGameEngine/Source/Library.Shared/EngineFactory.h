#pragma once
#include <gsl/gsl>
#include "HashMap.h"

namespace FieaGameEngine
{
	//!Engine Factory Class
	/*!
	*	The Engine factory class is a abstract class from which concrete factories for particular types are inherited from
	*	It has static functions that behave as a fuactory manager
	*/
	template <typename T>
	class EngineFactory
	{
	public:
		//!Engine Factory default constructor
		/*!
		*	The constructor is defaulted
		*/
		EngineFactory() = default;
		//!Engine Factory copy constructor
		/*!
		*	The constructor is defaulted
		*/
		EngineFactory(const EngineFactory &) = default;
		//!Engine Factory copy assignement operator
		/*!
		*	The operator is defaulted
		*/
		EngineFactory& operator=(const EngineFactory &) = default;

		//!Find memeber function
		/*!
		*	Function used to find a particular concrete factory pointer from list of concrete factories by using a string of class name as input
		*/
		static EngineFactory* Find(const std::string & className);
		//!Create memeber function
		/*!
		*	Function used to create a object of requested oject type using appropriate concrete factory refered by class name string as input
		*/
		static gsl::owner<T*> Create(const std::string & className);

		//!begin memeber function
		/*!
		*	Returns a iterator pointing to the first element of concrete factory list
		*/
		static typename HashMap<std::string, EngineFactory*>::Iterator begin();
		//!end memeber function
		/*!
		*	Returns a iterator pointing to the element after the last element of concrete factory list
		*/
		static typename HashMap<std::string, EngineFactory*>::Iterator end();
		//!Size memeber function
		/*!
		*	Returns the number of concrete factories stored in the list
		*/
		static uint32_t Size();

		//!Add memeber function
		/*!
		*	Adds the passed in concrete factory reference to its list of concrete factories
		*/
		static void Add(EngineFactory & concreteFactoryObject);
		//!Remove memeber function
		/*!
		*	Removes the passed in concrete factory reference from its list of concrete factories
		*/
		static void Remove(EngineFactory & concreteFactoryObject);

		//!Create pure virtual memeber function
		/*!
		*	Implemented in the concrete factories
		*	creates and returns a object of the appropriate concrete class' type
		*/
		virtual gsl::owner<T*> Create() = 0;
		//!Class Name pure virtual memeber function
		/*!
		*	Implemented in the concrete factories
		*	Returns the class name of the object type which can be created using the concrete factory
		*/
		virtual std::string ClassName() const = 0;

		//!Engine Factory virtual destructor
		/*!
		*	The destructor is defaulted
		*/
		virtual ~EngineFactory() = default;

	private:
		static HashMap<std::string, EngineFactory*> mFactoryList;
	};

}


//Concrete Factory Macro
/*!
*	The Macro is used to create a concrete class ath the place it is instanciated
*	It takes two parameters, the first is class of which type object has to be created and the second is its base class
*	Implements Create and ClassName functions
*	Objects auto adds during construction and removes itseld during destruction
*/
#define ConcreteFactory(ConcreteProductType, AbstractProductType)														\
class Concrete##ConcreteProductType##Factory: public FieaGameEngine::EngineFactory<AbstractProductType>					\
{																														\
	public:																												\
	Concrete##ConcreteProductType##Factory() { FieaGameEngine::EngineFactory<AbstractProductType>::Add(*this); }		\
	virtual gsl::owner<AbstractProductType*> Create() override	{ return new ConcreteProductType();}					\
	virtual std::string ClassName() const override { return std::string(#ConcreteProductType);}							\
	~Concrete##ConcreteProductType##Factory() { FieaGameEngine::EngineFactory<AbstractProductType>::Remove(*this); }	\
};

#include "EngineFactory.inl"