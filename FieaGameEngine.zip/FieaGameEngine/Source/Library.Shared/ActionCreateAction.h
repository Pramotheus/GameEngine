#pragma once
#include "Action.h"

namespace FieaGameEngine
{
	//!Action Create Action Class
	/*!
	*	The Action create action class is used to create new actions through script
	*	It inherits from action class
	*/
	class ActionCreateAction final : public Action
	{
		RTTI_DECLARATIONS(ActionCreateAction, Action)

	public:
		//!Default constructor
		/*!
		*	Initialises the member variables for the class
		*/
		ActionCreateAction();

		ActionCreateAction(const ActionCreateAction &) = delete;
		ActionCreateAction & operator=(const ActionCreateAction &) = delete;

		//!Move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		ActionCreateAction(ActionCreateAction && rhs);

		//!Move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		ActionCreateAction & operator=(ActionCreateAction && rhs);

		//!Update function
		/*!
		*	Function that is called each frame from its parent
		*	Creates a new action and appends it to the parent action list or entity
		*/
		void Update(WorldState& worldState) override;

		//!Default Destructor
		/*!
		*	Defaul destructor for destructing member variables, can be defaulted
		*/
		~ActionCreateAction();

	private:
		//!Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		string mNewActionClass;								//!< Member variable holding the name of class for the new action to create
		string mNewActionName;								//!< Member variable holding the name of new action to create
	};

	ConcreteFactory(ActionCreateAction, Action)
}

