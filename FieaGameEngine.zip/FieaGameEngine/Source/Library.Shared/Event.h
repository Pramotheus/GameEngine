#pragma once
#include "EventPublisher.h"
#include "EventSubscriber.h"

namespace FieaGameEngine
{
	//!Event Class
	/*!
	*	Templated class used to create actual events
	*	Derives from event publisher
	*/
	template <typename T>
	class Event : public EventPublisher
	{
		RTTI_DECLARATIONS(Event<T>, EventPublisher)										//RTTI Declaration

	public:
		//!Default constructor
		/*!
		*	Initialises the payload to be the passed in value
		*/
		Event();

		//!Defaulted Constructor & Destructor
		/*!
		*	The copy constructor, move constructor and virtual destructor are defaulted
		*/
		Event(const Event &) = default;
		Event(Event &&) = default;
		Event & operator=(const Event &) = default;
		Event & operator=(Event &&) = default;
		virtual ~Event() = default;

		//!Subscribe function
		/*!
		*	Function that is used to add the subscriber to the list of subscribers
		*/
		static void Subscribe(EventSubscriber & subscriber);
		//!UnSubscribe function
		/*!
		*	Function that is used to remove a subscriber from the list of subscribers
		*/
		static void UnSubscribe(EventSubscriber & subscriber);
		//!UnSubscribe All function
		/*!
		*	Function that is used to remove all subscriber from the list of subscribers (clear the list)
		*/
		static void UnSubscribeAll();
		//!Strink List function
		/*!
		*	Function that is used to shrink the capacity of the list equal to its size
		*/
		static void StrinkList();

		//!Message function
		/*!
		*	Function that is used to return the payload data that is stored
		*/
		T & Message();

	private:
		T mMessage;																					//!< Member variable holding the actual payload data
		static mutex mMutex;																		//!< Mutex variable to multi thread
		static Vector<gsl::not_null<EventSubscriber*>> mSubscriberList;								//!< static Member vector holding all subscribers to this type of events
	};	
}

#include "Event.inl"