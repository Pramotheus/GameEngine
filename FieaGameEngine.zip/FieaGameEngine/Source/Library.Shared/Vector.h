#pragma once
#include <cstdint>
#include <cstring>
#include <stdlib.h>

using namespace std;

namespace FieaGameEngine
{
	class Increment;
	//!Templated class for concurrent memeory storage (Vector)
	/*!
	The class is used for handiling data stored in the form of a array
	*/
	template <typename T>
	class Vector
	{
	public:
		//!Iterator class for iterating through the vector 
		/*!
		The class is used for iterating through the vector values, it holds index of the value in vector and a pointer to its owner
		*/
		class Iterator final
		{
		private:
			//!Iterator class parameterised constructor
			/*!
			Constructor used for initializing the Iterator class data members
			*/
			Iterator(const Vector & owner, uint32_t index = 0);

		public:
			friend Vector;

			//!Iterator class default constructor
			/*!
			Constructor used for initializing the Iterator class data members
			*/
			Iterator();

			//!Iterator class copy constructor
			/*!
			Constructor used for copy from other iterator object
			*/
			Iterator(const Iterator & otherIterator);

			//!Iterator relational equality operator overload
			/*!
			checks for one:one comeparison of iterators data members
			returns the bool based on comparison
			*/
			bool operator==(const Iterator& rhs) const;

			//!Iterator relational in-equality operator overload
			/*!
			checks for one:one comeparison of iterators data members
			returns the bool based on comparison (inverse of equality operator)
			*/
			bool operator!=(const Iterator& rhs) const;

			//!Iterator pre increment operator overload
			/*!
			move iterator to next vector value by increasing index and return the iterator
			*/
			Iterator & operator++();

			//!Iterator post increment operator overload
			/*!
			update index to next after returning current iterator value
			*/
			Iterator operator++(int);

			//!Iterator dereference operator overload
			/*!
			Makes the operand of the operator to point to the value stored in the vector at current index
			Returns an exception if there are no elements in the list
			can be used inside const functions
			*/
			const T & operator*() const;

			//!Iterator dereference operator overload
			/*!
			Makes the operand of the operator to point to the value stored in the vector at current index
			Returns an exception if there are no elements in the list
			*/
			T & operator*();

			//!Iterator assignment operator overload
			/*!
			used to copy from right side iterator object to left side iterator object
			*/
			Iterator operator=(const Iterator & otherIterator);

		private:
			uint32_t mIndex;											//!< Index to the content of data in vector class
			Vector *mOwner;												//!< vector class pointer variable used to set the owner vector
		};

		void ShrinkToFit();
		//!Vector class default constructor
		/*!
		Constructor used for initializing the Vector class data members
		*/
		explicit Vector(uint32_t capacity = 3);

		//!Vector class copy constructor
		/*!
		Constructor used for copy from other Vector object
		*/
		Vector(const Vector & otherVector);

		//!Vector class copy constructor
		/*!
		Constructor used for copy from other Vector object
		*/
		Vector(Vector && otherVector);

		//!Vector pop back function
		/*!
		deletes the last element from the front of the vector
		*/
		void PopBack();

		//!Vector push back function
		/*!
		Pushes the value passed in as arrgument to the back of the vector
		*/
		template <typename Functor = Increment>
		void PushBack(const T & pushItem);

		//!Vector clear function
		/*!
		It deletes all the elements present in the Vector and frees the memory
		*/
		void Clear();

		//!Vector Remove function
		/*!
		Deletes the first occurance of the element found in the vector
		*/
		bool Remove(const T & removeValue);

		//!Vector Remove function
		/*!
		Deletes the element found in the vector based on passed iterator
		*/
		void Remove(const Iterator & removeIterator);

		//!Vector Remove function
		/*!
		Deletes the elements within the mentioned range on the vector
		*/
		void Remove(const Iterator & removeStart, const Iterator & removeEnd);


		//!Vector front function
		/*!
		Returns a reference to the value stored as the first element from the front of the list
		Returns an exception if there are no elements in the list
		*/
		T& Front();

		//!Vector const front function
		/*!
		Returns a const reference to the value stored as the first element from the front of the list
		Returns an exception if there are no elements in the list
		Used within const functions
		*/
		const T& Front() const;

		//!Vector back function
		/*!
		Returns a reference to the value stored as the first element from the back of the list
		Returns an exception if there are no elements in the list
		*/
		T& Back();

		//!Vector const back function
		/*!
		Returns a const reference to the value stored as the first element from the back of the list
		Returns an exception if there are no elements in the list
		Used within const functions
		*/
		const T& Back() const;

		//!Vector Begin function
		/*!
		Returns a iterator with index to the first element of the list
		Returns an exception if there are no elements in the list
		*/
		Iterator begin() const;

		//!Vector Begin function
		/*!
		Returns a iterator with index to the first element of the list
		Returns an exception if there are no elements in the list
		Used within const functions
		*/

		Iterator end() const;

		//!Vector At function
		/*!
		Returns reference to the data at specified index passed in as argument
		Returns an exception if thepassed index is invalid
		*/
		T& At(const uint32_t & index);

		//!Vector const At function
		/*!
		Returns reference to the data at specified index passed in as argument
		Returns an exception if thepassed index is invalid
		Used within const functions
		*/
		const T& At(const uint32_t & index) const;

		//!Vector Find function
		/*!
		Returns a iterator pointing to the value passed in as reference
		Returns the end if it cant find mentioned value
		Used within const functions
		*/
		Iterator Find(const T & findValue) const;


		//!Vector is empty function
		/*!
		Returns true if there are no elements present in the list
		*/
		bool IsEmpty() const;

		//!Vector size function
		/*!
		Returns the number of elements present in the vector list
		*/
		uint32_t Size() const;

		//!SList Capacity function
		/*!
		Returns the number of elements that can be stored in the vector list (memory allocated)
		*/
		uint32_t Capacity() const;

		//!Vector At function
		/*!
		Returns reference to the data at specified index passed in as argument
		Returns an exception if thepassed index is invalid
		*/
		void Reserve(uint32_t capacity);

		//!Vector operator [] overload
		/*!
		Returns reference to the data at specified index passed in as argument
		Returns an exception if the passed index is invalid
		*/
		T& operator[](const uint32_t & index);

		//!Vector assignement oprator overload
		/*!
		performs a deep copy of the right hand side object
		returns the current object (this) for chanied assignements
		*/
		Vector & operator=(const Vector & otherVector);
		Vector & operator=(Vector && otherVector);

		//!Vector default destructor
		/*!
		Releases the memory of the stored list
		*/
		virtual ~Vector();

	private:
		uint32_t mCapacity;												//!< Unsigned int used for representing the maximum number of elements memory allocated 
		uint32_t mSize;													//!< Unsigned int used for representing the number of elements stored in the vector
		T* mData;														//!< Templated data pointer to hold the list of data in the vector
	};

	//!Increment functor for vector class
	/*!
	Used to define reserve strategy, can be overloaded by user for different reserve strategy
	*/
	class Increment
	{
	public:
		//!Increment class functer
		/*!
		Used for defining required reserve strategy for the vector
		pass in the current size and capacity of the vector, called from reserve function
		*/
		uint32_t operator()(uint32_t capacity, uint32_t size = 0) const;
	};
}

#include "Vector.inl"