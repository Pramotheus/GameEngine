#pragma once
#include <cstdint>

namespace FieaGameEngine
{
	//!Templated class for singly linked list
	/*!
		The class is used for handiling data stored in the form of a singly linked list 
	*/
	template <typename T>
	class SList
	{
	private:
		//!Node class for holding individual element 
		/*!
			The class is used for holding the value of each element and the pointer to next element 
		*/
		class Node 
		{
		public:
			T value;											//!< Templated variable to hold actual value to be stored
			Node *nextNode;										//!< Pointer variable used to point to next element

			//!Node class constructor
			/*!
				Constructor used for initializing the node class data members
			*/
			Node(const T& value, Node *nextNode = nullptr);
			Node(const Node& rhs) = delete;						//!< Deleting node copy constructor
			Node operator=(const Node& other) = delete;			//!< Deleting node assignment operator
		};

		Node *mFront;											//!< Node class pointer variable used to point to the start of the linked list
		Node *mBack;											//!< Node class pointer variable used to point to the end of the linked list
		std::uint32_t mSize;									//!< Unsigned int used for representing the number of elements stored in the list

	public:
		//!Iterator class for iterating through the SList 
		/*!
		The class is used for iterating through the SList values, it holds pointer to a node and a pointer to its owner
		*/
		class Iterator
		{
			friend SList;

		public:
			//!Iterator class default constructor
			/*!
			Constructor used for initializing the Iterator class data members
			*/
			Iterator();

			//!Iterator relational equality operator overload
			/*!
			checks for one:one comeparison of iterators data members
			returns the bool based on comparison 
			*/
			bool operator==(const Iterator& rhs) const;

			//!Iterator relational in-equality operator overload
			/*!
			checks for one:one comeparison of iterators data members
			returns the bool based on comparison (inverse of equality operator)
			*/
			bool operator!=(const Iterator& rhs) const;

			//!Iterator pre increment operator overload
			/*!
			move iterator to next node of the slist and return the iterator
			*/
			Iterator & operator++();

			//!Iterator post increment operator overload
			/*!
			update node pointer to next after returning current iterator value
			*/
			Iterator operator++(int);

			//!Iterator dereference operator overload
			/*!
			Makes the operand of the operator to point to the value stored in the node
			*/
			const T & operator*() const;

			//!Iterator dereference operator overload
			/*!
			Makes the operand of the operator to point to the value stored in the node
			Returns an exception if there are no elements in the list
			*/
			T & operator*();

		private:
			//!Iterator class private parameterized constructor
			/*!
			Constructor used for initializing the Iterator class data members
			*/
			Iterator(const SList & mOwner, Node *mCurrentNode = nullptr);

			Node *mCurrentNode;											//!< Node class pointer pointing to a element of the SList class
			SList *mOwner;												//!< SList class pointer variable used to set the owner slist
		};

		//!SList default constructor
		/*!
			Constructor used for initializing the slist class data members to nullptrs
		*/
		SList();

		//!SList copy constructor
		/*!
			performs a deep copy operation with another slist object
		*/
		SList(const SList &other);

		//!SList move constructor
		/*!
		performs a move operation with another slist object
		*/
		SList(SList && other);

		//!SList push front function
		/*!
			Pushes the value passed in as arrgument to the front of the linked list
		*/
		Iterator PushFront(const T& pushFrontValue);
		//!SList pop front function
		/*!
			deletes the first element from the front of the linked list
		*/
		void PopFront();
		//!SList push back function
		/*!
			Pushes the value passed in as arrgument to the end of the linked list
		*/
		Iterator PushBack(const T& pushBackValue);
		//!Slist is empty function
		/*!
			Returns true if there are no elements present in the list
		*/
		bool IsEmpty() const;
		
		//!SList front function
		/*!
			Returns a reference to the value stored as the first element from the front of the list
			Returns an exception if there are no elements in the list
		*/
		T& Front();
		//!SList const front function
		/*!
			Returns a const reference to the value stored as the first element from the front of the list
			Returns an exception if there are no elements in the list
			Used within const functions
		*/
		const T& Front() const;
		//!SList back function
		/*!
			Returns a reference to the value stored as the first element from the back of the list
			Returns an exception if there are no elements in the list
		*/
		T& Back();
		//!SList const back function
		/*!
			Returns a const reference to the value stored as the first element from the back of the list
			Returns an exception if there are no elements in the list
			Used within const functions
		*/
		const T& Back() const;

		//!SList size function
		/*!
			Returns the number of elements present in the list
		*/
		std::uint32_t Size() const;

		//!SList assignement oprator overload
		/*!
			performs a deep copy of the right hand side object
			returns the current object (this) for chanied assignements
		*/
		SList operator=(const SList &copySlist);

		//!SList move oprator overload
		/*!
		performs a move of the right hand side object
		returns the current object (this) for chanied assignements
		*/
		SList operator=(SList && copySlist);

		//!SList clear function
		/*!
			It deletes all the elements present in the list and frees the memory
		*/
		void Clear();

		//!SList Begin function
		/*!
		Returns a iterator pointing to the first node of the list
		Returns an exception if there are no elements in the list
		*/
		Iterator begin();
		//!SList Begin function
		/*!
		Returns a iterator pointing to the first node of the list
		Returns an exception if there are no elements in the list
		Used within const functions
		*/
		const Iterator begin() const;
		//!SList const front function
		/*!
		Returns a const iterator to the value stored as the first element from the front of the list
		Returns an exception if there are no elements in the list
		Used within const functions
		*/
		Iterator end();
		//!SList End function
		/*!
		Returns a iterator pointing to the node next of last node in the list
		Returns an exception if there are no elements in the list
		Used within const functions
		*/
		const Iterator end() const;
		//!SList Insert After function
		/*!
		Inserts a value passed in after the passed iterater location
		*/
		void InsertAfter(const T& insertValue,const Iterator& it);
		//!SList Find function
		/*!
		Returns a iterator pointing to the value passed in as reference
		Returns the end if it cant find mentioned value
		Used within const functions
		*/
		Iterator Find(const T& findValue) const;
		//!SList Remove function
		/*!
		Deletes the first occurance of the element found in the list
		*/
		bool Remove(const T& removeValue);
		//!SList Remove function
		/*!
		Deletes the first occurance of the element found in the list
		*/
		bool Remove(const Iterator& it);
		//!SList Remove All function
		/*!
		Deletes all the occurance of the element found in the list
		*/
		bool RemoveAll(const T& removeValue);

		//!SList default destructor
		/*!
			Releases the memory of the stored list
		*/
		~SList();
	};
}

#include "SList.inl"