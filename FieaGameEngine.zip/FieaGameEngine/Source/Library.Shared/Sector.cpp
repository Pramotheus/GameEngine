#include "pch.h"
#include "World.h"
#include "Sector.h"
#include "EngineFactory.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(Sector);

Sector::Sector()
	:Attributed(TypeIdInstance())
{
	InitializeMembers(TypeIdInstance());
}

Sector::Sector(const Sector & copySector)
	:Attributed(copySector), mName(copySector.mName)
{
	UpdateMembers();
}

Sector::Sector(Sector && moveSector)
	: Attributed(std::move(moveSector)), mName(std::move(moveSector.mName))
{
	UpdateMembers();
}

Sector & FieaGameEngine::Sector::operator=(const Sector & copySector)
{
	if (this != &copySector)
	{
		Attributed::operator=(copySector);
		mName = copySector.mName;

		UpdateMembers();
	}
	return *this;
}

Sector & FieaGameEngine::Sector::operator=(Sector && moveSector)
{
	if (this != &moveSector)
	{
		Attributed::operator=(std::move(moveSector));
		mName = std::move(moveSector.mName);

		UpdateMembers();
	}
	return *this;
}

std::string FieaGameEngine::Sector::Name() const
{
	return mName;
}

void FieaGameEngine::Sector::SetName(const std::string & entityName)
{
	mName = entityName;
}

Datum & FieaGameEngine::Sector::GetEntities()
{
	return *Find("Entities");
}

Entity * FieaGameEngine::Sector::CreateEntity(const std::string & entityClassName, const std::string & entityInstanceName)
{
	Entity * createdEntity = EngineFactory<Entity>::Create(entityClassName);
	createdEntity->SetName(entityInstanceName);
	createdEntity->SetSector(this);
	return createdEntity;
}

World & FieaGameEngine::Sector::GetWorld()
{
	return *mParent->As<World>();
}

void FieaGameEngine::Sector::SetWorld(World * parentWorld)
{
	if(parentWorld != nullptr)
		parentWorld->Adopt(*this, "Sectors");
}

void FieaGameEngine::Sector::Update(WorldState & worldState)
{
	worldState.CurrentSector = this;

	Datum entityDatum = GetEntities();
	Scope *currentEntity;
	uint32_t size = entityDatum.Size();

	for (uint32_t i = 0; i < size; ++i)
	{
		currentEntity = entityDatum.Get<Scope*>(i);
		assert(currentEntity->Is("Entity"));
		static_cast<Entity*>(currentEntity)->Update(worldState);
	}

	worldState.CurrentSector = nullptr;
}

void FieaGameEngine::Sector::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Name", &mName, 1);
	SetScope(typeID, "Entities");
}

void FieaGameEngine::Sector::UpdateMembers()
{
	(*this)["Name"].SetStorage(&mName, 1);
}

Sector::~Sector()
{
}

