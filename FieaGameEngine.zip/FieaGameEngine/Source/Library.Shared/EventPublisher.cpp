#include "pch.h"
#include <future>
#include "EventPublisher.h"
#include "EventSubscriber.h"

using namespace FieaGameEngine;
using namespace std;

RTTI_DEFINITIONS(EventPublisher)

EventPublisher::EventPublisher(Vector<gsl::not_null<EventSubscriber*>> & subscriberList, mutex &mutex)
	:mSubscribers(subscriberList), mMutex(&mutex), mEventTime(), mDelayTime(chrono::milliseconds::zero())
{
}


void FieaGameEngine::EventPublisher::SetTime(const std::chrono::high_resolution_clock::time_point & currentTime, std::chrono::milliseconds delay)
{
	mEventTime = currentTime;
	mDelayTime = delay;
}

std::chrono::high_resolution_clock::time_point & FieaGameEngine::EventPublisher::TimeEnqueued()
{
	return mEventTime;
}

std::chrono::milliseconds & FieaGameEngine::EventPublisher::Delay()
{
	return mDelayTime;
}

bool FieaGameEngine::EventPublisher::IsExpired(const std::chrono::high_resolution_clock::time_point & currentTime)
{
	return (currentTime > (mEventTime + mDelayTime));
}

void FieaGameEngine::EventPublisher::Deliver()
{
	vector<future<void>> futures;

	{
		lock_guard<mutex> lock(*mMutex);
		for (auto & value : mSubscribers)
		{
			futures.emplace_back(async(launch::async, [](gsl::not_null<EventSubscriber*> subscriber, EventPublisher* publisher) {subscriber->Notify(*publisher); }, value, this));
		}
	}

	for (auto & currentFuture : futures)
	{
		currentFuture.get();
	}
}