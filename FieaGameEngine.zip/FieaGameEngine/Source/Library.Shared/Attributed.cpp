#include "pch.h"
#include "Attributed.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(Attributed);

Attributed::Attributed(uint64_t typeID)
{
	string thisString = "this";
	Append(thisString) = static_cast<RTTI*>(this);
	Vector<std::string> tempVector;
	bool keyExists = mPrescribedAttributes.ContainsKey(typeID, tempVector);

	if (!keyExists)
	{
		tempVector.PushBack(thisString);
		mPrescribedAttributes.Insert({ typeID, tempVector });
	}
}

FieaGameEngine::Attributed::Attributed(const Attributed & copyAttributed)
	:Scope(copyAttributed)
{
	(*this)["this"] = static_cast<RTTI*>(this);
}

FieaGameEngine::Attributed::Attributed(Attributed && moveAttributed)
	: Scope(std::move(moveAttributed))
{
	(*this)["this"] = static_cast<RTTI*>(this);
}

void FieaGameEngine::Attributed::SetExternalAttributes(uint64_t typeId, std::string key, int32_t * inputArray, uint32_t numberOfElements)
{
	Append(key).SetStorage(inputArray, numberOfElements);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetExternalAttributes(uint64_t typeId, std::string key, float * inputArray, uint32_t numberOfElements)
{
	Append(key).SetStorage(inputArray, numberOfElements);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetExternalAttributes(uint64_t typeId, std::string key, glm::vec4 * inputArray, uint32_t numberOfElements)
{
	Append(key).SetStorage(inputArray, numberOfElements);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetExternalAttributes(uint64_t typeId, std::string key, glm::mat4x4 * inputArray, uint32_t numberOfElements)
{
	Append(key).SetStorage(inputArray, numberOfElements);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetExternalAttributes(uint64_t typeId, std::string key, std::string * inputArray, uint32_t numberOfElements)
{
	Append(key).SetStorage(inputArray, numberOfElements);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetExternalAttributes(uint64_t typeId, std::string key, RTTI ** inputArray, uint32_t numberOfElements)
{
	Append(key).SetStorage(inputArray, numberOfElements);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetInternalAttributes(uint64_t typeId, std::string key, int32_t value, uint32_t numberOfElements)
{
	Datum & temp = Append(key);
	temp.SetType(Datum::DatumType::Integer);
	temp.Reserve(numberOfElements);

	for (uint32_t i = 0; i < numberOfElements; ++i)
		temp.PushBack(value);

	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetInternalAttributes(uint64_t typeId, std::string key, float value, uint32_t numberOfElements)
{
	Datum & temp = Append(key);
	temp.SetType(Datum::DatumType::Float);
	temp.Reserve(numberOfElements);

	for (uint32_t i = 0; i < numberOfElements; ++i)
		temp.PushBack(value);

	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetInternalAttributes(uint64_t typeId, std::string key, const glm::vec4 & value, uint32_t numberOfElements)
{
	Datum & temp = Append(key);
	temp.SetType(Datum::DatumType::Vector);
	temp.Reserve(numberOfElements);

	for (uint32_t i = 0; i < numberOfElements; ++i)
		temp.PushBack(value);

	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetInternalAttributes(uint64_t typeId, std::string key, const glm::mat4x4 & value, uint32_t numberOfElements)
{
	Datum & temp = Append(key);
	temp.SetType(Datum::DatumType::Matrix);
	temp.Reserve(numberOfElements);

	for (uint32_t i = 0; i < numberOfElements; ++i)
		temp.PushBack(value);

	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetInternalAttributes(uint64_t typeId, std::string key, const std::string & value, uint32_t numberOfElements)
{
	Datum & temp = Append(key);
	temp.SetType(Datum::DatumType::String);
	temp.Reserve(numberOfElements);

	for (uint32_t i = 0; i < numberOfElements; ++i)
		temp.PushBack(value);

	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetInternalAttributes(uint64_t typeId, std::string key, RTTI *& value, uint32_t numberOfElements)
{
	Datum & temp = Append(key);
	temp.SetType(Datum::DatumType::Pointer);
	temp.Reserve(numberOfElements);

	for (uint32_t i = 0; i < numberOfElements; ++i)
		temp.PushBack(value);

	PrescribedAttributeUpdate(key, typeId);
}

Scope & FieaGameEngine::Attributed::SetNestedScope(uint64_t typeId, std::string key)
{
	PrescribedAttributeUpdate(key, typeId);
	return AppendScope(key);
}

void FieaGameEngine::Attributed::SetNestedScope(uint64_t typeId, std::string key, Scope & value)
{
	Adopt(value, key);
	PrescribedAttributeUpdate(key, typeId);
}

void FieaGameEngine::Attributed::SetScope(uint64_t typeId, std::string key)
{
	Append(key).SetType(Datum::DatumType::Table);
	PrescribedAttributeUpdate(key, typeId);
}

void Attributed::PrescribedAttributeUpdate(std::string key, uint64_t typeId)
{
	Vector<std::string> tempVector;
	bool keyExists = mPrescribedAttributes.ContainsKey(typeId, tempVector);

	if (keyExists)
	{
		if (tempVector.Find(key) == tempVector.end())
			mPrescribedAttributes.Find(typeId)->second.PushBack(key);
	}
}

Datum & FieaGameEngine::Attributed::AppendAuxiliaryAttribute(const std::string & key)
{
	if (IsPrescribedAttribute(key))
		throw exception("Trying to append prescribed attribute as auxilary attribute");

	return Append(key);
}

bool FieaGameEngine::Attributed::IsAttribute(const std::string & key) const
{
	return(Find(key) != nullptr);
}

bool FieaGameEngine::Attributed::IsPrescribedAttribute(const std::string & key) const
{
	Vector<string> prescribed = (mPrescribedAttributes.Find(TypeIdInstance()))->second;

	for (auto & value : prescribed)
	{
		if (value == key)
			return true;
	}

	return false;
}

bool FieaGameEngine::Attributed::IsAuxiliaryAttributed(const std::string & key) const
{
	return (IsAttribute(key) && !IsPrescribedAttribute(key));
}

Vector<Attributed::ScopePairType*> FieaGameEngine::Attributed::GetAttributes() const
{
	return Scope::mOrderVector;
}

Vector<Attributed::ScopePairType*> FieaGameEngine::Attributed::GetPrescribedAttributes() const
{
	Vector<string> prescribed = mPrescribedAttributes.Find(TypeIdInstance())->second;
	Vector<ScopePairType*> returnVector;

	for (auto & value : prescribed)
	{
		returnVector.PushBack(&(*(Scope::mData.Find(value))));
	}

	return returnVector;
}

Vector<Attributed::ScopePairType*> FieaGameEngine::Attributed::GetAuxiliaryAttributes() const
{
	Vector<ScopePairType*> returnVector;

	for (auto & value : Scope::mOrderVector)
	{
		if (!IsPrescribedAttribute(value->first))
			returnVector.PushBack(value);
	}

	return returnVector;
}

Attributed & FieaGameEngine::Attributed::operator=(const Attributed & copyAttributed)
{
	if (this != &copyAttributed)
	{
		Scope::operator=(copyAttributed);
		(*this)["this"] = static_cast<RTTI*>(this);
	}
	return *this;
}

Attributed & FieaGameEngine::Attributed::operator=(Attributed && moveAttributed)
{
	if (this != &moveAttributed)
	{
		Scope::operator=(std::move(moveAttributed));
		(*this)["this"] = static_cast<RTTI*>(this);
	}
	return *this;
}