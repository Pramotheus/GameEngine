#include "pch.h"
#include "World.h"
#include "EngineFactory.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(World);

World::World()
	:Attributed(TypeIdInstance()), mName(), mWorldState(), mEventQueue()
{
	InitializeMembers(TypeIdInstance());
}

World::World(World && moveWorld)
	: Attributed(std::move(moveWorld)), mName(std::move(moveWorld.mName)), mWorldState(std::move(moveWorld.mWorldState))//, mEventQueue(moveWorld.mEventQueue)
{
	UpdateMembers();
}

World & FieaGameEngine::World::operator=(World && moveWorld)
{
	if (this != &moveWorld)
	{
		Attributed::operator=(std::move(moveWorld));

		mName = std::move(moveWorld.mName);
		mWorldState = std::move(moveWorld.mWorldState);
		//mEventQueue = std::move(moveWorld.mEventQueue);

		UpdateMembers();
	}
	return *this;
}

std::string FieaGameEngine::World::Name() const
{
	return mName;
}

void FieaGameEngine::World::SetName(const std::string & entityName)
{
	mName = entityName;
}

void FieaGameEngine::World::Update()
{
	mWorldState.CurrentWorld = this;
	mWorldState.ThrowTrash();

	mEventQueue.Update(mWorldState.GetGameTime());

	Datum sectorDatum = GetSectors();
	Scope *currentSector;
	uint32_t size = sectorDatum.Size();

	for (uint32_t i = 0; i < size; ++i)
	{
		currentSector = sectorDatum.Get<Scope*>(i);
		assert(currentSector->Is("Sector"));
		static_cast<Sector*>(currentSector)->Update(mWorldState);
	}

	mWorldState.CurrentWorld = nullptr;
}

Datum & FieaGameEngine::World::GetSectors()
{
	return *Find("Sectors");
}

Sector * FieaGameEngine::World::CreateSector(const std::string & sectorInstanceName)
{
	Sector * createdSector = new Sector();
	createdSector->SetName(sectorInstanceName);
	createdSector->SetWorld(this);
	return createdSector;
}

Reaction * FieaGameEngine::World::CreateReactions(const std::string & reactionClassName, const std::string & reactionInstanceName)
{
	Reaction * createdReaction = EngineFactory<Reaction>::Create(reactionClassName);
	createdReaction->SetName(reactionInstanceName);
	Adopt(*createdReaction, "Reactions");
	return createdReaction;
}

WorldState & FieaGameEngine::World::GetWorldState()
{
	return mWorldState;
}

EventQueue & FieaGameEngine::World::GetEventQueue()
{
	return mEventQueue;
}

void FieaGameEngine::World::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Name", &mName, 1);
	SetScope(typeID, "Sectors");
	SetScope(typeID, "Reactions");
}

void FieaGameEngine::World::UpdateMembers()
{
	(*this)["Name"].SetStorage(&mName, 1);
}