#pragma once
#include <chrono>
#include <mutex>
#include "gsl\gsl"
#include "Vector.h"
#include "RTTI.h"

namespace FieaGameEngine
{
	class EventSubscriber;

	//!Event publisher Abstract Class
	/*!
	*	The class acts as the base interface for all events
	*/
	class EventPublisher : public RTTI
	{
		RTTI_DECLARATIONS(EventPublisher, RTTI)										//RTTI Declaration

	protected:
		//!Default constructor
		/*!
		*	It is protected so the constructer is used only to get derived class
		*	Gets the vector of subscriber from the child templeted events
		*/
		EventPublisher(Vector<gsl::not_null<EventSubscriber*>> &subscriberList, mutex &mutex);

	public:
		//!Defaulted Constructor & Destructor
		/*!
		*	The copy constructor, move constructor and virtual destructor are defaulted
		*/
		EventPublisher(const EventPublisher &) = default;
		EventPublisher(EventPublisher &&) = default;
		EventPublisher & operator=(const EventPublisher &) = default;
		EventPublisher & operator=(EventPublisher &&) = default;
		virtual ~EventPublisher() = default;

		//!SetTime function
		/*!
		*	Function that is used to set the start and delay time for the current event
		*/
		void SetTime(const std::chrono::high_resolution_clock::time_point& currentTime, std::chrono::milliseconds delay = std::chrono::milliseconds::zero());
		//!TimeEnqueued function
		/*!
		*	Function that is used to return the start time of the event
		*/
		std::chrono::high_resolution_clock::time_point & TimeEnqueued();
		//!Delay function
		/*!
		*	Function that is used to return the delay time from start of event
		*/
		std::chrono::milliseconds & Delay();
		//!IsExpired function
		/*!
		*	Function that is used to return a bool based on current passed in time with start time based on delay
		*/
		bool IsExpired(const std::chrono::high_resolution_clock::time_point& currentTime);

		//!Deliver function
		/*!
		*	Function that is used to notify all subsribers for current child type of event
		*/
		void Deliver();

	protected:
		std::chrono::high_resolution_clock::time_point mEventTime;							//!< Member variable holding the time point ehen event was created
		std::chrono::milliseconds mDelayTime;												//!< Member variable used to add delay on whe nevent has to fire
	private:
		Vector<gsl::not_null<EventSubscriber*>> & mSubscribers;								//!< Member vector holding all subscribers from the derived class (not static and hence varies with type of child)
		mutex* mMutex;																		//!< Mutex variable to multi thread
	};
}
