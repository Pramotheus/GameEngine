#pragma once
#include "Event.h"
#include "Action.h"

namespace FieaGameEngine
{
	//!ActionEvent Class
	/*!
	*	The ActionEvent class is used to create a event and enque it to the event queue
	*	It inherits from Action class
	*/
	class ActionEvent : public Action 
	{
		RTTI_DECLARATIONS(ActionEvent, Action)
	public:
		//!Defaulted Constructor & Destructor
		/*!
		*	The constructer, copy constructor and virtual destructor are defaulted
		*/
		ActionEvent();
		~ActionEvent() = default;

		ActionEvent(const ActionEvent &) = delete;
		ActionEvent & operator=(const ActionEvent &) = delete;

		//!Move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		ActionEvent(ActionEvent && rhs);

		//!Move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		ActionEvent & operator=(ActionEvent && rhs);

		//!Update function
		/*!
		*	Create an attributed event, assign its world and subtype, copy all auxiliary parameters into the event and queue the event with the given delay
		*/
		virtual void Update(WorldState & worldState) override;

	private:
		//!Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		string mSubtype;									//Subtype used to specify the type of message on the event
		int32_t mDelay;										//Amount of delay used to create the event
	};

	ConcreteFactory(ActionEvent, Action)
}
