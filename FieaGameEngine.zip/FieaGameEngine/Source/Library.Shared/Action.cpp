#include "pch.h"
#include "Action.h"
#include "Entity.h"

using namespace FieaGameEngine;

RTTI_DEFINITIONS(Action)

FieaGameEngine::Action::Action(uint64_t typeID)
	: Attributed(typeID)
{
	InitializeMembers(typeID);
}

FieaGameEngine::Action::Action(Action && moveAction)
	: Attributed(std::move(moveAction)), mName(std::move(moveAction.mName))
{
	UpdateMembers();
}

Action & FieaGameEngine::Action::operator=(Action && moveAction)
{
	if (this != &moveAction)
	{
		Attributed::operator=(std::move(moveAction));
		mName = std::move(moveAction.mName);
		UpdateMembers();
	}
	return *this;
}

std::string FieaGameEngine::Action::Name() const
{
	return mName;
}

void FieaGameEngine::Action::SetName(const std::string & ActionName)
{
	mName = ActionName;
}

Entity & FieaGameEngine::Action::GetEntity()
{
	return *mParent->As<Entity>();
}

void FieaGameEngine::Action::SetEntity(Entity * parentEntity)
{
	parentEntity->Adopt(*this, "Actions");
}

void FieaGameEngine::Action::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "Name", &mName, 1);
}

void FieaGameEngine::Action::UpdateMembers()
{
	(*this)["Name"].SetStorage(&mName, 1);
}

Action::~Action()
{
}


