#pragma once
#include "Scope.h"

namespace FieaGameEngine
{
	//!Attributed Class
	/*!
	*	The Attributed class behaves as a interface between scope and all other classes
	*	It adds priscribed and non prescribed attributes
	*/
	class Attributed : public Scope
	{
		RTTI_DECLARATIONS(Attributed, Scope)

		typedef std::pair<std::string, Datum> ScopePairType;

	public:
		//!Parameterised constructor
		/*!
		*	Used for instantiating the first element of the list with "this" pointer
		*/
		explicit Attributed(uint64_t typeID);
		//!Attributed copy constructor
		/*!
		*	The copy constructor reinitialises the "this" pointer and calls base class copy constructor
		*/
		Attributed(const Attributed & copyAttributed);
		//!Attributed move constructor
		/*!
		*	The move constructor reinitialises the "this" pointer and calls base class move constructor
		*/
		Attributed(Attributed && moveAttributed);

		//!Is Attributed Member Function
		/*!
		*	The function is used to verify if the passed in string is a key to a scope entry
		*/
		bool IsAttribute(const std::string & key) const;
		//!Is Prescribed Attributed Member Function
		/*!
		*	The function is used to verify if the passed in key is a prescribed attribute
		*/
		bool IsPrescribedAttribute(const std::string & key) const;
		//!Is Auxiliary Attributed Member Function
		/*!
		*	The function is used to verify if the passed in key is a attribute but not a prescribed attribute
		*/
		bool IsAuxiliaryAttributed(const std::string & key) const;

		//!Append Auxiliary Attribute function
		/*!
		*	The function is used to add a new auxilary attibute into the scope
		*	It returns a datum refernce used for modifying the data
		*/
		Datum & AppendAuxiliaryAttribute(const std::string & key);

		//!Get Attributes function
		/*!
		*	Returns a vector of all pointers to string datum pair in the scope
		*/
		Vector<ScopePairType*> GetAttributes() const;
		//!Get Prescribed Attributes function
		/*!
		*	Returns a vector of Prescribed Attributes pointers to string datum pair in the scope
		*/
		Vector<ScopePairType*> GetPrescribedAttributes() const;
		//!Get Auxiliary Attributes function
		/*!
		*	Returns a vector of Auxiliary Attributes pointers to string datum pair in the scope
		*/
		Vector<ScopePairType*> GetAuxiliaryAttributes() const;

		//!Attributed copy assignement operator
		/*!
		*	The copy assignement operator reinitialises the "this" pointer and calls base class copy assignement operator
		*/
		Attributed & operator=(const Attributed & copyAttributed);
		//!Attributed move assignement operator
		/*!
		*	The move assignement operator reinitialises the "this" pointer and calls base class move assignement operator
		*/
		Attributed & operator=(Attributed && moveAttributed);

		//!Set External int Attribute function
		/*!
		*	Used for setting the passed in int array or element as external storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetExternalAttributes(uint64_t typeId, std::string key, int32_t * inputArray, uint32_t numberOfElements = 1);
		//!Set External float Attribute function
		/*!
		*	Used for setting the passed in float array or element as external storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetExternalAttributes(uint64_t typeId, std::string key, float * inputArray, uint32_t numberOfElements = 1);
		//!Set External vec4 Attribute function
		/*!
		*	Used for setting the passed in vec4 array or element as external storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetExternalAttributes(uint64_t typeId, std::string key, glm::vec4 * inputArray, uint32_t numberOfElements = 1);
		//!Set External mat4x4 Attribute function
		/*!
		*	Used for setting the passed in mat4x4 array or element as external storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetExternalAttributes(uint64_t typeId, std::string key, glm::mat4x4 * inputArray, uint32_t numberOfElements = 1);
		//!Set External string Attribute function
		/*!
		*	Used for setting the passed in string array or element as external storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetExternalAttributes(uint64_t typeId, std::string key, std::string * inputArray, uint32_t numberOfElements = 1);
		//!Set External RTTI* Attribute function
		/*!
		*	Used for setting the passed in RTTI* array or element as external storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetExternalAttributes(uint64_t typeId, std::string key, RTTI* * inputArray, uint32_t numberOfElements = 1);

		//!Set Internal int Attribute function
		/*!
		*	Used for setting the passed in int element as default value for all elemets in datum specified by numberofElements in Internal storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetInternalAttributes(uint64_t typeId, std::string key, int32_t value, uint32_t numberOfElements = 1);
		//!Set Internal float Attribute function
		/*!
		*	Used for setting the passed in float element as default value for all elemets in datum specified by numberofElements in internal storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetInternalAttributes(uint64_t typeId, std::string key, float value, uint32_t numberOfElements = 1);
		//!Set Internal vec4 Attribute function
		/*!
		*	Used for setting the passed in vec4 element as default value for all elemets in datum specified by numberofElements in internal storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetInternalAttributes(uint64_t typeId, std::string key, const glm::vec4 & value, uint32_t numberOfElements = 1);
		//!Set Internal mat4x4 Attribute function
		/*!
		*	Used for setting the passed in mat4x4 element as default value for all elemets in datum specified by numberofElements in internal storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetInternalAttributes(uint64_t typeId, std::string key, const glm::mat4x4 & value, uint32_t numberOfElements = 1);
		//!Set Internal string Attribute function
		/*!
		*	Used for setting the passed in string element as default value for all elemets in datum specified by numberofElements in internal storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetInternalAttributes(uint64_t typeId, std::string key, const std::string & value, uint32_t numberOfElements = 1);
		//!Set Internal RTTI* Attribute function
		/*!
		*	Used for setting the passed in RTTI* element as default value for all elemets in datum specified by numberofElements in internal storage attribute
		*	Stores the attribute as a prescribed attibute and adds its key to a static hashmap for reference
		*/
		void SetInternalAttributes(uint64_t typeId, std::string key, RTTI* & value, uint32_t numberOfElements = 1);

		//!Set Nested Scope function
		/*!
		*	Used for appending a nested scope to the parent scope and returning its reference
		*/
		Scope & SetNestedScope(uint64_t typeId, std::string key);
		//!Set Nested Scope function
		/*!
		*	Used for adopting the passed in scope as nested scope to the parent scope
		*/
		void SetNestedScope(uint64_t typeId, std::string key, Scope & value);

		//!Set Scope function
		/*!
		*	Used for apending datum of type scope
		*/
		void SetScope(uint64_t typeId, std::string key);

		//!Scope Default destructor
		/*!
		*	Calls destructor of base class
		*/
		virtual ~Attributed() = default;

	private:
		//!Helper function
		/*!
		*	Used for help with assigning keys to static hashmap
		*/
		void PrescribedAttributeUpdate(std::string key, uint64_t typeId);

		static HashMap<uint64_t, Vector<std::string>> mPrescribedAttributes;										//!< Static hashmap used for holding all prescribed attributes
	};
}
