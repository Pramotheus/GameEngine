#pragma once
#include "Action.h"

namespace FieaGameEngine
{
	//!Action Delete Action Class
	/*!
	*	The Action delete action class is used to delete actions through script
	*	It inherits from action class
	*/
	class ActionDeleteAction : public Action
	{
		RTTI_DECLARATIONS(ActionDeleteAction, Action)

	public:
		//!Default constructor
		/*!
		*	Initialises the member variables for the class
		*/
		ActionDeleteAction();

		ActionDeleteAction(const ActionDeleteAction &) = delete;
		ActionDeleteAction & operator=(const ActionDeleteAction &) = delete;

		//!Move constructor
		/*!
		*	Constructor used to move one Action to other
		*/
		ActionDeleteAction(ActionDeleteAction && rhs);

		//!Move assignement operator
		/*!
		*	Assignement operator used to move one Action to other
		*/
		ActionDeleteAction & operator=(ActionDeleteAction && rhs);

		//!Update function
		/*!
		*	Function that is called each frame from its parent
		*	Searches up the heirachy and marks the required action to be deleted
		*/
		void Update(WorldState& worldState) override;

		//!Default Destructor
		/*!
		*	Defaul destructor for destructing member variables, can be defaulted
		*/
		~ActionDeleteAction();

	private:
		//!Initialize members function
		/*!
		*	Used to initialise members into the attributed static hashmap
		*/
		void InitializeMembers(uint64_t typeID);
		//!Update members function
		/*!
		*	used for updating pointers in static hashmap of attributed after move or copy
		*/
		void UpdateMembers();

		string mDeleteActionName;										//!< Member variable holding the name of the action to be deleted
	};

	ConcreteFactory(ActionDeleteAction, Action)
}
