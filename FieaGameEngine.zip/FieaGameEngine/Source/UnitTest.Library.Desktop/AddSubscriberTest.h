#pragma once
#include "EventSubscriber.h"
#include "EventQueue.h"

namespace UnitTestLibraryDesktop
{
	class AddSubscriberTest : public FieaGameEngine::EventSubscriber
	{
	public:
		AddSubscriberTest() = default;
		~AddSubscriberTest() = default;

		virtual void Notify(FieaGameEngine::EventPublisher & publisher) override;

		static FieaGameEngine::EventQueue* mQueue;
		static FieaGameEngine::GameTime mTime;
		bool mNotified{ false };
	};
}
