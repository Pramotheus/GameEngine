#include "pch.h"
#include "TesterClass.h"

namespace UnitTestLibraryDesktop
{
	RTTI_DEFINITIONS(TesterClass);

	TesterClass::TesterClass()
		:data(0), dataPointer(new int(0))
	{
	}

	TesterClass::TesterClass(int value)
		:data(value), dataPointer(new int(value))
	{
	}

	TesterClass::TesterClass(const TesterClass & other)
		: data(other.data), dataPointer(new int(*(other.dataPointer)))
	{
	}

	int TesterClass::GetData() const
	{
		return data;
	}

	int* TesterClass::GetDataPointer() const
	{
		return dataPointer;
	}


	void TesterClass::SetData(int value)
	{
		*dataPointer = value;
		data = value;
	}

	void TesterClass::clearTestPointer()
	{
		delete dataPointer;
	}

	TesterClass TesterClass::operator=(const TesterClass & rhs)
	{
		if (this != &rhs)
		{
			clearTestPointer();
			dataPointer = new int(*(rhs.dataPointer));
			data = rhs.data;
		}
		return *this;
	}

	bool TesterClass::operator==(const TesterClass & other)
	{
		return ((data == other.data) && (*dataPointer == *(other.dataPointer)));
	}

	bool TesterClass::operator==(const TesterClass & other) const
	{
		return ((data == other.data) && (*dataPointer == *(other.dataPointer)));
	}


	TesterClass::~TesterClass()
	{
		clearTestPointer();
	}

	uint32_t TesterHashFunctor::operator()(const TesterClass & foo) const
	{
		return (static_cast<uint32_t>(foo.GetData() + (*(foo.GetDataPointer()))));
	}
}