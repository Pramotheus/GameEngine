#include "pch.h"
#include "JsonFooParseHelper.h"

using namespace UnitTestLibraryDesktop;
using namespace FieaGameEngine;

RTTI_DEFINITIONS(JsonFooParseHelper::SharedFooData);

JsonFooParseHelper::JsonFooParseHelper()
	:mFooSharedData(nullptr)
{
}

void UnitTestLibraryDesktop::JsonFooParseHelper::Initialize()
{
}

bool UnitTestLibraryDesktop::JsonFooParseHelper::DataHandler(const string & value, const Json::Value & data, const FieaGameEngine::JsonParseMaster::SharedData & sharedData)
{
	mFooSharedData = sharedData.As<SharedFooData>();
	UNREFERENCED_PARAMETER(value);

	if (mFooSharedData != nullptr)
	{
		mFooSharedData->Foo->SetData(data.asInt());
		return true;
	}

	return false;
}

bool UnitTestLibraryDesktop::JsonFooParseHelper::StartHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData)
{
	UNREFERENCED_PARAMETER(sharedData);
	UNREFERENCED_PARAMETER(data);
	UNREFERENCED_PARAMETER(key);
	return false;
}

bool UnitTestLibraryDesktop::JsonFooParseHelper::EndHandler(const JsonParseMaster::SharedData & sharedData)
{
	UNREFERENCED_PARAMETER(sharedData);
	return false;
}

JsonFooParseHelper * JsonFooParseHelper::Clone()
{
	return new JsonFooParseHelper(*this);
}

JsonFooParseHelper::SharedFooData * JsonFooParseHelper::SharedFooData::Clone()
{
	SharedFooData * CloneFooShare = new SharedFooData(*this);
	CloneFooShare->Foo = new TesterClass(*this->Foo);
	CloneFooShare->mParseMaster = nullptr;
	CloneFooShare->IsClone = true;
	return CloneFooShare;
}

void UnitTestLibraryDesktop::JsonFooParseHelper::SharedFooData::Initialize()
{
}

void UnitTestLibraryDesktop::JsonFooParseHelper::SharedFooData::SetFoo(TesterClass * foo)
{
	if (foo != nullptr)
		Foo = foo;
}

TesterClass & UnitTestLibraryDesktop::JsonFooParseHelper::SharedFooData::GetFoo()
{
	return *Foo;
}

UnitTestLibraryDesktop::JsonFooParseHelper::SharedFooData::~SharedFooData()
{
	if (IsClone)
	{
		delete Foo;
	}
}

void UnitTestLibraryDesktop::JsonBarParseHelper::Initialize()
{
}

bool UnitTestLibraryDesktop::JsonBarParseHelper::DataHandler(const string & value, const Json::Value & data, const FieaGameEngine::JsonParseMaster::SharedData & sharedData)
{
	UNREFERENCED_PARAMETER(sharedData);
	UNREFERENCED_PARAMETER(data);
	UNREFERENCED_PARAMETER(value);
	return false;
}

bool UnitTestLibraryDesktop::JsonBarParseHelper::StartHandler(const string & key, const Json::Value & data, const JsonParseMaster::SharedData & sharedData)
{
	UNREFERENCED_PARAMETER(sharedData);
	UNREFERENCED_PARAMETER(data);
	UNREFERENCED_PARAMETER(key);
	return false;
}

bool UnitTestLibraryDesktop::JsonBarParseHelper::EndHandler(const JsonParseMaster::SharedData & sharedData)
{
	UNREFERENCED_PARAMETER(sharedData);
	return false;
}

JsonFooParseHelper * UnitTestLibraryDesktop::JsonBarParseHelper::Clone()
{
	return nullptr;
}
