#include "pch.h"
#include "Vector.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(VectorTest)
	{
	public:
		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(VectorBack)
		{
			//int test
			Vector<int> intVector;
			int a = 10;

			auto expression = [&intVector] {intVector.Back(); };
			Assert::ExpectException<exception>(expression);

			intVector.PushBack(a);

			Assert::AreEqual(a, intVector.Back());
			a = 20;
			Assert::AreNotEqual(a, intVector.Back());
			Assert::AreNotSame(a, intVector.Back());


			//int pointer test
			int* aPointer = &a;
			Vector<int*> pointerVector;

			auto pointerExpression = [&pointerVector] {pointerVector.Back(); };
			Assert::ExpectException<exception>(pointerExpression);

			pointerVector.PushBack(aPointer);

			Assert::AreEqual(aPointer, pointerVector.Back());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerVector.Back());
			Assert::AreNotSame(aPointer, pointerVector.Back());

			//user defined class test
			TesterClass foo(10);
			Vector<TesterClass> fooVector;

			auto fooExpression = [&fooVector] {fooVector.Back(); };
			Assert::ExpectException<exception>(fooExpression);

			fooVector.PushBack(foo);

			Assert::AreEqual(foo, fooVector.Back());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooVector.Back());
			Assert::AreNotSame(foo, fooVector.Back());
		}

		TEST_METHOD(VectorFront)
		{
			//int test
			Vector<int> intVector;
			int a = 10;

			auto expression = [&intVector] {intVector.Front(); };
			Assert::ExpectException<exception>(expression);

			intVector.PushBack(a);

			Assert::AreEqual(a, intVector.Front());
			a = 20;
			Assert::AreNotEqual(a, intVector.Front());
			Assert::AreNotSame(a, intVector.Front());


			//int pointer test
			int* aPointer = &a;
			Vector<int*> pointerVector;

			auto pointerExpression = [&pointerVector] {pointerVector.Front(); };
			Assert::ExpectException<exception>(pointerExpression);

			pointerVector.PushBack(aPointer);

			Assert::AreEqual(aPointer, pointerVector.Front());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerVector.Front());
			Assert::AreNotSame(aPointer, pointerVector.Front());

			//user defined class test
			TesterClass foo(10);
			Vector<TesterClass> fooVector;

			auto fooExpression = [&fooVector] {fooVector.Front(); };
			Assert::ExpectException<exception>(fooExpression);

			fooVector.PushBack(foo);

			Assert::AreEqual(foo, fooVector.Front());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooVector.Front());
			Assert::AreNotSame(foo, fooVector.Front());
		}

		TEST_METHOD(VectorConstBack)
		{
			//int test
			Vector<int> nonConstIntVector;
			int a = 10;
			nonConstIntVector.PushBack(a);

			const Vector<int> constIntVector;

			auto expression = [&constIntVector] {constIntVector.Back(); };
			Assert::ExpectException<exception>(expression);

			const Vector<int> intVector(nonConstIntVector);

			Assert::AreEqual(a, intVector.Back());
			a = 20;
			Assert::AreNotEqual(a, intVector.Back());
			Assert::AreNotSame(a, intVector.Back());


			//int pointer test
			Vector<int*> nonConstPointerVector;
			int* aPointer = &a;
			nonConstPointerVector.PushBack(aPointer);

			const Vector<int*> constPointerVector;

			auto pointerExpression = [&constPointerVector] {constPointerVector.Back(); };
			Assert::ExpectException<exception>(pointerExpression);

			const Vector<int*> pointerVector(nonConstPointerVector);

			Assert::AreEqual(aPointer, pointerVector.Back());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerVector.Back());
			Assert::AreNotSame(aPointer, pointerVector.Back());

			//user defined class test
			Vector<TesterClass> nonConstfooVector;
			TesterClass foo(10);
			nonConstfooVector.PushBack(foo);

			Vector<TesterClass> constFooVector;

			auto fooExpression = [&constFooVector] {constFooVector.Back(); };
			Assert::ExpectException<exception>(fooExpression);

			const Vector<TesterClass> fooVector(nonConstfooVector);

			Assert::AreEqual(foo, fooVector.Back());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooVector.Back());
			Assert::AreNotSame(foo, fooVector.Back());
		}

		TEST_METHOD(VectorConstFront)
		{
			//int test
			Vector<int> nonConstIntVector;
			int a = 10;
			nonConstIntVector.PushBack(a);

			const Vector<int> constIntVector;

			auto expression = [&constIntVector] {constIntVector.Front(); };
			Assert::ExpectException<exception>(expression);

			const Vector<int> intVector(nonConstIntVector);

			Assert::AreEqual(a, intVector.Front());
			a = 20;
			Assert::AreNotEqual(a, intVector.Front());
			Assert::AreNotSame(a, intVector.Front());


			//int pointer test
			Vector<int*> nonConstPointerVector;
			int* aPointer = &a;
			nonConstPointerVector.PushBack(aPointer);

			const Vector<int*> constPointerVector;

			auto pointerExpression = [&constPointerVector] {constPointerVector.Front(); };
			Assert::ExpectException<exception>(pointerExpression);

			const Vector<int*> pointerVector(nonConstPointerVector);

			Assert::AreEqual(aPointer, pointerVector.Front());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerVector.Front());
			Assert::AreNotSame(aPointer, pointerVector.Front());

			//user defined class test
			Vector<TesterClass> nonConstfooVector;
			TesterClass foo(10);
			nonConstfooVector.PushBack(foo);

			Vector<TesterClass> constFooVector;

			auto fooExpression = [&constFooVector] {constFooVector.Front(); };
			Assert::ExpectException<exception>(fooExpression);

			const Vector<TesterClass> fooVector(nonConstfooVector);

			Assert::AreEqual(foo, fooVector.Front());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooVector.Front());
			Assert::AreNotSame(foo, fooVector.Front());
		}

		TEST_METHOD(VectorBegin)
		{
			//int test
			Vector<int> intVector;
			int a = 10; int b = 20;
			Vector<int>::Iterator it;

			intVector.PushBack(a);
			intVector.PushBack(b);

			it = intVector.begin();

			Assert::AreEqual(a, *it);
			Assert::AreNotEqual(b, *it);
			Assert::AreEqual(intVector.Front(), *it);

			//pointer test
			Vector<int*> pointerVector;
			int* aPointer = &a; int* bPointer = &b;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);

			Vector<int*>::Iterator pointerIt = pointerVector.begin();

			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreNotEqual(bPointer, *pointerIt);
			Assert::AreEqual(pointerVector.Front(), *pointerIt);

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);

			Vector<TesterClass>::Iterator fooIt = fooVector.begin();

			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreNotEqual(fooTwo, *fooIt);
			Assert::AreEqual(fooVector.Front(), *fooIt);

		}

		TEST_METHOD(VectorConstBegin)
		{
			//int test
			Vector<int> baseIntVector;
			int a = 10; int b = 20;

			const Vector<int> constInt;
			Vector<int>::Iterator constIt;

			baseIntVector.PushBack(a);
			baseIntVector.PushBack(b);

			const Vector<int> copyIntVector(baseIntVector);

			Vector<int>::Iterator it = copyIntVector.begin();

			Assert::AreEqual(a, *it);
			Assert::AreNotEqual(b, *it);
			Assert::AreEqual(copyIntVector.Front(), *it);

			//pointer test
			int* aPointer = &a; int* bPointer = &b;
			Vector<int*> basePointerVector;
			basePointerVector.PushBack(aPointer);
			basePointerVector.PushBack(bPointer);

			const Vector<int*> copyPointerVector(basePointerVector);

			Vector<int*>::Iterator pointerIt = copyPointerVector.begin();

			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreNotEqual(bPointer, *pointerIt);
			Assert::AreEqual(copyPointerVector.Front(), *pointerIt);

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			Vector<TesterClass> baseFooVector;

			baseFooVector.PushBack(fooOne);
			baseFooVector.PushBack(fooTwo);

			const Vector<TesterClass> copyFooVector(baseFooVector);

			Vector<TesterClass>::Iterator fooIt = copyFooVector.begin();

			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreNotEqual(fooTwo, *fooIt);
			Assert::AreEqual(copyFooVector.Front(), *fooIt);

		}

		TEST_METHOD(VectorEnd)
		{
			//int test
			Vector<int> intVector;
			int a = 10; int b = 20;
			Vector<int>::Iterator it;

			intVector.PushBack(a);
			intVector.PushBack(b);

			it = intVector.end();

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			//pointer test
			Vector<int*> pointerVector;
			int* aPointer = &a; int* bPointer = &b;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);

			Vector<int*>::Iterator pointerIt = pointerVector.end();

			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);

			Vector<TesterClass>::Iterator fooIt = fooVector.end();

			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

		}

		TEST_METHOD(VectorConstEnd)
		{
			//int test
			Vector<int> baseIntVector;
			int a = 10; int b = 20;

			const Vector<int> constInt;
			Vector<int>::Iterator constIt;

			baseIntVector.PushBack(a);
			baseIntVector.PushBack(b);

			const Vector<int> copyIntVector(baseIntVector);

			Vector<int>::Iterator it = copyIntVector.end();

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			//pointer test
			int* aPointer = &a; int* bPointer = &b;
			Vector<int*> basePointerVector;
			basePointerVector.PushBack(aPointer);
			basePointerVector.PushBack(bPointer);

			const Vector<int*> copyPointerVector(basePointerVector);

			Vector<int*>::Iterator pointerIt = copyPointerVector.end();

			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			Vector<TesterClass> baseFooVector;

			baseFooVector.PushBack(fooOne);
			baseFooVector.PushBack(fooTwo);

			const Vector<TesterClass> copyFooVector(baseFooVector);

			Vector<TesterClass>::Iterator fooIt = copyFooVector.end();

			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

		}

		TEST_METHOD(VectorPopBack)
		{
			//int test
			Vector<int> intVector;
			int a = 10; int b = 20;
			intVector.PushBack(a);
			intVector.PushBack(b);

			Assert::AreEqual(2U, intVector.Size());
			Assert::AreEqual(a, intVector.Front());
			Assert::AreEqual(b, intVector.Back());
			intVector.PopBack();
			Assert::AreEqual(1U, intVector.Size());
			Assert::AreEqual(a, intVector.Front());
			Assert::AreEqual(a, intVector.Back());
			intVector.PopBack();
			Assert::IsTrue(intVector.IsEmpty());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			Vector<int*> pointerVector;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);

			Assert::AreEqual(2U, pointerVector.Size());
			Assert::AreEqual(aPointer, pointerVector.Front());
			Assert::AreEqual(bPointer, pointerVector.Back());
			pointerVector.PopBack();
			Assert::AreEqual(1U, pointerVector.Size());
			Assert::AreEqual(aPointer, pointerVector.Front());
			Assert::AreEqual(aPointer, pointerVector.Back());
			pointerVector.PopBack();
			Assert::IsTrue(pointerVector.IsEmpty());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);

			Assert::AreEqual(2U, fooVector.Size());
			Assert::AreEqual(fooOne, fooVector.Front());
			Assert::AreEqual(fooTwo, fooVector.Back());
			fooVector.PopBack();
			Assert::AreEqual(1U, fooVector.Size());
			Assert::AreEqual(fooOne, fooVector.Front());
			Assert::AreEqual(fooOne, fooVector.Back());
			fooVector.PopBack();
			Assert::IsTrue(fooVector.IsEmpty());
		}

		TEST_METHOD(VectorPushBack)
		{
			//int test
			Vector<int> intVector;
			int a = 10; int b = 20; int c = 30;
			intVector.PushBack(a);
			intVector.PushBack(b);
			intVector.PushBack(c);
			intVector.PushBack(a);
			intVector.PushBack(b);

			Assert::IsFalse(intVector.IsEmpty());
			Assert::AreEqual(5U, intVector.Size());
			Assert::AreEqual(b, intVector.Back());
			Assert::AreEqual(c, intVector[2]);
			Assert::AreEqual(6U, intVector.Capacity());

			auto expression = [&intVector] {intVector.At(6); };
			Assert::ExpectException<exception>(expression);

			//int pointer test
			int* aPointer = &a;
			int* bPointer = &b;
			int* cPointer = &c;
			Vector<int*> pointerVector;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);
			pointerVector.PushBack(cPointer);
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);

			Assert::IsFalse(pointerVector.IsEmpty());
			Assert::AreEqual(5U, pointerVector.Size());
			Assert::AreEqual(bPointer, pointerVector.Back());
			Assert::AreEqual(cPointer, pointerVector[2]);
			Assert::AreEqual(6U, pointerVector.Capacity());

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			Vector<TesterClass> fooVector;
			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);
			fooVector.PushBack(fooThree);
			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);

			Assert::IsFalse(fooVector.IsEmpty());
			Assert::AreEqual(5U, fooVector.Size());
			Assert::AreEqual(fooTwo, fooVector.Back());
			Assert::AreEqual(fooThree, fooVector[2]);
			Assert::AreEqual(6U, fooVector.Capacity());
		}

		TEST_METHOD(VectorCopyConsrtuctor)
		{
			//int test
			Vector<int> baseIntVector;
			int a = 10; int b = 20;
			baseIntVector.PushBack(a);
			baseIntVector.PushBack(b);

			Vector<int> copyIntVector(baseIntVector);

			Assert::IsFalse(copyIntVector.IsEmpty());
			Assert::AreEqual(2U, copyIntVector.Size());
			Assert::AreNotSame(copyIntVector.Front(), copyIntVector.Back());
			Assert::AreEqual(a, copyIntVector.Front());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			Vector<int*> basePointerVector;
			basePointerVector.PushBack(aPointer);
			basePointerVector.PushBack(bPointer);

			Vector<int*> copyPointerVector(basePointerVector);

			Assert::IsFalse(copyPointerVector.IsEmpty());
			Assert::AreEqual(2U, copyPointerVector.Size());
			Assert::AreNotSame(copyPointerVector.Front(), copyPointerVector.Back());
			Assert::AreEqual(aPointer, copyPointerVector.Front());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			Vector<TesterClass> baseFooVector;

			baseFooVector.PushBack(fooOne);
			baseFooVector.PushBack(fooTwo);

			Vector<TesterClass> copyFooVector(baseFooVector);

			Assert::IsFalse(copyFooVector.IsEmpty());
			Assert::AreEqual(2U, copyFooVector.Size());
			Assert::AreNotSame(copyFooVector.Front(), copyFooVector.Back());
			Assert::AreEqual(fooOne, copyFooVector.Front());
		}

		TEST_METHOD(VectorAssignementOpertator)
		{
			//int test
			Vector<int> baseIntVector;
			int a = 10; int b = 20;
			baseIntVector.PushBack(a);
			baseIntVector.PushBack(b);

			Vector<int> copyIntVector;
			copyIntVector = baseIntVector;

			Assert::IsFalse(copyIntVector.IsEmpty());
			Assert::AreEqual(2U, copyIntVector.Size());
			Assert::AreNotSame(copyIntVector.Front(), copyIntVector.Back());
			Assert::AreEqual(a, copyIntVector.Front());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			Vector<int*> basePointerVector;
			basePointerVector.PushBack(aPointer);
			basePointerVector.PushBack(bPointer);

			Vector<int*> copyPointerVector;
			copyPointerVector = basePointerVector;

			Assert::IsFalse(copyPointerVector.IsEmpty());
			Assert::AreEqual(2U, copyPointerVector.Size());
			Assert::AreNotSame(copyPointerVector.Front(), copyPointerVector.Back());
			Assert::AreEqual(aPointer, copyPointerVector.Front());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			Vector<TesterClass> baseFooVector;

			baseFooVector.PushBack(fooOne);
			baseFooVector.PushBack(fooTwo);

			Vector<TesterClass> copyFooVector;
			copyFooVector = baseFooVector;

			Assert::IsFalse(copyFooVector.IsEmpty());
			Assert::AreEqual(2U, copyFooVector.Size());
			Assert::AreNotSame(copyFooVector.Front(), copyFooVector.Back());
			Assert::AreEqual(fooOne, copyFooVector.Front());
		}

		TEST_METHOD(VectorFind)
		{
			//int test
			Vector<int> intVector;
			int a = 10; int b = 20; int c = 30;
			intVector.PushBack(a);
			intVector.PushBack(b);

			Vector<int>::Iterator it = intVector.Find(b);
			Assert::AreEqual(b, *it);
			Assert::AreNotEqual(a, *it);

			it = intVector.Find(a);
			Assert::AreEqual(a, *it);
			Assert::AreNotEqual(b, *it);

			it = intVector.Find(c);
			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			//pointer test
			Vector<int*> pointerVector;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);

			Vector<int*>::Iterator pointerIt = pointerVector.Find(bPointer);
			Assert::AreEqual(bPointer, *pointerIt);
			Assert::AreNotEqual(aPointer, *pointerIt);

			pointerIt = pointerVector.Find(aPointer);
			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreNotEqual(bPointer, *pointerIt);

			pointerIt = pointerVector.Find(cPointer);
			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);

			Vector<TesterClass>::Iterator fooIt = fooVector.Find(fooTwo);
			Assert::AreEqual(fooTwo, *fooIt);
			Assert::AreNotEqual(fooOne, *fooIt);

			fooIt = fooVector.Find(fooOne);
			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreNotEqual(fooTwo, *fooIt);

			fooIt = fooVector.Find(fooThree);
			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

		}

		TEST_METHOD(VectorRemove)
		{
			//int test
			Vector<int> intVector;
			int a = 10; int b = 20; int c = 30;
			intVector.PushBack(b);
			intVector.PushBack(a);
			intVector.PushBack(a);
			intVector.PushBack(c);

			intVector.Remove(c);

			Vector<int>::Iterator it = intVector.Find(c);
			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);
			Assert::AreEqual(3U, intVector.Size());
			Assert::AreEqual(4U, intVector.Capacity());

			Assert::IsFalse(intVector.Remove(c));

			intVector.Remove(a);

			it = intVector.Find(a);
			Assert::AreEqual(a, *it);
			Assert::AreEqual(2U, intVector.Size());

			//pointer test
			Vector<int*> pointerVector;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(cPointer);

			pointerVector.Remove(cPointer);

			Vector<int*>::Iterator pointerIt = pointerVector.Find(cPointer);
			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);
			Assert::AreEqual(3U, pointerVector.Size());
			Assert::AreEqual(4U, pointerVector.Capacity());

			Assert::IsFalse(pointerVector.Remove(cPointer));

			pointerVector.Remove(aPointer);

			pointerIt = pointerVector.Find(aPointer);
			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreEqual(2U, pointerVector.Size());

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooThree);
			fooVector.PushBack(fooTwo);
			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooOne);

			fooVector.Remove(fooThree);

			Vector<TesterClass>::Iterator fooIt = fooVector.Find(fooThree);
			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);
			Assert::AreEqual(3U, fooVector.Size());
			Assert::AreEqual(4U, fooVector.Capacity());

			Assert::IsFalse(fooVector.Remove(fooThree));

			fooVector.Remove(fooOne);

			fooIt = fooVector.Find(fooOne);
			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreEqual(2U, fooVector.Size());
		}

		TEST_METHOD(VectorRemoveIterator)
		{//int test
			Vector<int> intVector;
			int a = 10; int b = 20; int c = 30;
			intVector.PushBack(b);
			intVector.PushBack(a);
			intVector.PushBack(a);
			intVector.PushBack(c);

			Vector<int>::Iterator it = intVector.Find(c);

			intVector.Remove(it);

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			Assert::AreEqual(3U, intVector.Size());
			Assert::AreEqual(4U, intVector.Capacity());
			
			it = intVector.Find(a);

			intVector.Remove(it);

			it = intVector.Find(a);
			Assert::AreEqual(a, *it);
			Assert::AreEqual(2U, intVector.Size());

			//pointer test
			Vector<int*> pointerVector;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(cPointer);
			
			Vector<int*>::Iterator pointerIt = pointerVector.Find(cPointer);

			pointerVector.Remove(pointerIt);

			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			Assert::AreEqual(3U, pointerVector.Size());
			Assert::AreEqual(4U, pointerVector.Capacity());

			pointerIt = pointerVector.Find(aPointer);

			pointerVector.Remove(pointerIt);

			pointerIt = pointerVector.Find(aPointer);
			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreEqual(2U, pointerVector.Size());

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);
			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooThree);

			Vector<TesterClass>::Iterator fooIt = fooVector.Find(fooThree);

			fooVector.Remove(fooIt);

			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

			Assert::AreEqual(3U, fooVector.Size());
			Assert::AreEqual(4U, fooVector.Capacity());

			fooIt = fooVector.Find(fooOne);

			fooVector.Remove(fooIt);

			fooIt = fooVector.Find(fooOne);
			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreEqual(2U, fooVector.Size());
		}

		TEST_METHOD(VectorRangedRemoveIterator)
		{
			//int test
			Vector<int> intVector;
			Vector<int> otherintVector;
			int a = 10; int b = 20; int c = 30;
			intVector.PushBack(b);
			intVector.PushBack(a);
			intVector.PushBack(c);
			intVector.PushBack(a);

			otherintVector.PushBack(b);
			Vector<int> newIntVector(intVector);
			Vector<int>::Iterator itStart = intVector.Find(b);
			Vector<int>::Iterator itEnd = intVector.Find(c);

			intVector.Remove(itStart, itEnd);

			Assert::AreEqual(1U, intVector.Size());
			Assert::AreEqual(4U, intVector.Capacity());
			Assert::AreEqual(a, intVector[0]);
			Assert::IsFalse(intVector.IsEmpty());

			Assert::ExpectException<exception>([&newIntVector, &itStart, &itEnd] {newIntVector.Remove(itStart, itEnd); });

			itStart = otherintVector.Find(b);

			auto ExpressionRemove = [&intVector, &itStart, &itEnd] {intVector.Remove(itStart, itEnd);; };
			Assert::ExpectException<exception>(ExpressionRemove);
			

			//pointer test
			Vector<int*> pointerVector;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(bPointer);
			pointerVector.PushBack(aPointer);
			pointerVector.PushBack(cPointer);

			Vector<int*>::Iterator pointerItStart = pointerVector.Find(bPointer);
			Vector<int*>::Iterator pointerItEnd = pointerVector.Find(cPointer);
			
			pointerVector.Remove(pointerItStart, pointerItEnd);

			Assert::AreEqual(1U, pointerVector.Size());
			Assert::AreEqual(4U, pointerVector.Capacity());
			Assert::AreEqual(aPointer, pointerVector[0]);
			Assert::IsFalse(pointerVector.IsEmpty());


			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			Vector<TesterClass> fooVector;

			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooTwo);
			fooVector.PushBack(fooOne);
			fooVector.PushBack(fooThree);

			Vector<TesterClass>::Iterator fooItStart = fooVector.Find(fooTwo);
			Vector<TesterClass>::Iterator fooItEnd = fooVector.Find(fooOne);

			auto fooExpressionRemove = [&fooVector, &fooItStart, &fooItEnd] {fooVector.Remove(fooItStart, fooItEnd); };
			Assert::ExpectException<exception>(fooExpressionRemove);

			fooItEnd = fooVector.Find(fooThree);

			fooVector.Remove(fooItStart, fooItEnd);

			Assert::AreEqual(1U, fooVector.Size());
			Assert::AreEqual(4U, fooVector.Capacity());
			Assert::AreEqual(fooOne, fooVector[0]);
			Assert::IsFalse(fooVector.IsEmpty());
		}

		TEST_METHOD(VectorIteratorConstOperatorTest)
		{
			//int test
			Vector<TesterClass> baseVector;
			TesterClass a(10); TesterClass b(20);

			const Vector<TesterClass> constVector;
			Vector<TesterClass>::Iterator constIt;

			auto failExpression = [&constIt] {*constIt; };
			Assert::ExpectException<exception>(failExpression);
			Assert::ExpectException<exception>([&constIt] {++constIt; });
			baseVector.PushBack(a);
			baseVector.PushBack(b);

			auto failIntExpression = [&baseVector] {baseVector[3]; };
			Assert::ExpectException<exception>(failIntExpression);

			const Vector<TesterClass> copyVector(baseVector);

			Assert::AreEqual(a, copyVector.At(0));

			auto failAtExpression = [&copyVector] {copyVector.At(3); };
			Assert::ExpectException<exception>(failAtExpression);

			const Vector<TesterClass>::Iterator it = copyVector.end();

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);
			
			const Vector<TesterClass>::Iterator newIt;

			auto newExpression = [&newIt] {*newIt; };
			Assert::ExpectException<exception>(newExpression);

			const Vector<TesterClass>::Iterator constDereferenceCheckIt = copyVector.begin();
			Assert::AreEqual(a, *constDereferenceCheckIt);

			constIt = baseVector.begin();
			constIt++;
			Assert::AreEqual(b, *constIt);
		}

	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState VectorTest::sStartMemState;
}