#include "pch.h"
#include "JsonParseHelperTable.h"
#include "EngineFactory.h"
#include "Event.h"
#include "World.h"
#include "ReactionAttributed.h"
#include "ActionEvent.h"
#include "EventMessageAttributed.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{

	TEST_CLASS(ReactionTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			Event<EventMessageAttributed>::StrinkList();
			Event<EventMessageAttributed>::UnSubscribeAll();
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			Event<EventMessageAttributed>::StrinkList();
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(ReactionCreate)
		{
			World baseWorld;
			GameTime time;
			baseWorld.SetName("BaseWorld");
			baseWorld.GetWorldState().SetGameTime(time);
			baseWorld.GetWorldState().CurrentWorld = &baseWorld;

			Assert::AreEqual(0U, baseWorld.GetEventQueue().Size());

			ActionEvent testActionEvent;
			testActionEvent.Update(baseWorld.GetWorldState());
			ReactionAttributed testReaction;

			Assert::AreEqual(1U, baseWorld.GetEventQueue().Size());

			Event<EventMessageAttributed>::UnSubscribe(testReaction);
		}

		TEST_METHOD(ReactionParse)
		{
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionEventFactory actionEventFactory;
			ConcreteReactionAttributedFactory reactionAttributedFactory;

			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			testParseMaster.ParseFromFile("Script/ReactionScript.json");

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Assert::IsNotNull(baseWorld);

			ReactionAttributed* testReaction = baseWorld->Find("Reactions")->Get<Scope*>()->As<ReactionAttributed>();
			Assert::IsNotNull(testReaction);

			Sector * sector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>();
			Assert::IsNotNull(sector);
			Entity* player = sector->GetEntities().Get<Scope*>()->As<Entity>();
			Assert::IsNotNull(player);
			ActionList* run = player->GetActions().Get<Scope*>()->As<ActionList>();
			Assert::IsNotNull(run);
			ActionList* walk = run->GetActions().Get<Scope*>(1)->As<ActionList>();
			Assert::IsNotNull(walk);

			ActionEvent* testActionEvent = run->GetActions().Get<Scope*>()->As<ActionEvent>();
			Assert::IsNotNull(testActionEvent);

			Assert::AreEqual("String"s, testReaction->Find("Subtype")->Get<string>());
			Assert::AreEqual("String"s, testActionEvent->Find("Subtype")->Get<string>());
			Assert::AreEqual(1000, testActionEvent->Find("Delay")->Get<int>());

			Event<EventMessageAttributed>::UnSubscribe(*testReaction);
		}

		TEST_METHOD(ReactionMove)
		{
			World baseWorld;
			GameTime time;
			baseWorld.SetName("BaseWorld");
			baseWorld.GetWorldState().SetGameTime(time);
			baseWorld.GetWorldState().CurrentWorld = &baseWorld;

			Assert::AreEqual(0U, baseWorld.GetEventQueue().Size());

			ActionEvent testActionEvent;
			ActionEvent otherTestActionEvent(move(testActionEvent));
			ActionEvent tempAction;
			tempAction = move(otherTestActionEvent);

			ReactionAttributed testReaction;
			ReactionAttributed testReactionOne(move(testReaction));
			ReactionAttributed testReactionTwo;
			testReactionTwo = move(testReactionOne);
			baseWorld.Update();

			Assert::AreEqual(0U, baseWorld.GetEventQueue().Size());

			EventMessageAttributed message;
			EventMessageAttributed messageHolder(move(message));
			EventMessageAttributed contrivedMessage;
			contrivedMessage = move(messageHolder);

			Assert::AreEqual(0U, baseWorld.GetEventQueue().Size());

			Event<EventMessageAttributed>::UnSubscribeAll();
		}

		TEST_METHOD(ReactionUpdate)
		{
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionEventFactory actionEventFactory;
			ConcreteReactionAttributedFactory reactionAttributedFactory;

			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			testParseMaster.ParseFromFile("Script/ReactionScript.json");

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Assert::IsNotNull(baseWorld);
			GameTime time;
			baseWorld->GetWorldState().SetGameTime(time);

			ReactionAttributed* testReaction = baseWorld->Find("Reactions")->Get<Scope*>()->As<ReactionAttributed>();
			Assert::IsNotNull(testReaction);

			Sector * sector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>();
			Assert::IsNotNull(sector);
			Entity* player = sector->GetEntities().Get<Scope*>()->As<Entity>();
			Assert::IsNotNull(player);
			ActionList* run = player->GetActions().Get<Scope*>()->As<ActionList>();
			Assert::IsNotNull(run);
			ActionList* walk = run->GetActions().Get<Scope*>(1)->As<ActionList>();
			Assert::IsNotNull(walk);

			ActionEvent* testActionEvent = run->GetActions().Get<Scope*>()->As<ActionEvent>();
			Assert::IsNotNull(testActionEvent);

			Assert::IsNull(testReaction->Find("Aux"));
			Assert::IsNull(testReaction->Find("AuxScope"));
			Assert::IsNotNull(testActionEvent->Find("Aux"));
			Assert::IsNotNull(testActionEvent->Find("AuxScope"));

			baseWorld->Update();

			Assert::IsNull(testReaction->Find("Aux"));
			Assert::IsNull(testReaction->Find("AuxScope"));

			chrono::steady_clock::time_point tempPoint(chrono::milliseconds(2000));
			time.SetCurrentTime(tempPoint);
			baseWorld->Update();

			Assert::IsNotNull(testReaction->Find("Aux"));
			Assert::IsNotNull(testReaction->Find("AuxScope"));

			Event<EventMessageAttributed>::UnSubscribe(*testReaction);
		}

		

	private:
		static _CrtMemState sStartMemState;
		EventMessageAttributed baseMessage;
		Event<EventMessageAttributed> stuff;
		ReactionAttributed baseReaction;
		ActionEvent ae;

		Entity e;
		World w;
		Sector s;
		ActionList a;
	};

	_CrtMemState ReactionTest::sStartMemState;
}