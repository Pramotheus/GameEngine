#include "pch.h"
#include "Event.h"
#include "EventQueue.h"
#include "EventPublisher.h"
#include "EventSubscriber.h"
#include "FooSubscriber.h"
#include "TesterClass.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{

	TEST_CLASS(EventTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			Event<TesterClass>::StrinkList();
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			Event<TesterClass>::StrinkList();
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(EventEnqueue)
		{
			
			Event<TesterClass> event;
			GameTime tempTime;
			shared_ptr<Event<TesterClass>> eventPtr = make_shared<Event<TesterClass>>(event);
			EventQueue eventQueue;

			Assert::IsTrue(eventQueue.IsEmpty());
			eventQueue.Enqueue(eventPtr, tempTime);
			Assert::AreEqual(1U, eventQueue.Size());
			eventQueue.Clear();
			Assert::IsTrue(eventQueue.IsEmpty());

			Event<TesterClass>::UnSubscribeAll();
		}

		TEST_METHOD(EventSubscribe)
		{
			Event<TesterClass> event;
			TesterClass& Foo = event.Message();
			GameTime tempTime;
			shared_ptr<Event<TesterClass>> eventPtr = make_shared<Event<TesterClass>>(event);
		
			FooSubscriber fooSub;
			Assert::IsFalse(fooSub.mNotified);
			event.Subscribe(fooSub);

			Assert::AreSame(Foo, event.Message());
			Assert::IsFalse(fooSub.mNotified);
			event.Deliver();
			Assert::IsTrue(fooSub.mNotified);

			Event<TesterClass>::UnSubscribeAll();
		}

		TEST_METHOD(EventQueueUpdate)
		{
			GameTime tempTime;
			shared_ptr<Event<TesterClass>> eventPtr = make_shared<Event<TesterClass>>(Event<TesterClass>());
			TesterClass Foo = eventPtr->Message();
			EventQueue eventQueue;

			FooSubscriber fooSub;
			eventPtr->Subscribe(fooSub);

			Assert::IsTrue(eventQueue.IsEmpty());
			eventQueue.Enqueue(eventPtr, tempTime, chrono::milliseconds(1000));
			Assert::AreEqual(1U, eventQueue.Size());

			Assert::IsTrue(chrono::milliseconds(1000) == eventPtr->Delay());
			Assert::IsFalse(eventPtr->IsExpired(tempTime.CurrentTime()));

			eventQueue.Update(tempTime);
			Assert::IsFalse(fooSub.mNotified);

			chrono::steady_clock::time_point tempPoint(chrono::milliseconds(1000));
			tempTime.SetCurrentTime(tempPoint);
			EventPublisher::TypeIdClass();
			eventQueue.Update(tempTime);
			Assert::IsFalse(fooSub.mNotified);

			chrono::steady_clock::time_point point(chrono::milliseconds(2000));
			tempTime.SetCurrentTime(point);
			eventQueue.Update(tempTime);
			Assert::IsTrue(fooSub.mNotified);

			fooSub.mNotified = false;
			eventQueue.Update(tempTime);
			Assert::IsFalse(fooSub.mNotified);

			Event<TesterClass>::UnSubscribeAll();
		}

		TEST_METHOD(EventQueueSend)
		{
			GameTime tempTime;
			shared_ptr<Event<TesterClass>> eventPtr = make_shared<Event<TesterClass>>(Event<TesterClass>());
			TesterClass Foo = eventPtr->Message();
			EventQueue eventQueue;

			FooSubscriber fooSub;

			eventPtr->Subscribe(fooSub);

			Assert::IsTrue(eventQueue.IsEmpty());
			eventQueue.Enqueue(eventPtr, tempTime, chrono::milliseconds(1000));
			Assert::AreEqual(1U, eventQueue.Size());

			chrono::steady_clock::time_point zero(chrono::milliseconds(0));
			Assert::IsTrue(chrono::milliseconds(1000) == eventPtr->Delay());
			Assert::IsTrue(zero == eventPtr->TimeEnqueued());
			Assert::IsFalse(eventPtr->IsExpired(tempTime.CurrentTime()));

			eventQueue.Update(tempTime);
			Assert::IsFalse(fooSub.mNotified);

			eventQueue.Send(eventPtr);
			Assert::IsTrue(fooSub.mNotified);

			Event<TesterClass>::UnSubscribeAll();
		}

	private:
		static _CrtMemState sStartMemState;
		Event<TesterClass> ETC;
	};

	_CrtMemState EventTest::sStartMemState;
}