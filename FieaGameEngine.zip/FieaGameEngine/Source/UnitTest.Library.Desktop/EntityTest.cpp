#include "pch.h"
#include "JsonParseHelperTable.h"
#include "EngineFactory.h"
#include "Entity.h"
#include "Sector.h"
#include "World.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{

	ConcreteFactory(Entity, Entity)

	TEST_CLASS(EntityTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(WorldParse)
		{
			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);
			ConcreteEntityFactory baseEntityFactory;

			testParseMaster.ParseFromFile("Script/EntityScript.json");

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Sector * firstSector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>(); 
			Entity* playerBaseEntity = firstSector->GetEntities().Get<Scope*>()->As<Entity>();
			Assert::AreEqual(100, playerBaseEntity->Find("Health")->Get<int32_t>());
			Assert::AreEqual("FirstSector"s, firstSector->Name());
			Assert::AreEqual("Player"s, playerBaseEntity->Name());

			Assert::IsTrue(firstSector == &playerBaseEntity->GetSector());
			Assert::IsTrue(baseWorld == &firstSector->GetWorld());
		}

		TEST_METHOD(MultiSectorParse)
		{
			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);
			ConcreteEntityFactory baseEntityFactory;

			testParseMaster.ParseFromFile("Script/EntityScript.json");

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Sector * secondSector = baseWorld->GetSectors().Get<Scope*>(1)->As<Sector>();
			Entity* blobEntity = secondSector->GetEntities().Get<Scope*>(0)->As<Entity>();
			Entity* bossEntity = secondSector->GetEntities().Get<Scope*>(1)->As<Entity>();
			Assert::AreEqual(200, blobEntity->Find("Health")->Get<int32_t>());
			Assert::IsTrue(bossEntity->Find("Health")->Get<int32_t>() > 9000);
			Assert::AreEqual("SecondSector"s, secondSector->Name());
			Assert::AreEqual("Blob"s, blobEntity->Name());
			Assert::AreEqual("Boss"s, bossEntity->Name());
		}

		TEST_METHOD(WorldUpdateTest)
		{
			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);
			ConcreteEntityFactory baseEntityFactory;

			testParseMaster.ParseFromFile("Script/EntityScript.json");

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Sector * secondSector = baseWorld->GetSectors().Get<Scope*>(1)->As<Sector>();
			Entity* blobEntity = secondSector->GetEntities().Get<Scope*>(0)->As<Entity>(); blobEntity;
			Entity* bossEntity = secondSector->GetEntities().Get<Scope*>(1)->As<Entity>(); bossEntity;

			WorldState &state = baseWorld->GetWorldState();
			Assert::IsNull(state.CurrentWorld);
			baseWorld->Update();
			Assert::IsNull(state.CurrentWorld);
		}

		TEST_METHOD(WorldMoveTest)
		{
			ConcreteEntityFactory baseEntityFactory;

			World baseWorld;
			baseWorld.SetName("BaseWorld");
			Sector* firstSector = baseWorld.CreateSector("firstSector");
			Entity* monster = firstSector->CreateEntity("Entity", "Monster"); monster;

			World constructorMoveWorld(std::move(baseWorld));
			Sector * constructorMoveSector = static_cast<Sector*>(constructorMoveWorld.GetSectors().Get<Scope*>()); constructorMoveSector;
			Entity* constructorMoveEntity = constructorMoveSector->GetEntities().Get<Scope*>()->As<Entity>(); constructorMoveEntity;

			Assert::AreEqual("firstSector"s, constructorMoveSector->Name());
			Assert::AreEqual(monster->Name(), constructorMoveEntity->Name());
			Assert::AreEqual("BaseWorld"s, constructorMoveWorld.Name());

			World MoveWorld;
			MoveWorld = std::move(constructorMoveWorld);

			Sector * MoveSector = static_cast<Sector*>(MoveWorld.GetSectors().Get<Scope*>()); MoveSector;
			Entity* MoveEntity = MoveSector->GetEntities().Get<Scope*>()->As<Entity>(); MoveEntity;

			Assert::AreEqual("firstSector"s, MoveSector->Name());
			Assert::AreEqual("Monster"s, MoveEntity->Name());
			Assert::AreEqual("BaseWorld"s, MoveWorld.Name());

			constructorMoveSector = std::move(MoveSector);
			Assert::AreEqual("firstSector"s, constructorMoveSector->Name());

			constructorMoveEntity = std::move(MoveEntity);
			Assert::AreEqual("Monster"s, constructorMoveEntity->Name());

			Entity Ent;
			Ent.SetName("Goblin");
			Sector Sec(std::move(*constructorMoveSector)) , Sec2;

			Entity E2(std::move(Ent)), E3;
			Assert::AreEqual("firstSector"s, Sec.Name());
			Assert::AreEqual("Goblin"s, E2.Name());

			E3 = std::move(E2);
			Sec2 = std::move(Sec);

			Assert::AreEqual("firstSector"s, Sec2.Name());
			Assert::AreEqual("Goblin"s, E3.Name());
		}

		TEST_METHOD(WorldCopyTest)
		{
			ConcreteEntityFactory baseEntityFactory;

			World baseWorld;
			baseWorld.SetName("BaseWorld");
			
			Sector baseSector;
			baseSector.SetName("BadaBoom");
			Sector copySector(baseSector);

			Assert::AreEqual(baseSector.Name(), copySector.Name());

			Sector otherCopySector;
			otherCopySector = baseSector;

			Assert::AreEqual(baseSector.Name(), otherCopySector.Name());
			
		}

	private:
		static _CrtMemState sStartMemState;
		Entity e;
		World w;
		Sector s;
	};

	_CrtMemState EntityTest::sStartMemState;
}