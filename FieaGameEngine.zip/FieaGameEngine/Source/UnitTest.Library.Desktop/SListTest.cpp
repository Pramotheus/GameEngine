#include "pch.h"
#include "SList.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{		
	TEST_CLASS(SListTest)
	{

	public:
		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(SListBack)
		{
			//int test
			SList<int> intList;
			int a = 10;

			auto expression = [&intList] {intList.Back(); };
			Assert::ExpectException<exception>(expression);

			intList.PushFront(a);

			Assert::AreEqual(a, intList.Back());
			a = 20;
			Assert::AreNotEqual(a, intList.Back());
			Assert::AreNotSame(a, intList.Back());


			//int pointer test
			int* aPointer = &a;
			SList<int*> pointerList;

			auto pointerExpression = [&pointerList] {pointerList.Back(); };
			Assert::ExpectException<exception>(pointerExpression);

			pointerList.PushFront(aPointer);

			Assert::AreEqual(aPointer, pointerList.Back());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerList.Back());
			Assert::AreNotSame(aPointer, pointerList.Back());

			//user defined class test
			TesterClass foo(10);
			SList<TesterClass> fooList;

			auto fooExpression = [&fooList] {fooList.Back(); };
			Assert::ExpectException<exception>(fooExpression);

			fooList.PushFront(foo);
			if (true)
			{
				TesterClass stuff(20);
			}

			Assert::AreEqual(foo, fooList.Back());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooList.Back());
			Assert::AreNotSame(foo, fooList.Back());
		}

		TEST_METHOD(SListFront)
		{
			//int test
			SList<int> intList;
			int a = 10;

			auto expression = [&intList] {intList.Front(); };
			Assert::ExpectException<exception>(expression);

			intList.PushFront(a);

			Assert::AreEqual(a, intList.Front());
			a = 20;
			Assert::AreNotEqual(a, intList.Front());
			Assert::AreNotSame(a, intList.Front());
			

			//int pointer test
			int* aPointer = &a;
			SList<int*> pointerList;

			auto pointerExpression = [&pointerList] {pointerList.Front(); };
			Assert::ExpectException<exception>(pointerExpression);

			pointerList.PushFront(aPointer);

			Assert::AreEqual(aPointer, pointerList.Front());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerList.Front());
			Assert::AreNotSame(aPointer, pointerList.Front());

			//user defined class test
			TesterClass foo(10);
			SList<TesterClass> fooList;

			auto fooExpression = [&fooList] {fooList.Front(); };
			Assert::ExpectException<exception>(fooExpression);

			fooList.PushFront(foo);

			Assert::AreEqual(foo, fooList.Front());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooList.Front());
			Assert::AreNotSame(foo, fooList.Front());
		}

		TEST_METHOD(SListConstBack)
		{
			//int test
			SList<int> nonConstIntList;
			int a = 10;
			nonConstIntList.PushFront(a);

			const SList<int> constIntList;

			auto expression = [&constIntList] {constIntList.Back(); };
			Assert::ExpectException<exception>(expression);

			const SList<int> intList(nonConstIntList);
			
			Assert::AreEqual(a, intList.Back());
			a = 20;
			Assert::AreNotEqual(a, intList.Back());
			Assert::AreNotSame(a, intList.Back());


			//int pointer test
			SList<int*> nonConstPointerList;
			int* aPointer = &a;
			nonConstPointerList.PushFront(aPointer);

			const SList<int*> constPointerList;

			auto pointerExpression = [&constPointerList] {constPointerList.Back(); };
			Assert::ExpectException<exception>(pointerExpression);

			const SList<int*> pointerList(nonConstPointerList);

			Assert::AreEqual(aPointer, pointerList.Back());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerList.Back());
			Assert::AreNotSame(aPointer, pointerList.Back());

			//user defined class test
			SList<TesterClass> nonConstfooList;
			TesterClass foo(10);
			nonConstfooList.PushFront(foo);

			SList<TesterClass> constFooList;

			auto fooExpression = [&constFooList] {constFooList.Back(); };
			Assert::ExpectException<exception>(fooExpression);

			const SList<TesterClass> fooList(nonConstfooList);
			
			Assert::AreEqual(foo, fooList.Back());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooList.Back());
			Assert::AreNotSame(foo, fooList.Back());
		}

		TEST_METHOD(SListConstFront)
		{
			//int test
			SList<int> nonConstIntList;
			int a = 10;
			nonConstIntList.PushFront(a);

			const SList<int> constIntList;

			auto expression = [&constIntList] {constIntList.Front(); };
			Assert::ExpectException<exception>(expression);

			const SList<int> intList(nonConstIntList);

			Assert::AreEqual(a, intList.Front());
			a = 20;
			Assert::AreNotEqual(a, intList.Front());
			Assert::AreNotSame(a, intList.Front());


			//int pointer test
			SList<int*> nonConstPointerList;
			int* aPointer = &a;
			nonConstPointerList.PushFront(aPointer);

			const SList<int*> constPointerList;

			auto pointerExpression = [&constPointerList] {constPointerList.Front(); };
			Assert::ExpectException<exception>(pointerExpression);

			const SList<int*> pointerList(nonConstPointerList);

			Assert::AreEqual(aPointer, pointerList.Front());
			int b;
			aPointer = &b;
			Assert::AreNotEqual(aPointer, pointerList.Front());
			Assert::AreNotSame(aPointer, pointerList.Front());

			//user defined class test
			SList<TesterClass> nonConstfooList;
			TesterClass foo(10);
			nonConstfooList.PushFront(foo);

			SList<TesterClass> constFooList;

			auto fooExpression = [&constFooList] {constFooList.Front(); };
			Assert::ExpectException<exception>(fooExpression);

			const SList<TesterClass> fooList(nonConstfooList);

			Assert::AreEqual(foo, fooList.Front());
			foo.SetData(20);
			Assert::AreNotEqual(foo, fooList.Front());
			Assert::AreNotSame(foo, fooList.Front());
		}

		TEST_METHOD(SListClear)
		{
			//int test
			SList<int> intList;
			int a = 10; int b = 20;

			intList.PushFront(a);
			intList.PushFront(b);
			Assert::AreEqual(2U, intList.Size());
			intList.Clear();
			Assert::AreEqual(0U, intList.Size());
			Assert::IsTrue(intList.IsEmpty());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			SList<int*> pointerList;

			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);
			Assert::AreEqual(2U, pointerList.Size());
			pointerList.Clear();
			Assert::AreEqual(0U, pointerList.Size());
			Assert::IsTrue(pointerList.IsEmpty());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);

			Assert::AreEqual(2U, fooList.Size());
			fooList.Clear();
			Assert::AreEqual(0U, fooList.Size());
			Assert::IsTrue(fooList.IsEmpty());
		}

		TEST_METHOD(SListPushFront)
		{
			//int test
			SList<int> intList;
			int a = 10;
			intList.PushFront(a);

			Assert::IsFalse(intList.IsEmpty());
			Assert::AreEqual(1U, intList.Size());
			Assert::AreSame(intList.Front(), intList.Back());
			Assert::AreEqual(a, intList.Front());

			//int pointer test
			int* aPointer = &a;
			SList<int*> pointerList;
			pointerList.PushFront(aPointer);

			Assert::IsFalse(pointerList.IsEmpty());
			Assert::AreEqual(1U, pointerList.Size());
			Assert::AreSame(pointerList.Front(), pointerList.Back());
			Assert::AreEqual(aPointer, pointerList.Front());

			//user defined class test
			TesterClass foo(10);
			SList<TesterClass> fooList;
			fooList.PushFront(foo);

			Assert::IsFalse(fooList.IsEmpty());
			Assert::AreEqual(1U, fooList.Size());
			Assert::AreSame(fooList.Front(), fooList.Back());
			Assert::AreEqual(foo, fooList.Front());
		}

		TEST_METHOD(SListPushBack)
		{
			//int test
			SList<int> intList;
			int a = 10;
			intList.PushBack(a);

			Assert::IsFalse(intList.IsEmpty());
			Assert::AreEqual(1U, intList.Size());
			Assert::AreSame(intList.Front(), intList.Back());
			Assert::AreEqual(a, intList.Back());

			//int pointer test
			int* aPointer = &a;
			SList<int*> pointerList;
			pointerList.PushBack(aPointer);

			Assert::IsFalse(pointerList.IsEmpty());
			Assert::AreEqual(1U, pointerList.Size());
			Assert::AreSame(pointerList.Front(), pointerList.Back());
			Assert::AreEqual(aPointer, pointerList.Back());

			//user defined class test
			TesterClass foo(10);
			SList<TesterClass> fooList;
			fooList.PushBack(foo);

			Assert::IsFalse(fooList.IsEmpty());
			Assert::AreEqual(1U, fooList.Size());
			Assert::AreSame(fooList.Front(), fooList.Back());
			Assert::AreEqual(foo, fooList.Back());
		}

		TEST_METHOD(SListPopFront)
		{
			//int test
			SList<int> intList;
			int a = 10; int b = 20;
			intList.PushFront(a);
			intList.PushFront(b);

			Assert::AreEqual(2U, intList.Size());
			Assert::AreEqual(b, intList.Front());
			Assert::AreEqual(a, intList.Back());
			intList.PopFront();
			Assert::AreEqual(1U, intList.Size());
			Assert::AreEqual(a, intList.Front());
			Assert::AreEqual(a, intList.Back());
			intList.PopFront();
			Assert::IsTrue(intList.IsEmpty());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			SList<int*> pointerList;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);

			Assert::AreEqual(2U, pointerList.Size());
			Assert::AreEqual(bPointer, pointerList.Front());
			Assert::AreEqual(aPointer, pointerList.Back());
			pointerList.PopFront();
			Assert::AreEqual(1U, pointerList.Size());
			Assert::AreEqual(aPointer, pointerList.Front());
			Assert::AreEqual(aPointer, pointerList.Back());
			pointerList.PopFront();
			Assert::IsTrue(pointerList.IsEmpty());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);

			Assert::AreEqual(2U, fooList.Size());
			Assert::AreEqual(fooTwo, fooList.Front());
			Assert::AreEqual(fooOne, fooList.Back());
			fooList.PopFront();
			Assert::AreEqual(1U, fooList.Size());
			Assert::AreEqual(fooOne, fooList.Front());
			Assert::AreEqual(fooOne, fooList.Back());
			fooList.PopFront();
			Assert::IsTrue(fooList.IsEmpty());
		}

		TEST_METHOD(SListSize)
		{
			//int test
			SList<int> intList;
			int a = 10;

			Assert::AreEqual(0U, intList.Size());
			Assert::IsTrue(intList.IsEmpty());
			intList.PushFront(a);
			Assert::AreEqual(1U, intList.Size());
			
			//int pointer test
			int* aPointer = &a;
			SList<int*> pointerList;

			Assert::AreEqual(0U, pointerList.Size());
			Assert::IsTrue(pointerList.IsEmpty());
			pointerList.PushFront(aPointer);
			Assert::AreEqual(1U, pointerList.Size());

			//user defined class test
			TesterClass foo(10);
			SList<TesterClass> fooList;

			Assert::AreEqual(0U, fooList.Size());
			Assert::IsTrue(fooList.IsEmpty());
			fooList.PushBack(foo);
			Assert::AreEqual(1U, fooList.Size());
		}

		TEST_METHOD(SListIsEmpty)
		{
			//int test
			SList<int> intList;
			int a = 10;

			intList.PushFront(a);
			Assert::IsFalse(intList.IsEmpty());
			Assert::AreEqual(1U, intList.Size());
			intList.Clear();
			Assert::IsTrue(intList.IsEmpty());

			//int pointer test
			int* aPointer = &a;
			SList<int*> pointerList;

			pointerList.PushFront(aPointer);
			Assert::IsFalse(pointerList.IsEmpty());
			Assert::AreEqual(1U, pointerList.Size());
			pointerList.Clear();
			Assert::IsTrue(pointerList.IsEmpty());

			//user defined class test
			TesterClass foo(10);
			SList<TesterClass> fooList;

			fooList.PushFront(foo);
			Assert::IsFalse(fooList.IsEmpty());
			Assert::AreEqual(1U, fooList.Size());
			fooList.Clear();
			Assert::IsTrue(fooList.IsEmpty());
		}

		TEST_METHOD(SListConstructor)
		{
			//int test
			SList<int> intList;
			
			Assert::IsTrue(intList.IsEmpty());
			Assert::AreEqual(0U, intList.Size());

			//int pointer test
			SList<int*> pointerList;

			Assert::IsTrue(pointerList.IsEmpty());
			Assert::AreEqual(0U, pointerList.Size());

			//user defined class test
			SList<TesterClass> fooList;

			Assert::IsTrue(fooList.IsEmpty());
			Assert::AreEqual(0U, fooList.Size());
		}

		TEST_METHOD(SListCopyConsrtuctor)
		{
			//int test
			SList<int> baseIntList;
			int a = 10; int b = 20;
			baseIntList.PushFront(a);
			baseIntList.PushFront(b);

			SList<int> copyIntList(baseIntList);

			Assert::IsFalse(copyIntList.IsEmpty());
			Assert::AreEqual(2U, copyIntList.Size());
			Assert::AreNotSame(copyIntList.Front(), copyIntList.Back());
			Assert::AreEqual(b, copyIntList.Front());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			SList<int*> basePointerList;
			basePointerList.PushFront(aPointer);
			basePointerList.PushFront(bPointer);

			SList<int*> copyPointerList(basePointerList);

			Assert::IsFalse(copyPointerList.IsEmpty());
			Assert::AreEqual(2U, copyPointerList.Size());
			Assert::AreNotSame(copyPointerList.Front(), copyPointerList.Back());
			Assert::AreEqual(bPointer, copyPointerList.Front());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			SList<TesterClass> baseFooList;

			baseFooList.PushFront(fooOne);
			baseFooList.PushFront(fooTwo);

			SList<TesterClass> copyFooList(baseFooList);

			Assert::IsFalse(copyFooList.IsEmpty());
			Assert::AreEqual(2U, copyFooList.Size());
			Assert::AreNotSame(copyFooList.Front(), copyFooList.Back());
			Assert::AreEqual(fooTwo, copyFooList.Front());
		}

		TEST_METHOD(SListDistructor)
		{
			//int test
			SList<int> *intList = new SList<int>();
			delete intList;

			//int pointer test
			SList<int*> *pointerList = new SList<int*>();
			delete pointerList;

			//user defined class test
			SList<TesterClass> *fooList = new SList<TesterClass>();
			delete fooList;
		}

		TEST_METHOD(SListAssignementOpertator)
		{
			//int test
			SList<int> baseIntList;
			int a = 10; int b = 20;
			baseIntList.PushFront(a);
			baseIntList.PushFront(b);

			SList<int> copyIntList;
			copyIntList = baseIntList;

			Assert::IsFalse(copyIntList.IsEmpty());
			Assert::AreEqual(2U, copyIntList.Size());
			Assert::AreNotSame(copyIntList.Front(), copyIntList.Back());
			Assert::AreEqual(b, copyIntList.Front());

			//int pointer test
			int* aPointer = &a; int* bPointer = &b;
			SList<int*> basePointerList;
			basePointerList.PushFront(aPointer);
			basePointerList.PushFront(bPointer);

			SList<int*> copyPointerList;
			copyPointerList = basePointerList;

			Assert::IsFalse(copyPointerList.IsEmpty());
			Assert::AreEqual(2U, copyPointerList.Size());
			Assert::AreNotSame(copyPointerList.Front(), copyPointerList.Back());
			Assert::AreEqual(bPointer, copyPointerList.Front());

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			SList<TesterClass> baseFooList;

			baseFooList.PushFront(fooOne);
			baseFooList.PushFront(fooTwo);

			SList<TesterClass> copyFooList;
			copyFooList = baseFooList;

			Assert::IsFalse(copyFooList.IsEmpty());
			Assert::AreEqual(2U, copyFooList.Size());
			Assert::AreNotSame(copyFooList.Front(), copyFooList.Back());
			Assert::AreEqual(fooTwo, copyFooList.Front());
		}

		TEST_METHOD(SListBegin)
		{
			//int test
			SList<int> intList;
			int a = 10; int b = 20;
			SList<int>::Iterator it;

			intList.PushFront(a);
			intList.PushFront(b);

			it = intList.begin();

			Assert::AreEqual(b, *it);
			Assert::AreNotEqual(a, *it);
			Assert::AreEqual(intList.Front(), *it);

			//pointer test
			SList<int*> pointerList;
			int* aPointer = &a; int* bPointer = &b;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);

			SList<int*>::Iterator pointerIt = pointerList.begin();

			Assert::AreEqual(bPointer, *pointerIt);
			Assert::AreNotEqual(aPointer, *pointerIt);
			Assert::AreEqual(pointerList.Front(), *pointerIt);

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);

			SList<TesterClass>::Iterator fooIt = fooList.begin();

			Assert::AreEqual(fooTwo, *fooIt);
			Assert::AreNotEqual(fooOne, *fooIt);
			Assert::AreEqual(fooList.Front(), *fooIt);

		}

		TEST_METHOD(SListConstBegin)
		{
			//int test
			SList<int> baseIntList;
			int a = 10; int b = 20;

			const SList<int> constInt;
			SList<int>::Iterator constIt;

			baseIntList.PushFront(a);
			baseIntList.PushFront(b);

			const SList<int> copyIntList(baseIntList);

			SList<int>::Iterator it = copyIntList.begin();

			Assert::AreEqual(b, *it);
			Assert::AreNotEqual(a, *it);
			Assert::AreEqual(copyIntList.Front(), *it);

			//pointer test
			int* aPointer = &a; int* bPointer = &b;
			SList<int*> basePointerList;
			basePointerList.PushFront(aPointer);
			basePointerList.PushFront(bPointer);

			const SList<int*> copyPointerList(basePointerList);

			SList<int*>::Iterator pointerIt = copyPointerList.begin();

			Assert::AreEqual(bPointer, *pointerIt);
			Assert::AreNotEqual(aPointer, *pointerIt);
			Assert::AreEqual(copyPointerList.Front(), *pointerIt);

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			SList<TesterClass> baseFooList;

			baseFooList.PushFront(fooOne);
			baseFooList.PushFront(fooTwo);

			const SList<TesterClass> copyFooList(baseFooList);

			SList<TesterClass>::Iterator fooIt = copyFooList.begin();

			Assert::AreEqual(fooTwo, *fooIt);
			Assert::AreNotEqual(fooOne, *fooIt);
			Assert::AreEqual(copyFooList.Front(), *fooIt);

		}

		TEST_METHOD(SListEnd)
		{
			//int test
			SList<int> intList;
			int a = 10; int b = 20;
			SList<int>::Iterator it;
			intList.end();

			intList.PushFront(a);
			intList.PushFront(b);

			it = intList.end();

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			//pointer test
			SList<int*> pointerList;
			int* aPointer = &a; int* bPointer = &b;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);

			SList<int*>::Iterator pointerIt = pointerList.end();

			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);

			SList<TesterClass>::Iterator fooIt = fooList.end();

			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

		}

		TEST_METHOD(SListConstEnd)
		{
			//int test
			SList<int> baseIntList;
			int a = 10; int b = 20;

			const SList<int> constInt;
			SList<int>::Iterator constIt;
			constInt.end();

			baseIntList.PushFront(a);
			baseIntList.PushFront(b);

			const SList<int> copyIntList(baseIntList);

			SList<int>::Iterator it = copyIntList.end();

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			//pointer test
			int* aPointer = &a; int* bPointer = &b;
			SList<int*> basePointerList;
			basePointerList.PushFront(aPointer);
			basePointerList.PushFront(bPointer);

			const SList<int*> copyPointerList(basePointerList);

			SList<int*>::Iterator pointerIt = copyPointerList.end();

			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			//user defined class test
			TesterClass fooOne(10);
			TesterClass fooTwo(20);
			SList<TesterClass> baseFooList;

			baseFooList.PushFront(fooOne);
			baseFooList.PushFront(fooTwo);

			const SList<TesterClass> copyFooList(baseFooList);

			SList<TesterClass>::Iterator fooIt = copyFooList.end();

			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

		}

		TEST_METHOD(SListIteratorConstOperatorTest)
		{
			//int test
			SList<int> baseIntList;
			int a = 10; int b = 20;

			const SList<int> constInt;
			SList<int>::Iterator constIt;

			constInt.end();

			baseIntList.PushFront(a);
			baseIntList.PushFront(b);

			const SList<int> copyIntList(baseIntList);

			const SList<int>::Iterator it = copyIntList.end();

			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			const SList<int>::Iterator constDereferenceCheckIt = copyIntList.begin();
			Assert::AreEqual(b, *constDereferenceCheckIt);

			constIt = baseIntList.begin();
			constIt++;
			Assert::AreEqual(a, *constIt);
		}

		TEST_METHOD(SListFind)
		{
			//int test
			SList<int> intList;
			int a = 10; int b = 20; int c = 30;
			intList.PushFront(a);
			intList.PushFront(b);

			SList<int>::Iterator it = intList.Find(b);
			Assert::AreEqual(b, *it);
			Assert::AreNotEqual(a, *it);

			it = intList.Find(a);
			Assert::AreEqual(a, *it);
			Assert::AreNotEqual(b, *it);

			it = intList.Find(c);
			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			//pointer test
			SList<int*> pointerList;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);

			SList<int*>::Iterator pointerIt = pointerList.Find(bPointer);
			Assert::AreEqual(bPointer, *pointerIt);
			Assert::AreNotEqual(aPointer, *pointerIt);

			pointerIt = pointerList.Find(aPointer);
			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreNotEqual(bPointer, *pointerIt);

			pointerIt = pointerList.Find(cPointer);
			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);

			SList<TesterClass>::Iterator fooIt = fooList.Find(fooTwo);
			Assert::AreEqual(fooTwo, *fooIt);
			Assert::AreNotEqual(fooOne, *fooIt);

			fooIt = fooList.Find(fooOne);
			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreNotEqual(fooTwo, *fooIt);

			fooIt = fooList.Find(fooThree);
			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

		}

		TEST_METHOD(SListInsertAfter)
		{
			//int test
			SList<int> intList, otherIntList;
			int a = 10; int b = 20; int c = 30;
			intList.PushFront(a);
			intList.PushFront(b);

			SList<int>::Iterator otherIt;
			auto failExpression = [&intList, &c, &otherIt] {intList.InsertAfter(c, otherIt); };
			Assert::ExpectException<exception>(failExpression);

			SList<int>::Iterator it = intList.Find(c);
			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			it = intList.Find(b);
			intList.InsertAfter(c, it);
			it = intList.Find(c);
			Assert::AreEqual(c, *it);

			intList.Remove(c);

			it = intList.Find(a);
			intList.InsertAfter(c, it);
			it = intList.Find(c);
			Assert::AreEqual(c, *it);

			//pointer test
			SList<int*> pointerList;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);

			SList<int*>::Iterator pointerIt = pointerList.Find(cPointer);
			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			pointerIt = pointerList.Find(bPointer);
			pointerList.InsertAfter(cPointer, pointerIt);
			pointerIt = pointerList.Find(cPointer);
			Assert::AreEqual(cPointer, *pointerIt);

			pointerList.Remove(cPointer);

			pointerIt = pointerList.Find(aPointer);
			pointerList.InsertAfter(cPointer, pointerIt);
			pointerIt = pointerList.Find(cPointer);
			Assert::AreEqual(cPointer, *pointerIt);
			
			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);

			SList<TesterClass>::Iterator fooIt = fooList.Find(fooThree);
			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

			fooIt = fooList.Find(fooTwo);
			fooList.InsertAfter(fooThree, fooIt);
			fooIt = fooList.Find(fooThree);
			Assert::AreEqual(fooThree, *fooIt);

			fooList.Remove(fooThree);

			fooIt = fooList.Find(fooOne);
			fooList.InsertAfter(fooThree, fooIt);
			fooIt = fooList.Find(fooThree);
			Assert::AreEqual(fooThree, *fooIt);
			
		}

		TEST_METHOD(SListRemove)
		{//int test
			SList<int> intList;
			int a = 10; int b = 20; int c = 30;
			intList.PushFront(b);
			intList.PushFront(a);
			intList.PushFront(a);
			intList.PushFront(c);

			intList.Remove(c);

			SList<int>::Iterator it = intList.Find(c);
			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);
			Assert::AreEqual(3U, intList.Size());

			Assert::IsFalse(intList.Remove(c));

			Assert::IsTrue(intList.Remove(a));

			it = intList.Find(a);
			Assert::AreEqual(a, *it);
			Assert::AreEqual(2U, intList.Size());

			//pointer test
			SList<int*> pointerList;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);
			pointerList.PushFront(aPointer);
			pointerList.PushFront(cPointer);

			pointerList.Remove(cPointer);

			SList<int*>::Iterator pointerIt = pointerList.Find(cPointer);
			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);
			Assert::AreEqual(3U, pointerList.Size());

			Assert::IsFalse(pointerList.Remove(cPointer));

			Assert::IsTrue(pointerList.Remove(aPointer));

			pointerIt = pointerList.Find(aPointer);
			Assert::AreEqual(aPointer, *pointerIt);
			Assert::AreEqual(2U, pointerList.Size());

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			SList<TesterClass> fooList;

			fooList.PushFront(fooThree);
			fooList.PushFront(fooTwo);
			fooList.PushFront(fooOne);
			fooList.PushFront(fooOne);

			fooList.Remove(fooThree);

			SList<TesterClass>::Iterator fooIt = fooList.Find(fooThree);
			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);
			Assert::AreEqual(3U, fooList.Size());

			Assert::IsFalse(fooList.Remove(fooThree));

			Assert::IsTrue(fooList.Remove(fooOne));

			fooIt = fooList.Find(fooOne);
			Assert::AreEqual(fooOne, *fooIt);
			Assert::AreEqual(2U, fooList.Size());
		}

		TEST_METHOD(SListRemoveAll)
		{//int test
			SList<int> intList;
			int a = 10; int b = 20; int c = 30;
			intList.PushFront(b);
			intList.PushFront(a);
			intList.PushFront(a);
			intList.PushFront(c);

			intList.RemoveAll(c);

			SList<int>::Iterator it = intList.Find(c);
			auto expression = [&it] {*it; };
			Assert::ExpectException<exception>(expression);

			Assert::IsFalse(intList.RemoveAll(c));

			Assert::IsTrue(intList.RemoveAll(a));

			it = intList.Find(a);
			Assert::ExpectException<exception>(expression);
			Assert::AreEqual(1U, intList.Size());

			//pointer test
			SList<int*> pointerList;
			int* aPointer = &a; int* bPointer = &b; int* cPointer = &c;
			pointerList.PushFront(aPointer);
			pointerList.PushFront(bPointer);
			pointerList.PushFront(aPointer);
			pointerList.PushFront(cPointer);

			pointerList.RemoveAll(cPointer);

			SList<int*>::Iterator pointerIt = pointerList.Find(cPointer);
			auto pointerExpression = [&pointerIt] {*pointerIt; };
			Assert::ExpectException<exception>(pointerExpression);

			Assert::IsFalse(pointerList.RemoveAll(cPointer));

			Assert::IsTrue(pointerList.RemoveAll(aPointer));

			pointerIt = pointerList.Find(aPointer);
			Assert::ExpectException<exception>(pointerExpression);
			Assert::AreEqual(1U, pointerList.Size());

			//user defined class test
			TesterClass fooOne(a);
			TesterClass fooTwo(b);
			TesterClass fooThree(c);
			SList<TesterClass> fooList;

			fooList.PushFront(fooOne);
			fooList.PushFront(fooTwo);
			fooList.PushFront(fooOne);
			fooList.PushFront(fooThree);

			fooList.RemoveAll(fooThree);

			SList<TesterClass>::Iterator fooIt = fooList.Find(fooThree);
			auto fooExpression = [&fooIt] {*fooIt; };
			Assert::ExpectException<exception>(fooExpression);

			Assert::IsFalse(fooList.RemoveAll(fooThree));

			Assert::IsTrue(fooList.RemoveAll(fooOne));

			pointerIt = pointerList.Find(aPointer);
			Assert::ExpectException<exception>(fooExpression);
			Assert::AreEqual(1U, pointerList.Size());
		}

	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState SListTest::sStartMemState;
}