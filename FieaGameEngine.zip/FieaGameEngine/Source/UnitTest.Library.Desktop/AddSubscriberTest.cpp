#include "pch.h"
#include "FooSubscriber.h"
#include "AddSubscriberTest.h"
#include "Event.h"

using namespace UnitTestLibraryDesktop;
using namespace FieaGameEngine;

EventQueue* AddSubscriberTest::mQueue;
GameTime AddSubscriberTest::mTime;

void AddSubscriberTest::Notify(FieaGameEngine::EventPublisher & publisher)
{
	mNotified = true;
	mQueue->Enqueue(make_shared<Event<float>>(Event<float>()), mTime);
	publisher;
}
