#pragma once
#include "pch.h"

namespace Microsoft::VisualStudio::CppUnitTestFramework
{
	template<>
	inline std::wstring ToString<UnitTestLibraryDesktop::TesterClass>(const UnitTestLibraryDesktop::TesterClass &t)
	{
		RETURN_WIDE_STRING(t.GetData() + t.GetDataPointer());
	}
}