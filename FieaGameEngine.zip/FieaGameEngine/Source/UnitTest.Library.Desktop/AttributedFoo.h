#pragma once
#include "Attributed.h"

namespace UnitTestLibraryDesktop
{
	class AttributedFoo : public FieaGameEngine::Attributed
	{
		RTTI_DECLARATIONS(AttributedFoo, Attributed);

	public:
		AttributedFoo();
		AttributedFoo(const AttributedFoo & rhs);
		AttributedFoo(AttributedFoo && rhs);
		AttributedFoo & operator=(const AttributedFoo & rhs);
		AttributedFoo & operator=(AttributedFoo && rhs);
		
		int32_t mInt;
		float mFloat;
		glm::vec4 mVector, mOtherVector;
		glm::mat4x4 mMatrix, mOtherMatrix;
		string mBaseString, mOtherString;
		string mArrayStr[2];
		RTTI * mNewPointer;
		RTTI * mOtherPointer;

		Scope *mTestScope;

		void TestHelper();
		virtual ~AttributedFoo();

	private:
		void InitializeMembers(uint64_t typeID);
		void UpdateMembers();
	};
}

