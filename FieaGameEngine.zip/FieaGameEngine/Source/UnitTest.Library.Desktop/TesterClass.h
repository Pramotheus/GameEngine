#pragma once
#include "RTTI.h"

namespace UnitTestLibraryDesktop
{
	class TesterClass : public FieaGameEngine::RTTI
	{
		RTTI_DECLARATIONS(TesterClass, FieaGameEngine::RTTI)

	public:
		TesterClass();
		TesterClass(int value);
		TesterClass(const TesterClass &other);

		int GetData() const;
		int* GetDataPointer() const;

		void SetData(int value);
		void clearTestPointer();

		TesterClass operator=(const TesterClass &rhs);
		bool operator==(const TesterClass &other);
		bool operator==(const TesterClass &other) const;

		~TesterClass();

	private:
		int data;
		int *dataPointer;

	};

	class TesterHashFunctor
	{
	public:
		uint32_t operator()(const TesterClass & foo) const;
	};
}


