#include "pch.h"
#include "AttributedFoo.h"

using namespace UnitTestLibraryDesktop;
using namespace FieaGameEngine;

RTTI_DEFINITIONS(AttributedFoo);

HashMap<uint64_t, Vector<std::string>> Attributed::mPrescribedAttributes;

AttributedFoo::AttributedFoo()
	:Attributed(TypeIdInstance())
{
	mInt = 10;
	mFloat = 12.60f;
	mBaseString = "bigstring";
	mOtherString = "notsmallstr";
	mArrayStr[0] = mBaseString;
	mArrayStr[1] = mOtherString;
	mNewPointer = new TesterClass(10);
	mOtherPointer = new TesterClass(20);

	mTestScope = new Scope();
	InitializeMembers(TypeIdInstance());
}

UnitTestLibraryDesktop::AttributedFoo::AttributedFoo(const AttributedFoo & rhs)
	: Attributed(rhs), mInt(rhs.mInt), mFloat(rhs.mFloat), mVector(rhs.mVector), mOtherVector(rhs.mOtherVector), mMatrix(rhs.mMatrix), mOtherMatrix(rhs.mOtherMatrix),
	mBaseString(rhs.mBaseString), mOtherString(rhs.mOtherString)
{ 
	*mNewPointer = *(rhs.mNewPointer); 
	*mOtherPointer = *(rhs.mOtherPointer);

	std::copy(std::begin(rhs.mArrayStr), std::end(rhs.mArrayStr), mArrayStr);

	UpdateMembers();
}

UnitTestLibraryDesktop::AttributedFoo::AttributedFoo(AttributedFoo && rhs)
	: Attributed(std::move(rhs)), mInt(std::move(rhs.mInt)), mFloat(std::move(rhs.mFloat)), mVector(std::move(rhs.mVector)), mOtherVector(std::move(rhs.mOtherVector)), mMatrix(std::move(rhs.mMatrix)), mOtherMatrix(std::move(rhs.mOtherMatrix)),
	mBaseString(std::move(rhs.mBaseString)), mOtherString(std::move(rhs.mOtherString))
{
	*mNewPointer = *(std::move(rhs.mNewPointer));
	*mOtherPointer = *(std::move(rhs.mOtherPointer));

	std::move(std::begin(rhs.mArrayStr), std::end(rhs.mArrayStr), mArrayStr);

	UpdateMembers();
}

AttributedFoo & UnitTestLibraryDesktop::AttributedFoo::operator=(const AttributedFoo & rhs)
{
	if (this != &rhs)
	{
		Attributed::operator=(rhs);

		mInt = (rhs.mInt); mFloat = (rhs.mFloat); mVector = (rhs.mVector); mOtherVector = (rhs.mOtherVector); mMatrix = (rhs.mMatrix); mOtherMatrix = (rhs.mOtherMatrix);
		mBaseString = (rhs.mBaseString); mOtherString = (rhs.mOtherString); *mNewPointer = *(rhs.mNewPointer); *mOtherPointer = *(rhs.mOtherPointer);

		std::copy(std::begin(rhs.mArrayStr), std::end(rhs.mArrayStr), mArrayStr);

		UpdateMembers();
	}
	return *this;
}

AttributedFoo & UnitTestLibraryDesktop::AttributedFoo::operator=(AttributedFoo && rhs)
{
	if (this != &rhs)
	{
		Attributed::operator=(std::move(rhs));

		mInt = std::move(rhs.mInt); mFloat = std::move(rhs.mFloat); mVector = std::move(rhs.mVector); mOtherVector = std::move(rhs.mOtherVector); mMatrix = std::move(rhs.mMatrix); mOtherMatrix = std::move(rhs.mOtherMatrix);
		mBaseString = std::move(rhs.mBaseString); mOtherString = std::move(rhs.mOtherString); *mNewPointer = *std::move(rhs.mNewPointer); *mOtherPointer = *std::move(rhs.mOtherPointer);

		std::move(std::begin(rhs.mArrayStr), std::end(rhs.mArrayStr), mArrayStr);

		UpdateMembers();
	}
	return *this;
}

void UnitTestLibraryDesktop::AttributedFoo::InitializeMembers(uint64_t typeID)
{
	SetExternalAttributes(typeID, "ExternalInt", &mInt, 1);
	SetInternalAttributes(typeID, "InternalInt", mInt);

	SetExternalAttributes(typeID, "ExternalFloat", &mFloat, 1);
	SetInternalAttributes(typeID, "InternalFloat", mFloat);

	SetExternalAttributes(typeID, "ExternalVector", &mVector, 1);
	SetInternalAttributes(typeID, "InternalVector", mOtherVector);

	SetExternalAttributes(typeID, "Externalmatrix", &mMatrix, 1);
	SetInternalAttributes(typeID, "Internalmatrix", mOtherMatrix);

	SetExternalAttributes(typeID, "ExternalStr", mArrayStr, 2);
	SetInternalAttributes(typeID, "InternalStr", mBaseString);
	SetInternalAttributes(typeID, "InternalStr", mOtherString);

	SetExternalAttributes(typeID, "ExternalPtr", &mNewPointer, 1);
	SetInternalAttributes(typeID, "InternalPtr", mOtherPointer);

	SetNestedScope(typeID, "InternalScope");
	SetNestedScope(typeID, "AdoptedScope", *mTestScope);

}

void UnitTestLibraryDesktop::AttributedFoo::UpdateMembers()
{
	(*this)["ExternalInt"].SetStorage(&mInt, 1);
	(*this)["ExternalFloat"].SetStorage(&mFloat, 1);
	(*this)["ExternalVector"].SetStorage(&mVector, 1);
	(*this)["Externalmatrix"].SetStorage(&mMatrix, 1);
	(*this)["ExternalStr"].SetStorage(mArrayStr, 2);
	(*this)["ExternalPtr"].SetStorage(&mNewPointer, 1);
}

void UnitTestLibraryDesktop::AttributedFoo::TestHelper()
{
	Attributed::TypeIdClass();
}

AttributedFoo::~AttributedFoo()
{
	delete mNewPointer;
	delete mOtherPointer;
}
