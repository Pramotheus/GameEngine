#include "pch.h"
#include "TesterClass.h"
#include "EngineFactory.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(FactoryTest)
	{
	public:
		ConcreteFactory(TesterClass, RTTI)

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(ConcreteFactoryCreate)
		{
			ConcreteTesterClassFactory FooFactory;

			Assert::AreEqual(1U, FooFactory.Size());
			char* testClassName = "TesterClass";
			Assert::IsTrue(testClassName == FooFactory.ClassName());

			TesterClass *Foo = FooFactory.Create()->As<TesterClass>();
			Foo->SetData(10);
			TesterClass Bar(10);
			Assert::AreEqual(Bar, *Foo);



			delete Foo;
		}

		TEST_METHOD(AbstractFactoryCreate)
		{
			ConcreteTesterClassFactory FooFactory;

			Assert::AreEqual(1U, FooFactory.Size());
			char* testClassName = "TesterClass";
			Assert::IsTrue(testClassName == FooFactory.ClassName());

			TesterClass *Foo = EngineFactory<RTTI>::Create("TesterClass")->As<TesterClass>();
			Foo->SetData(10);
			TesterClass Bar(10);
			Assert::AreEqual(Bar, *Foo);

			ConcreteTesterClassFactory *BarFactory = nullptr;
			Assert::IsTrue(BarFactory == EngineFactory<RTTI>::Find("Scope"));

			delete Foo;
		}

		TEST_METHOD(FactoryIteration)
		{
			ConcreteTesterClassFactory FooFactory;

			Assert::AreEqual(1U, FooFactory.Size());
			char* testClassName = "TesterClass";
			Assert::IsTrue(testClassName == FooFactory.ClassName());

			HashMap<string, EngineFactory<RTTI>*>::Iterator it = EngineFactory<RTTI>::begin();
			Assert::IsTrue(FooFactory.ClassName() == it->second->ClassName());
			++it;
			Assert::IsTrue(it == EngineFactory<RTTI>::end());
		}

	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState FactoryTest::sStartMemState;
}
