#include "pch.h"
#include "HashMap.h"
#include <string>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(HashMapTest)
	{
	public:
		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(HashInsert)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20, c = 30, d = 40;
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			intIntHash.Insert(B);
			HashMap<int, int>::Iterator it = intIntHash.Insert(A);
			HashMap<int, int>::Iterator newIt = intIntHash.Insert(A);
			Assert::IsTrue(it==newIt);
			++it;
			intIntHash.Insert(B);

			HashMap<char*, int> charIntHash;
			char* aChar = "hello";
			pair<char*, int> C = make_pair(aChar, a);

			char copyChar[40];
			char* bChar;
			strcpy_s(copyChar, aChar);
			bChar = copyChar;
			pair<char*, int> F = make_pair(bChar, a);
			
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			HashMap<char*, int>::Iterator otherCharit = charIntHash.Insert(F);
			Assert::IsTrue(charIntHash.ContainsKey(aChar));
			Assert::IsTrue(charIt == otherCharit);
			Assert::AreEqual(1U, charIntHash.Size());

			HashMap<string, int> strIntHash;
			string aStr = "Welcome";
			pair<string, int> D = make_pair(aStr, a);
			strIntHash.Insert(D);
			Assert::IsTrue(strIntHash.ContainsKey(aStr));
			Assert::AreEqual(1U, strIntHash.Size());

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12);
			pair<TesterClass, int> E = make_pair(foo, a);
			fooIntHash.Insert(E);
			Assert::IsTrue(fooIntHash.ContainsKey(foo));
			Assert::AreEqual(1U, fooIntHash.Size());

		}

		TEST_METHOD(HashFind)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20 , c = 30, d = 40; 
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			HashMap<int, int>::Iterator newIt = intIntHash.Insert(A);
			intIntHash.Insert(B);
			HashMap<int, int>::Iterator it = intIntHash.Find(a);
			Assert::IsTrue(it == newIt);

			HashMap<char*, int> charIntHash;
			char* aChar = "hello", *bChar = "Birdie";
			pair<char*, int> C = make_pair(aChar, a);
			pair<char*, int> F = make_pair(bChar, b);
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			charIntHash.Insert(F);
			HashMap<char*, int>::Iterator charOtherIt = charIntHash.Find(bChar);
			Assert::IsTrue(F == *charOtherIt);
			Assert::IsTrue(charIntHash.ContainsKey(aChar));
			Assert::AreEqual(2U, charIntHash.Size());

			HashMap<string, int> strIntHash;
			string aStr = "Welcome", bStr = "To DOTA";
			pair<string, int> D = make_pair(aStr, a);
			pair<string, int> G = make_pair(bStr, b);
			HashMap<string, int>::Iterator strIt = strIntHash.Insert(D);
			strIntHash.Insert(G);
			HashMap<string, int>::Iterator strOtherIt = strIntHash.Find(bStr);
			Assert::IsTrue(G == *strOtherIt);
			Assert::IsTrue(strIntHash.ContainsKey(bStr));
			Assert::AreEqual(2U, strIntHash.Size());

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12), fooB(48), fooC(22);

			pair<TesterClass, int> E = make_pair(foo, a);
			pair<TesterClass, int> H = make_pair(fooB, b);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt = fooIntHash.Insert(E);
			fooIntHash.Insert(H);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooOtherIt = fooIntHash.Find(fooB);
			Assert::IsTrue(H == *fooOtherIt);
			Assert::IsTrue(fooIntHash.ContainsKey(fooB));
			Assert::AreEqual(2U, fooIntHash.Size());
		}

		TEST_METHOD(HashIndexOperator)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20, c = 30, d = 40;
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			HashMap<int, int>::Iterator it = intIntHash.Insert(A);
			intIntHash[c] = d;
			Assert::IsTrue(intIntHash.ContainsKey(c));
			HashMap<int, int>::Iterator newIt = intIntHash.Find(c);
			Assert::IsTrue(B == *newIt);

			HashMap<char*, int> charIntHash;
			char* aChar = "hello", *bChar = "Birdie";
			pair<char*, int> C = make_pair(aChar, a);
			pair<char*, int> F = make_pair(bChar, b);
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			charIntHash[bChar] = b;
			HashMap<char*, int>::Iterator charOtherIt = charIntHash.Find(bChar);
			Assert::IsTrue(F == *charOtherIt);
			Assert::IsTrue(charIntHash.ContainsKey(aChar));
			Assert::AreEqual(2U, charIntHash.Size());

			HashMap<string, int> strIntHash;
			string aStr = "Welcome", bStr = "To DOTA";
			pair<string, int> D = make_pair(aStr, a);
			pair<string, int> G = make_pair(bStr, b);
			HashMap<string, int>::Iterator strIt = strIntHash.Insert(D);
			strIntHash[bStr] = b;
			HashMap<string, int>::Iterator strOtherIt = strIntHash.Find(bStr);
			Assert::IsTrue(G == *strOtherIt);
			Assert::IsTrue(strIntHash.ContainsKey(bStr));
			Assert::AreEqual(2U, strIntHash.Size());

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12), fooB(48);
			pair<TesterClass, int> E = make_pair(foo, a);
			pair<TesterClass, int> H = make_pair(fooB, b);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt = fooIntHash.Insert(E);
			fooIntHash[fooB] = b;
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooOtherIt = fooIntHash.Find(fooB);
			Assert::IsTrue(H == *fooOtherIt);
			Assert::IsTrue(fooIntHash.ContainsKey(fooB));
			Assert::AreEqual(2U, fooIntHash.Size());
		}

		TEST_METHOD(HashAtFunction)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20, c = 30, d = 40;
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			HashMap<int, int>::Iterator newIt = intIntHash.Insert(A);
			intIntHash.Insert(B);
			intIntHash[b] = a;
			const HashMap<int, int> constIntIntHash(intIntHash);
			const HashMap<int, int>::Iterator it = constIntIntHash.Find(a);
			Assert::AreEqual(a, constIntIntHash.At(b));
			Assert::IsTrue(A==*it);
			Assert::IsTrue(a == it->first);

			HashMap<char*, int> charIntHash;
			char* aChar = "hello";
			pair<char*, int> C = make_pair(aChar, a);
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			Assert::AreEqual(a, charIntHash.At(aChar));

			HashMap<string, int> strIntHash;
			string aStr = "Welcome";
			pair<string, int> D = make_pair(aStr, a);
			HashMap<string, int>::Iterator strIt = strIntHash.Insert(D);
			Assert::AreEqual(a, strIntHash.At(aStr));

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12);
			pair<TesterClass, int> E = make_pair(foo, a);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt = fooIntHash.Insert(E);
			Assert::AreEqual(a, fooIntHash.At(foo));
		}

		TEST_METHOD(HashRemove)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20, c = 30, d = 40;
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			HashMap<int, int>::Iterator newIt = intIntHash.Insert(A);
			intIntHash.Insert(B);
			intIntHash[b] = a;
			Assert::IsTrue(intIntHash.Remove(b));
			Assert::IsFalse(intIntHash.ContainsKey(b));

			HashMap<char*, int> charIntHash;
			char* aChar = "hello", *bChar = "Birdie";
			pair<char*, int> C = make_pair(aChar, a);
			pair<char*, int> F = make_pair(bChar, b);
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			charIntHash.Insert(F);
			HashMap<char*, int>::Iterator charOtherIt = charIntHash.Find(bChar);
			Assert::IsTrue(charIntHash.ContainsKey(aChar));
			Assert::AreEqual(2U, charIntHash.Size());
			Assert::IsTrue(charIntHash.Remove(bChar));
			Assert::IsFalse(charIntHash.ContainsKey(bChar));

			HashMap<string, int> strIntHash;
			string aStr = "Welcome", bStr = "To DOTA";
			pair<string, int> D = make_pair(aStr, a);
			pair<string, int> G = make_pair(bStr, b);
			HashMap<string, int>::Iterator strIt = strIntHash.Insert(D);
			strIntHash.Insert(G);
			HashMap<string, int>::Iterator strOtherIt = strIntHash.Find(bStr);
			Assert::IsTrue(strIntHash.ContainsKey(bStr));
			Assert::AreEqual(2U, strIntHash.Size());
			Assert::IsTrue(strIntHash.Remove(bStr));
			Assert::IsFalse(strIntHash.ContainsKey(bStr));

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12), fooB(48);
			pair<TesterClass, int> E = make_pair(foo, a);
			pair<TesterClass, int> H = make_pair(fooB, b);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt = fooIntHash.Insert(E);
			fooIntHash.Insert(H);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooOtherIt = fooIntHash.Find(fooB);
			Assert::IsTrue(H == *fooOtherIt);
			Assert::IsTrue(fooIntHash.ContainsKey(fooB));
			Assert::AreEqual(2U, fooIntHash.Size());
			Assert::IsTrue(fooIntHash.Remove(fooB));
			Assert::IsFalse(fooIntHash.ContainsKey(fooB));
			Assert::IsFalse(fooIntHash.Remove(fooB));
		}

		TEST_METHOD(HashClear)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20, c = 30, d = 40;
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			HashMap<int, int>::Iterator newIt = intIntHash.Insert(A);
			intIntHash.Insert(B);
			intIntHash[b] = a;

			intIntHash.Clear();

			Assert::IsFalse(intIntHash.ContainsKey(b));
			Assert::AreEqual(0U, intIntHash.Size());

			HashMap<char*, int> charIntHash;
			char* aChar = "hello", *bChar = "Birdie";
			pair<char*, int> C = make_pair(aChar, a);
			pair<char*, int> F = make_pair(bChar, b);
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			charIntHash.Insert(F);
			HashMap<char*, int>::Iterator charOtherIt = charIntHash.Find(bChar);
			Assert::IsTrue(charIntHash.ContainsKey(aChar));
			Assert::AreEqual(2U, charIntHash.Size());

			charIntHash.Clear();

			Assert::IsFalse(charIntHash.ContainsKey(bChar));
			Assert::AreEqual(0U, charIntHash.Size());

			HashMap<string, int> strIntHash;
			string aStr = "Welcome", bStr = "To DOTA";
			pair<string, int> D = make_pair(aStr, a);
			pair<string, int> G = make_pair(bStr, b);
			HashMap<string, int>::Iterator strIt = strIntHash.Insert(D);
			strIntHash.Insert(G);
			HashMap<string, int>::Iterator strOtherIt = strIntHash.Find(bStr);
			Assert::IsTrue(strIntHash.ContainsKey(bStr));
			Assert::AreEqual(2U, strIntHash.Size());

			strIntHash.Clear();

			Assert::IsFalse(strIntHash.ContainsKey(bStr));
			Assert::AreEqual(0U, strIntHash.Size());

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12), fooB(48);
			pair<TesterClass, int> E = make_pair(foo, a);
			pair<TesterClass, int> H = make_pair(fooB, b);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt = fooIntHash.Insert(E);
			fooIntHash.Insert(H);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooOtherIt = fooIntHash.Find(fooB);
			Assert::IsTrue(fooIntHash.ContainsKey(fooB));
			Assert::AreEqual(2U, fooIntHash.Size());

			fooIntHash.Clear();

			Assert::IsFalse(fooIntHash.ContainsKey(fooB));
			Assert::AreEqual(0U, fooIntHash.Size());
		}

		TEST_METHOD(HashBeginEnd)
		{
			HashMap<int, int> intIntHash;
			int a = 10, b = 20, c = 30, d = 40;
			pair<int, int> A = make_pair(a, b);
			pair<int, int> B = make_pair(c, d);
			Assert::IsTrue(intIntHash.begin() == intIntHash.end());
			HashMap<int, int>::Iterator it = intIntHash.Insert(B);
			Assert::IsTrue(it == intIntHash.begin());
			it++;
			Assert::IsTrue(it == intIntHash.end());

			HashMap<char*, int> charIntHash;
			char* aChar = "hello";
			pair<char*, int> C = make_pair(aChar, a);
			HashMap<char*, int>::Iterator charIt = charIntHash.Insert(C);
			Assert::IsTrue(charIt == charIntHash.begin());
			charIt++;
			Assert::IsTrue(charIt == charIntHash.end());

			HashMap<string, int> strIntHash;
			string aStr = "Welcome";
			pair<string, int> D = make_pair(aStr, a);
			HashMap<string, int>::Iterator strIt = strIntHash.Insert(D);
			Assert::IsTrue(strIt == strIntHash.begin());
			strIt++;
			Assert::IsTrue(strIt == strIntHash.end());

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash;
			TesterClass foo(12);
			pair<TesterClass, int> E = make_pair(foo, a);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt = fooIntHash.Insert(E);
			Assert::IsTrue(fooIt == fooIntHash.begin());
			fooIt++;
			Assert::IsTrue(fooIt == fooIntHash.end());

		}

		TEST_METHOD(HashIteratorTest)
		{

			int a = 10, b = 20;
			TesterClass foo(12), fooB(48);

			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooIt;

			auto Expression = [&fooIt] {++fooIt; };
			Assert::ExpectException<exception>(Expression);

			pair<TesterClass, int> E = make_pair(foo, a);
			pair<TesterClass, int> H = make_pair(fooB, b);

			HashMap<TesterClass, int, TesterHashFunctor> fooIntHash = {E, H};
			
			fooIt = fooIntHash.Find(foo);
			HashMap<TesterClass, int, TesterHashFunctor>::Iterator fooOtherIt = fooIntHash.Find(fooB);

			Assert::IsTrue(H == *fooOtherIt);
			Assert::IsTrue(fooIntHash.ContainsKey(fooB));
			Assert::AreEqual(2U, fooIntHash.Size());

			auto zeroSizeExpression = [] {HashMap<TesterClass, int, TesterHashFunctor> zeroFooIt(0); };
			Assert::ExpectException<exception>(zeroSizeExpression);

		}

	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState HashMapTest::sStartMemState;
}