#include "pch.h"
#include "JsonParseHelperTable.h"
#include "EngineFactory.h"
#include "Entity.h"
#include "Sector.h"
#include "World.h"
#include "IfAction.h"
#include "ActionCreateAction.h"
#include "ActionDeleteAction.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(ActionTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(ActionParse)
		{
			ConcreteIfActionFactory ifActionFactory;
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionDeleteActionFactory deleteActionFactory;
			ConcreteActionCreateActionFactory createActionFactory;

			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			testParseMaster.ParseFromFile("Script/ActionTestScript.json");

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Assert::IsNotNull(baseWorld);
			Sector * sector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>();
			Assert::IsNotNull(sector);
			Entity* player = sector->GetEntities().Get<Scope*>()->As<Entity>();
			Assert::IsNotNull(player);
			ActionList* run = player->GetActions().Get<Scope*>(1)->As<ActionList>();
			Assert::IsNotNull(run);
			ActionList* walk = run->GetActions().Get<Scope*>(3)->As<ActionList>();
			Assert::IsNotNull(walk);
			ActionList* stop = run->GetActions().Get<Scope*>(2)->As<ActionList>();
			Assert::IsNotNull(stop);

			Assert::AreEqual(350, walk->Find("Speed")->Get<int32_t>());
			Assert::AreEqual(0, stop->Find("Speed")->Get<int32_t>());
			Assert::AreEqual("FirstSector"s, sector->Name());
			Assert::AreEqual("Player"s, player->Name());

			Assert::IsTrue(sector == &player->GetSector());
			Assert::IsTrue(baseWorld == &sector->GetWorld());
		}

		TEST_METHOD(IfActionParse)
		{
			ConcreteIfActionFactory ifActionFactory;
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionDeleteActionFactory deleteActionFactory;
			ConcreteActionCreateActionFactory createActionFactory;

			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			testParseMaster.ParseFromFile("Script/ActionTestScript.json");

			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Assert::IsNotNull(baseWorld);
			Sector * sector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>();
			Assert::IsNotNull(sector);
			Entity* player = sector->GetEntities().Get<Scope*>()->As<Entity>();
			Assert::IsNotNull(player);
			ActionList* run = player->GetActions().Get<Scope*>(1)->As<ActionList>();
			Assert::IsNotNull(run);
			IfAction* testIf = run->GetActions().Get<Scope*>(4)->As<IfAction>();
			Assert::IsNotNull(testIf);

			Action *passedAction = testIf->GetPassedActions();
			Assert::IsNotNull(passedAction);
			Assert::AreEqual("True"s, passedAction->Find("TrueDatum"s)->Get<string>());
			Action *failAction = testIf->Find("ActionsList"s)->Get<Scope*>()->As<Action>();
			Assert::IsNotNull(failAction);
			Assert::AreEqual("False"s, failAction->Find("FalseDatum"s)->Get<string>());

		}

		TEST_METHOD(ActionUpdateTest)
		{
			ConcreteIfActionFactory ifActionFactory;
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionDeleteActionFactory deleteActionFactory;
			ConcreteActionCreateActionFactory createActionFactory;

			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);
			testParseMaster.AddHelper(tableHelper);
			testParseMaster.ParseFromFile("Script/ActionTestScript.json");

			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Assert::IsNotNull(baseWorld);
			Sector * sector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>();
			Assert::IsNotNull(sector);
			Entity* player = sector->GetEntities().Get<Scope*>()->As<Entity>();
			Assert::IsNotNull(player);
			ActionList* run = player->GetActions().Get<Scope*>(1)->As<ActionList>();
			Assert::IsNotNull(run);
			WorldState &state = baseWorld->GetWorldState();
			state.GetGameTime();
			GameTime newTime;
			state.SetGameTime(newTime);
			ActionCreateAction* testCreate = player->GetActions().Get<Scope*>()->As<ActionCreateAction>();
			Assert::IsNotNull(testCreate);
			Datum *creatorClass = testCreate->Find("NewActionClass");
			Assert::AreEqual("ActionList"s, creatorClass->Get<string>());

			Assert::IsNull(state.CurrentWorld);
			baseWorld->Update();
			Assert::IsNull(state.CurrentWorld);
		}

		TEST_METHOD(ActionCreateDeleteTest)
		{
			ConcreteIfActionFactory ifActionFactory;
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionDeleteActionFactory deleteActionFactory;
			ConcreteActionCreateActionFactory createActionFactory;

			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);
			testParseMaster.AddHelper(tableHelper);
			testParseMaster.ParseFromFile("Script/ActionTestScript.json");

			World * baseWorld = baseScope.Find("BaseWorld")->Get<Scope*>()->As<World>();
			Sector * sector = baseWorld->GetSectors().Get<Scope*>()->As<Sector>();
			Entity* player = sector->GetEntities().Get<Scope*>()->As<Entity>();
			ActionList* run = player->GetActions().Get<Scope*>(1)->As<ActionList>();
			Assert::IsNotNull(run);

			WorldState &state = baseWorld->GetWorldState(); state;

			baseWorld->Update();

			ActionList* createdFlyAction = player->GetActions().Get<Scope*>(2)->As<ActionList>(); createdFlyAction;
			Assert::AreEqual("Fly"s, createdFlyAction->Name());
			ActionList* createdJumpAction = run->GetActions().Get<Scope*>(5)->As<ActionList>();
			Assert::AreEqual("Jump"s, createdJumpAction->Name());
			ActionCreateAction* testCreate = player->GetActions().Get<Scope*>()->As<ActionCreateAction>();
			Assert::IsNotNull(testCreate);
			Datum *creatorClass = testCreate->Find("NewActionClass");
			Assert::AreEqual("ActionList"s, creatorClass->Get<string>());

			baseWorld->Update();
			testCreate = player->GetActions().Get<Scope*>()->As<ActionCreateAction>();
			Assert::IsNull(testCreate);
		}

		TEST_METHOD(ActionMoveTest)
		{
			ConcreteIfActionFactory ifActionFactory;
			ConcreteActionListFactory actionListFactory;
			ConcreteEntityFactory baseEntityFactory;
			ConcreteActionDeleteActionFactory deleteActionFactory;
			ConcreteActionCreateActionFactory createActionFactory;

			World baseWorld;
			baseWorld.SetName("BaseWorld");
			Sector* firstSector = baseWorld.CreateSector("firstSector");
			Entity* monster = firstSector->CreateEntity("Entity", "Monster"); monster;
			ActionList* run = monster->CreateAction("ActionList", "Run")->As<ActionList>(); run;
			ActionList* walk = run->CreateActions("ActionList", "Walk")->As<ActionList>(); walk;
			ActionList* stop = run->CreateActions("ActionList", "Stop")->As<ActionList>(); stop;
			IfAction* testIf = run->CreateActions("IfAction", "FirstIf")->As<IfAction>(); testIf;
			IfAction* testElse = run->CreateActions("IfAction", "SecondIf")->As<IfAction>(); testElse;
			ActionCreateAction* createActionOne = run->CreateActions("ActionCreateAction", "OneCreate")->As<ActionCreateAction>(); createActionOne;
			ActionCreateAction* createActionTwo = run->CreateActions("ActionCreateAction", "TwoCreate")->As<ActionCreateAction>(); createActionTwo;
			ActionDeleteAction* deleteActionOne = run->CreateActions("ActionDeleteAction", "OneDelete")->As<ActionDeleteAction>(); deleteActionOne;
			ActionDeleteAction* deleteActionTwo = run->CreateActions("ActionDeleteAction", "TwoDelete")->As<ActionDeleteAction>(); deleteActionTwo;

			ActionList moveActionList(std::move(*walk));
			ActionList otherActionList;
			otherActionList = std::move(*stop);

			Assert::AreEqual("Walk"s, moveActionList.Name());
			Assert::AreEqual("Stop"s, otherActionList.Name());

			testElse->Append("Condition"s) = 0;
			testElse->CreateActions("ActionList"s, "Temp"s);
			testElse->GetPassedActions();
			ActionCreateAction createMoveOne(std::move(*createActionOne));
			ActionCreateAction createMoveTwo;
			createMoveTwo = std::move(*createActionTwo);
			ActionDeleteAction deleteMoveOne(std::move(*deleteActionOne));
			ActionDeleteAction deleteMoveTwo;
			deleteMoveTwo = std::move(*deleteActionTwo);

			Assert::AreEqual("OneCreate"s, createMoveOne.Name());
			Assert::AreEqual("TwoCreate"s, createMoveTwo.Name());
			Assert::AreEqual("OneDelete"s, deleteMoveOne.Name());
			Assert::AreEqual("TwoDelete"s, deleteMoveTwo.Name());

			IfAction moveIf(std::move(*testIf));
			IfAction moveElse;
			moveElse = std::move(*testElse);

			Assert::AreEqual("FirstIf"s, moveIf.Name());
			Assert::AreEqual("SecondIf"s, moveElse.Name());

			delete walk;
			delete stop;
			delete createActionOne;
			delete createActionTwo;
			delete deleteActionOne;
			delete deleteActionTwo;
			delete testIf;
			delete testElse;
		}

	private:
		static _CrtMemState sStartMemState;
		Entity e;
		World w;
		Sector s;
		ActionList a;
		IfAction ifaction;
		ActionCreateAction aca;
		ActionDeleteAction ada;
	};

	_CrtMemState ActionTest::sStartMemState;
}