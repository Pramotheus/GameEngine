#include "pch.h"
#include "JsonFooParseHelper.h"
#include "JsonParseHelperTable.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(JsonTableTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(TableInitialize)
		{
			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			string jsonScript = R"(
			{
				"Player":
				{
					"Type": "Scope",
					"Value":
					{
						"Health":
						{
							"Type" : "Integer",
							"Value" : "100"
						},
						"Name" :
						{
							"Type" : "String",
							"Value" : "DarkLord"
						},
						"ContrivedScope":
						{
							"Type": "Scope",
							"Value":
							{
								"ConctrivedDatum":
								{
									"Type" : "Vector",
									"Value": "vec4(0.5,0.3,1.5,0) "
								}
							}
						}
					}
				},
				"DistanceFromPlayer":
				{
					"Type" : "Float",
					"Value" : ["15.5","20","63"]
				}
			}
			)";

			testParseMaster.Parse(jsonScript);

			string testString = "DarkLord";
			glm::vec4 testVector{ 0.5,0.3,1.5,0 };

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			Assert::IsTrue(Datum::DatumType::Table == baseScope.Find("Player")->Type());

			Assert::AreEqual(100, baseScope.Find("Player")->Get<Scope*>()->Find("Health")->Get<int32_t>());
			Assert::AreEqual(testString, baseScope.Find("Player")->Get<Scope*>()->Find("Name")->Get<string>());
			Assert::IsTrue(testVector == baseScope.Find("Player")->Get<Scope*>()->Find("ContrivedScope")->Get<Scope*>()->Find("ConctrivedDatum")->Get<glm::vec4>());
			Assert::AreEqual(20.0f, baseScope.Find("DistanceFromPlayer")->Get<float>(1));
		}


		TEST_METHOD(TableParseFromFile)
		{
			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			testParseMaster.ParseFromFile("Script/TestTable.json");

			string testString = "DarkLord";
			glm::vec4 testVector{ 0.5,0.3,1.5,0 };

			Assert::IsTrue(&baseScope == scopeSharedData.GetScope());
			Assert::IsTrue(Datum::DatumType::Table == baseScope.Find("Player")->Type());

			Assert::AreEqual(100, baseScope.Find("Player")->Get<Scope*>()->Find("Health")->Get<int32_t>());
			Assert::AreEqual(testString, baseScope.Find("Player")->Get<Scope*>()->Find("Name")->Get<string>());
			Assert::IsTrue(testVector == baseScope.Find("Player")->Get<Scope*>()->Find("ContrivedScope")->Get<Scope*>()->Find("ConctrivedDatum")->Get<glm::vec4>());
			Assert::AreEqual(20.0f, baseScope.Find("DistanceFromPlayer")->Get<float>(1));
		}

		TEST_METHOD(TableClone)
		{
			JsonParseHelperTable::SharedTableData scopeSharedData;
			Scope baseScope;
			scopeSharedData.SetScope(baseScope);
			JsonParseHelperTable tableHelper;
			JsonParseMaster testParseMaster(scopeSharedData);

			testParseMaster.AddHelper(tableHelper);

			JsonParseMaster *CloneParseMaster = testParseMaster.Clone();

			Assert::IsTrue(CloneParseMaster->IsClone());
			CloneParseMaster->ParseFromFile("Script/TestTable.json");

			Assert::IsTrue(baseScope != *CloneParseMaster->GetSharedData()->As<JsonParseHelperTable::SharedTableData>()->GetScope());
			Assert::IsTrue(CloneParseMaster->GetSharedData()->As<JsonParseHelperTable::SharedTableData>() != nullptr);
			Assert::IsTrue(&scopeSharedData != CloneParseMaster->GetSharedData()->As<JsonParseHelperTable::SharedTableData>());
			Assert::IsTrue(CloneParseMaster->GetSharedData()->GetJsonParseMaster() == CloneParseMaster);
			Assert::IsTrue(CloneParseMaster->GetSharedData()->GetJsonParseMaster() != &testParseMaster);

			delete CloneParseMaster;
		}

		TEST_METHOD(TableSharedChainTest)
		{
			JsonFooParseHelper::SharedFooData fooShared;
			TesterClass *foo = new TesterClass(0);
			fooShared.SetFoo(foo);

			JsonParseHelperTable tableHelper;
			JsonParseMaster TestParseMaster(fooShared);
			TestParseMaster.AddHelper(tableHelper);
			TestParseMaster.AddHelper(tableHelper);
			TestParseMaster.AddHelper(tableHelper);
			TestParseMaster.Reset();
			Assert::IsFalse(tableHelper.EndHandler(fooShared));
			
			TestParseMaster.ParseFromFile("Script/FooTest.json");

			Assert::AreNotEqual(54, foo->GetData());
			delete foo;
		}


	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState JsonTableTest::sStartMemState;
}