#include "pch.h"
#include "Scope.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(ScopeTest)
	{
	public:
		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(ScopeAppend)
		{
			Scope baseScope;
			Datum &HealthDatum = baseScope.Append("Health");
			Assert::IsTrue(HealthDatum == *(baseScope.Find("Health")));
			Datum &NameDatum = baseScope.Append("Name");
			Assert::IsTrue(HealthDatum == NameDatum);
			Assert::IsTrue(&HealthDatum != &NameDatum);
			baseScope[0] = 100;
			Assert::IsTrue(HealthDatum != NameDatum);

			auto scopeExpression = [&baseScope] {baseScope.Append(""); };
			Assert::ExpectException<exception>(scopeExpression);
		}

		TEST_METHOD(ScopeAppendScope)
		{
			Scope baseScope;
			Scope &HealthScope = baseScope.AppendScope("Health");
			Assert::IsTrue(HealthScope == *((baseScope.Find("Health"))->Get<Scope*>(0)));
			Scope &NameScope = baseScope.AppendScope("Name");
			Assert::IsTrue(HealthScope == NameScope);
			Assert::IsTrue(&HealthScope != &NameScope);
			HealthScope.Adopt(NameScope, "ChildName");
			Assert::IsTrue(HealthScope != NameScope);

			baseScope.Append("IntegerDatum");
			baseScope[2] = 100;
			auto scopeExpression = [&baseScope] {baseScope.AppendScope("IntegerDatum"); };
			Assert::ExpectException<exception>(scopeExpression);
		}

		TEST_METHOD(ScopeFind)
		{
			Scope baseScope;
			Scope &HealthScope = baseScope.AppendScope("Health");
			Assert::IsTrue(HealthScope == *((baseScope.Find("Health"))->Get<Scope*>(0)));

			Datum &HealthDatum = baseScope.Append("OtherHealth");
			Assert::IsTrue(HealthDatum == *(baseScope.Find("OtherHealth")));

			Datum * Nullptr = nullptr;
			Assert::IsTrue(Nullptr == (baseScope.Find("other")));
		}

		TEST_METHOD(ScopeSearch)
		{
			Scope baseScope;
			Scope &PlayerScope = baseScope.AppendScope("Player");
			Datum &EnemyDatum = baseScope.Append("Enemy");
			Scope &EnemyScope = baseScope.AppendScope("Enemy");
			Scope &PowerScope = PlayerScope.AppendScope("Power");
			Scope &HealthScope = EnemyScope.AppendScope("Health");
			Scope &NameScope = PowerScope.AppendScope("Name");

			Assert::IsTrue(EnemyDatum == *(NameScope.Search("Enemy")));

			Scope *tempScope;
			Assert::IsTrue(EnemyDatum == *(NameScope.Search("Enemy", &tempScope)));
			Assert::IsTrue(*tempScope == baseScope);

			Datum * Nullptr = nullptr;
			Assert::IsTrue(Nullptr == (NameScope.Search("Health", &tempScope)));

			UNREFERENCED_PARAMETER(HealthScope);
		}

		TEST_METHOD(ScopeCopy)
		{
			Scope *baseScope = new Scope();
			baseScope->Append("other")= 100;
			Scope &HealthScope = baseScope->AppendScope("Health");
			Scope *NameScope = new Scope();
			HealthScope.Adopt(*NameScope, "ChildName");

			Scope *copyScope = new Scope(*baseScope);
			Assert::IsTrue(HealthScope == *((copyScope->Find("Health")->Get<Scope*>(0))));
			Assert::IsTrue(*copyScope == *baseScope);

			Scope *childCopyScope = new Scope();
			*childCopyScope = *NameScope;
			Assert::IsTrue(*childCopyScope == *NameScope);

			childCopyScope->Append("other") = 100;
			NameScope->Append("stuff") = 50;

			Assert::IsTrue(*childCopyScope != *NameScope);
			delete NameScope;

			Scope * Nullptr = nullptr;
			Assert::IsTrue(Nullptr == childCopyScope->GetParent());

			delete baseScope;
			delete copyScope;
			delete childCopyScope;
		}

		TEST_METHOD(ScopeMove)
		{
			Scope *baseScope = new Scope();
			baseScope->Append("other") = 100;
			Scope &HealthScope = baseScope->AppendScope("Health");
			HealthScope;
			Scope moveScope =Scope(std::move(*baseScope));
			Assert::IsTrue(moveScope != *baseScope);

			Scope *childmoveScope = new Scope();
			*childmoveScope = std::move(HealthScope);

			delete baseScope;
			delete &HealthScope;
		}

		TEST_METHOD(ScopeAdopt)
		{
			Scope baseScope;
			Scope &HealthScope = baseScope.AppendScope("Health");
			Scope *NameScope = new Scope();
			HealthScope.Adopt(*NameScope, "ChildName");
			Assert::IsTrue(HealthScope != *NameScope);
			Assert::IsTrue(*NameScope == *((HealthScope.Find("ChildName"))->Get<Scope*>(0)));

			baseScope.Append("IntegerDatum") = 100;
			auto scopeExpression = [&baseScope, &NameScope] {baseScope.Adopt(*NameScope, "IntegerDatum"); };
			Assert::ExpectException<exception>(scopeExpression);
		}

		TEST_METHOD(ScopeFindName)
		{
			Scope baseScope;
			Scope &HealthScope = baseScope.AppendScope("Health");
			Scope &NameScope = baseScope.AppendScope("Name");
			Assert::IsTrue("Health" == baseScope.FindName(HealthScope));
			HealthScope.Adopt(NameScope, "ChildName");
			Assert::IsFalse("ChildName" == baseScope.FindName(NameScope));
		}

		TEST_METHOD(ScopeOrphan)
		{
			Scope baseScope;
			Scope &PlayerScope = baseScope.AppendScope("Player");
			Scope *EnemyScope = new Scope();
			baseScope.Adopt(*EnemyScope, "Enemy");
			Scope &PowerScope = PlayerScope.AppendScope("Power");
			Scope &NameScope = PowerScope.AppendScope("Name");

			Scope *tempScope;
			NameScope.Search("Enemy", &tempScope);
			Assert::IsTrue(baseScope == *tempScope);
			
			baseScope.Orphan(*EnemyScope);
			Assert::IsTrue("" == baseScope.FindName(*EnemyScope));
			delete EnemyScope;
		}

		TEST_METHOD(ScopeRTTITest)
		{
			Scope baseScope;
			std::string scope = "Unknown Scope";
			Assert::AreEqual(scope, baseScope.ToString());
			baseScope["Health"] = 100;
			baseScope["Name"] = "Player";
			scope = "Health";
			Assert::AreEqual(scope, baseScope.ToString());

			auto scopeExpression = [&baseScope] {baseScope[20]; };
			Assert::ExpectException<exception>(scopeExpression);

		}
	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState ScopeTest::sStartMemState;
}