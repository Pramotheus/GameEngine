#include "pch.h"
#include "Event.h"
#include "EventQueue.h"
#include "EventPublisher.h"
#include "EventSubscriber.h"
#include "FooSubscriber.h"
#include "TesterClass.h"
#include "AddSubscriberTest.h"
#include "RemoveSubscriberTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{

	TEST_CLASS(AsyncEventTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			Event<TesterClass>::StrinkList();
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			Event<TesterClass>::StrinkList();
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(AsyncEventEnqueue)
		{
			uint32_t numberOfEvents = 10000;

			Event<TesterClass> event;
			GameTime tempTime;
			EventQueue eventQueue;

			Assert::IsTrue(eventQueue.IsEmpty());

			for (uint32_t i = 0; i < numberOfEvents; ++i)
			{
				eventQueue.Enqueue(make_shared<Event<TesterClass>>(event), tempTime);
			}
			
			Assert::AreEqual(numberOfEvents, eventQueue.Size());

			eventQueue.Clear();
			Assert::IsTrue(eventQueue.IsEmpty());

			Event<TesterClass>::UnSubscribeAll();
		}

		TEST_METHOD(AsyncEventSubscribe)
		{
			uint32_t numberOfSubs = 10000;

			Event<TesterClass> event;
			TesterClass& Foo = event.Message();
			GameTime tempTime;
			shared_ptr<Event<TesterClass>> eventPtr = make_shared<Event<TesterClass>>(event);

			vector<FooSubscriber> fooSub;

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				fooSub.push_back(FooSubscriber());
			}

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				event.Subscribe(fooSub[i]);
			}

			Assert::AreSame(Foo, event.Message());

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				Assert::IsFalse(fooSub[i].mNotified);
			}

			event.Deliver();

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				Assert::IsTrue(fooSub[i].mNotified);
			}

			Event<TesterClass>::UnSubscribeAll();
		}

		TEST_METHOD(AsyncEventQueueUpdate)
		{
			uint32_t numberOfEvents = 300;
			uint32_t numberOfSubs = 500;


			Event<TesterClass> event;
			GameTime tempTime;
			EventQueue eventQueue;

			vector<FooSubscriber> fooSub;

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				fooSub.push_back(FooSubscriber());
			}

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				event.Subscribe(fooSub[i]);
			}


			Assert::IsTrue(eventQueue.IsEmpty());

			for (uint32_t i = 0; i < numberOfEvents; ++i)
			{
				eventQueue.Enqueue(make_shared<Event<TesterClass>>(event), tempTime);
			}

			Assert::AreEqual(numberOfEvents, eventQueue.Size());

			eventQueue.Update(tempTime);

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				Assert::IsFalse(fooSub[i].mNotified);
			}

			chrono::steady_clock::time_point tempPoint(chrono::milliseconds(1000));
			tempTime.SetCurrentTime(tempPoint);

			eventQueue.Update(tempTime);

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				Assert::IsTrue(fooSub[i].mNotified);
			}

			Event<TesterClass>::UnSubscribeAll();
		}

		TEST_METHOD(AsyncEventAddRemoveSubscribersInThread)
		{
			uint32_t numberOfEvents = 300;
			uint32_t numberOfSubs = 100;

			Event<TesterClass> event;
			GameTime tempTime;
			EventQueue eventQueue;

			vector<FooSubscriber> fooSub;
			vector<AddSubscriberTest> addSub;
			vector<RemoveSubscriberTest> remSub;

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				fooSub.push_back(FooSubscriber());
			}
			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				addSub.push_back(AddSubscriberTest());
			}
			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				remSub.push_back(RemoveSubscriberTest());
			}

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				event.Subscribe(fooSub[i]);
				event.Subscribe(addSub[i]);
				event.Subscribe(remSub[i]);
			}

			AddSubscriberTest::mTime = tempTime;
			AddSubscriberTest::mQueue = &eventQueue;
			Assert::IsTrue(eventQueue.IsEmpty());

			for (uint32_t i = 0; i < numberOfEvents; ++i)
			{
				eventQueue.Enqueue(make_shared<Event<TesterClass>>(event), tempTime);
			}

			Assert::AreEqual(numberOfEvents, eventQueue.Size());

			eventQueue.Update(tempTime);

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				Assert::IsFalse(fooSub[i].mNotified);
				Assert::IsFalse(addSub[i].mNotified);
				Assert::IsFalse(remSub[i].mNotified);
			}

			chrono::steady_clock::time_point tempPoint(chrono::milliseconds(1000));
			tempTime.SetCurrentTime(tempPoint);

			eventQueue.Update(tempTime);

			for (uint32_t i = 0; i < numberOfSubs; ++i)
			{
				Assert::IsTrue(fooSub[i].mNotified);
				Assert::IsTrue(addSub[i].mNotified);
				Assert::IsTrue(remSub[i].mNotified);
			}

			Event<TesterClass>::UnSubscribeAll();
		}

	private:
		static _CrtMemState sStartMemState;
		Event<TesterClass> ETC;
		Event<float> EF;
		AddSubscriberTest enqueObj;
	};

	_CrtMemState AsyncEventTest::sStartMemState;
}