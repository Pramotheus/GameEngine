#pragma once
#include "EventSubscriber.h"

namespace UnitTestLibraryDesktop
{
	class FooSubscriber : public FieaGameEngine::EventSubscriber
	{
	public:
		FooSubscriber() = default;

		void Notify(FieaGameEngine::EventPublisher & publisher);

		~FooSubscriber() = default;

		bool mNotified {false};
	};
}
