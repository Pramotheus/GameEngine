#include "pch.h"
#include "FooSubscriber.h"
#include "Event.h"

using namespace UnitTestLibraryDesktop;
using namespace FieaGameEngine;

void UnitTestLibraryDesktop::FooSubscriber::Notify(FieaGameEngine::EventPublisher & publisher)
{
	if (publisher.Is(Event<TesterClass>::TypeIdClass()))
	{
		mNotified = true;
	}
}
