#include "pch.h"
#include "JsonParseMaster.h"
#include "JsonFooParseHelper.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(JsonParseTest)
	{
	public:

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(JsonParse)
		{
			JsonFooParseHelper::SharedFooData fooShared;
			TesterClass *foo = new TesterClass(0);
			fooShared.SetFoo(foo);
			JsonFooParseHelper fooHelper;
			JsonBarParseHelper barHelper;
			JsonParseMaster TestParseMaster(fooShared);
			
			TestParseMaster.AddHelper(barHelper);
			TestParseMaster.AddHelper(fooHelper);

			string jsonScript = R"({"Foo": {"Value" : 54 }})";

			TestParseMaster.Parse(jsonScript);
			TestParseMaster.RemoveHelper(fooHelper);

			Assert::AreEqual(54, foo->GetData());
			delete foo;
		}

		TEST_METHOD(JsonParseFromFile)
		{
			JsonFooParseHelper::SharedFooData fooShared;
			TesterClass *foo = new TesterClass(0);
			fooShared.SetFoo(foo);
			JsonFooParseHelper fooHelper;
			JsonParseMaster TestParseMaster(fooShared);

			TestParseMaster.AddHelper(fooHelper);

			TestParseMaster.ParseFromFile("Script/FooTest.json");
			string fileName = TestParseMaster.GetFileName();
			Assert::AreEqual(54, foo->GetData());
			delete foo;
		}

		TEST_METHOD(JsonMasterClone)
		{
			JsonFooParseHelper::SharedFooData fooShared;
			TesterClass *foo = new TesterClass(0);
			fooShared.SetFoo(foo);
			JsonFooParseHelper fooHelper;
			JsonParseMaster TestParseMaster(fooShared);
			TestParseMaster.AddHelper(fooHelper);

			JsonParseMaster *CloneParseMaster = TestParseMaster.Clone();

			Assert::IsTrue(CloneParseMaster->IsClone());
			fooShared.GetDepth();
			CloneParseMaster->ParseFromFile("Script/FooTest.json");

			Assert::AreNotEqual(54, foo->GetData());
			Assert::IsTrue(CloneParseMaster->GetSharedData()->As<JsonFooParseHelper::SharedFooData>() != nullptr);
			Assert::IsTrue(&fooShared != CloneParseMaster->GetSharedData()->As<JsonFooParseHelper::SharedFooData>());
			Assert::IsTrue(CloneParseMaster->GetSharedData()->GetJsonParseMaster() == CloneParseMaster);
			Assert::IsTrue(CloneParseMaster->GetSharedData()->GetJsonParseMaster() != &TestParseMaster);

			delete foo;
			delete CloneParseMaster;
		}

		TEST_METHOD(JsonMisc)
		{
			JsonFooParseHelper::SharedFooData fooShared;
			TesterClass *foo = new TesterClass(0);
			fooShared.SetFoo(foo);
			JsonFooParseHelper fooHelper;
			JsonParseMaster TestParseMaster(fooShared);
			TestParseMaster.AddHelper(fooHelper);

			JsonParseMaster *CloneParseMaster = TestParseMaster.Clone();

			TestParseMaster.Reset();
			auto CloneExpression = [&CloneParseMaster] {CloneParseMaster->ParseFromFile("Foo.json"); };
			Assert::ExpectException<exception>(CloneExpression);

			auto CloneRemoveExpression = [&CloneParseMaster, &fooHelper] {CloneParseMaster->RemoveHelper(fooHelper); };
			Assert::ExpectException<exception>(CloneRemoveExpression);
			auto CloneFailExpression = [&CloneParseMaster, &fooHelper] {CloneParseMaster->AddHelper(fooHelper); };
			Assert::ExpectException<exception>(CloneFailExpression);

			TestParseMaster.SetSharedData(fooShared);
			auto CloneShareExpression = [&CloneParseMaster, &fooShared] {CloneParseMaster->SetSharedData(fooShared); };
			Assert::ExpectException<exception>(CloneShareExpression);

			delete foo;
			delete CloneParseMaster;
		}

	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState JsonParseTest::sStartMemState;
}