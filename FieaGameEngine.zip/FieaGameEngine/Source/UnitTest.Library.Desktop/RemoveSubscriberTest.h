#pragma once
#include "EventSubscriber.h"

namespace UnitTestLibraryDesktop
{
	class RemoveSubscriberTest : public FieaGameEngine::EventSubscriber
	{
	public:
		RemoveSubscriberTest() = default;
		~RemoveSubscriberTest() = default;

		void Notify(FieaGameEngine::EventPublisher & publisher);

		bool mNotified{ false };
	};
}

