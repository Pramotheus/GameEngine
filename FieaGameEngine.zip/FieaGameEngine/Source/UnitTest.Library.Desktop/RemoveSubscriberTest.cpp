#include "pch.h"
#include "RemoveSubscriberTest.h"
#include "Event.h"

using namespace UnitTestLibraryDesktop;
using namespace FieaGameEngine;

void UnitTestLibraryDesktop::RemoveSubscriberTest::Notify(FieaGameEngine::EventPublisher & publisher)
{
	if (publisher.Is(Event<TesterClass>::TypeIdClass()))
	{
		mNotified = true;
		Event<TesterClass>::UnSubscribe(*this);
	}
}
