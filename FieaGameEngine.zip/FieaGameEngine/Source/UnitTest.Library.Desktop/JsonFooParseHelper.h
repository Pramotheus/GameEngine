#pragma once
#include "IJsonParseHelper.h"
#include "TesterClass.h"

namespace UnitTestLibraryDesktop
{
	class JsonFooParseHelper final : public FieaGameEngine::IJsonParseHelper
	{
	public:
		class SharedFooData final : public FieaGameEngine::JsonParseMaster::SharedData
		{
			RTTI_DECLARATIONS(SharedFooData, FieaGameEngine::JsonParseMaster::SharedData)

		public:
			friend JsonFooParseHelper;

			virtual SharedFooData* Clone();
			virtual void Initialize();
			void SetFoo(TesterClass* foo);
			TesterClass & GetFoo();

			~SharedFooData();

		private:
			TesterClass* Foo;
			bool IsClone;
		};

		JsonFooParseHelper();

		virtual void Initialize() override;

		virtual bool DataHandler(const string & value, const Json::Value & data, const FieaGameEngine::JsonParseMaster::SharedData & sharedData) override;
		virtual bool StartHandler(const string & key, const Json::Value & data, const FieaGameEngine::JsonParseMaster::SharedData & sharedData) override;
		virtual bool EndHandler(const FieaGameEngine::JsonParseMaster::SharedData & sharedData) override;

		virtual JsonFooParseHelper* Clone() override;

		virtual ~JsonFooParseHelper() = default;

	private:
		SharedFooData* mFooSharedData;
	};

	//!Bar Helper
	/*!
	*	Bar Helper is a temporary calss that does not have any declarations in it, Do not use it for testing other functions
	*	This is a dumy helper class
	*/
	class JsonBarParseHelper final : public FieaGameEngine::IJsonParseHelper
	{
		virtual void Initialize() override;

		virtual bool DataHandler(const string & value, const Json::Value & data, const FieaGameEngine::JsonParseMaster::SharedData & sharedData) override;
		virtual bool StartHandler(const string & key, const Json::Value & data, const FieaGameEngine::JsonParseMaster::SharedData & sharedData) override;
		virtual bool EndHandler(const FieaGameEngine::JsonParseMaster::SharedData & sharedData) override;

		virtual JsonFooParseHelper* Clone() override;
	};
}
