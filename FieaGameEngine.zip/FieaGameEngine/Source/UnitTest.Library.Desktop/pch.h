#pragma once

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

#include <string>
#include <stdlib.h>
#include "CppUnitTest.h"

#include "TesterClass.h"
#include "AdditionalContent.h"
