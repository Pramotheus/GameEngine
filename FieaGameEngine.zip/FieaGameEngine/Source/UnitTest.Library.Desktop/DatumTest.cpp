#include "pch.h"
#include "Datum.h"
#include "Scope.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(DatumTest)
	{
	public:
		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(DatumPushBack)
		{
			Datum intDatum;
			int a = 10;
			intDatum.PushBack(a);
			Assert::AreEqual(a, intDatum.Get<int>(0));

			float b = 10.0;
			Datum floatDatum;
			floatDatum.PushBack(b);
			Assert::AreEqual(b, floatDatum.Get<float>(0));
			auto intExpression = [&intDatum, &b] {intDatum.PushBack(b); };
			Assert::ExpectException<exception>(intExpression);
			auto floatExpression = [&floatDatum, &a] {floatDatum.PushBack(a); };
			Assert::ExpectException<exception>(floatExpression);
			Assert::IsTrue(Datum::DatumType::Float == floatDatum.Type());

			glm::vec4 vector;
			Datum vectorDatum;
			vectorDatum.PushBack(vector);
			Assert::IsTrue(vector == vectorDatum.Get<glm::vec4>(0));
			
			glm::mat4x4 matrix;
			Datum matrixDatum;
			matrixDatum.PushBack(matrix);
			Assert::IsTrue(matrix == matrixDatum.Get<glm::mat4x4>(0));

			string baseString = "bigstring";
			Datum stringDatum;
			stringDatum.PushBack(baseString);
			Assert::AreEqual(baseString, stringDatum.Get<string>(0));
			
			RTTI * newPointer = new TesterClass(10);
			Datum pointerDatum;
			pointerDatum.PushBack(newPointer);
			Assert::IsTrue(newPointer == pointerDatum.Get<RTTI *>(0));

			auto pointExpression = [&pointerDatum, &baseString] {pointerDatum.PushBack(baseString); };
			Assert::ExpectException<exception>(pointExpression);
			auto vecExpression = [&vectorDatum, &matrix] {vectorDatum.PushBack(matrix); };
			Assert::ExpectException<exception>(vecExpression);
			auto strExpression = [&stringDatum, &newPointer] {stringDatum.PushBack(newPointer); };
			Assert::ExpectException<exception>(strExpression);
			auto matExpression = [&matrixDatum, &vector] {matrixDatum.PushBack(vector); };
			Assert::ExpectException<exception>(matExpression);

			delete newPointer;
		}

		TEST_METHOD(DatumPopBack)
		{
			Datum intDatum;
			int a = 10;
			intDatum.PushBack(a);
			Assert::AreEqual(a, intDatum.Get<int>(0));
			intDatum.PopBack();
			Assert::AreEqual(0U, intDatum.Size());

			float b = 10.0;
			Datum floatDatum;
			floatDatum.PushBack(b);
			Assert::AreEqual(b, floatDatum.Get<float>(0));
			floatDatum.PopBack();
			Assert::AreEqual(0U, floatDatum.Size());

			glm::vec4 vector;
			Datum vectorDatum;
			vectorDatum.PushBack(vector);
			Assert::IsTrue(vector == vectorDatum.Get<glm::vec4>(0));
			vectorDatum.PopBack();
			Assert::AreEqual(0U, vectorDatum.Size());

			glm::mat4x4 matrix;
			Datum matrixDatum;
			matrixDatum.PushBack(matrix);
			Assert::IsTrue(matrix == matrixDatum.Get<glm::mat4x4>(0));
			matrixDatum.PopBack();
			Assert::AreEqual(0U, matrixDatum.Size());

			string baseString = "bigstring";
			Datum stringDatum;
			stringDatum.PushBack(baseString);
			Assert::AreEqual(baseString, stringDatum.Get<string>(0));
			stringDatum.PopBack();
			Assert::AreEqual(0U, stringDatum.Size());
			
			RTTI * newPointer = new TesterClass(10);
			Datum pointerDatum;
			pointerDatum.PushBack(newPointer);
			Assert::IsTrue(newPointer == pointerDatum.Get<RTTI*>(0));
			pointerDatum.PopBack();
			Assert::AreEqual(0U, pointerDatum.Size());
			delete newPointer;
		}

		TEST_METHOD(DatumSetSize)
		{
			Datum intDatum;
			int a = 10;
			intDatum.PushBack(a);
			intDatum.PushBack(a);
			Assert::AreEqual(2U, intDatum.Size());
			intDatum.SetSize(1);
			Assert::AreEqual(1U, intDatum.Size());

			float b = 10.0;
			Datum floatDatum;
			floatDatum.PushBack(b);
			floatDatum.PushBack(b);
			Assert::AreEqual(2U, floatDatum.Size());
			floatDatum.SetSize(1);
			Assert::AreEqual(1U, floatDatum.Size());

			glm::vec4 vector;
			Datum vectorDatum;
			vectorDatum.PushBack(vector);
			vectorDatum.PushBack(vector);
			Assert::AreEqual(2U, vectorDatum.Size());
			vectorDatum.SetSize(1);
			Assert::AreEqual(1U, vectorDatum.Size());

			glm::mat4x4 matrix;
			Datum matrixDatum;
			matrixDatum.PushBack(matrix);
			matrixDatum.PushBack(matrix);
			Assert::AreEqual(2U, matrixDatum.Size());
			matrixDatum.SetSize(1);
			Assert::AreEqual(1U, matrixDatum.Size());

			string baseString = "bigstring";
			Datum stringDatum;
			stringDatum.PushBack(baseString);
			stringDatum.PushBack(baseString);
			Assert::AreEqual(2U, stringDatum.Size());
			stringDatum.SetSize(1);
			Assert::AreEqual(1U, stringDatum.Size());
			
			RTTI * newPointer = new TesterClass(10);
			Datum pointerDatum;
			pointerDatum.PushBack(newPointer);
			pointerDatum.PushBack(newPointer);
			Assert::AreEqual(2U, pointerDatum.Size());
			pointerDatum.SetSize(1);
			Assert::AreEqual(1U, pointerDatum.Size());
			delete newPointer;
		}

		TEST_METHOD(DatumSetTest)
		{
			Datum intDatum;
			int a = 10, b = 20;
			auto intExpression = [&intDatum, &a] {intDatum.Set(a,2); };
			Assert::ExpectException<exception>(intExpression);
			intDatum.SetType(Datum::DatumType::Integer);
			intDatum.Reserve(2);
			intDatum.PushBack(a);
			intDatum.PushBack(a);
			auto intZeroExpression = [&intDatum, &a] {intDatum.Set(a, 10); };
			Assert::ExpectException<exception>(intZeroExpression);
			intDatum.Set(b, 1);
			Assert::AreEqual(b, intDatum.Get<int32_t>(1));
			Assert::AreEqual(2U, intDatum.Size());

			float c = 10.0, d =20.5;
			Datum floatDatum;
			auto floatExpression = [&floatDatum, &c] {floatDatum.Set(c, 2); };
			Assert::ExpectException<exception>(floatExpression);
			floatDatum.SetType(Datum::DatumType::Float);
			floatDatum.Reserve(2);
			floatDatum.PushBack(c);
			floatDatum.PushBack(c);
			Assert::ExpectException<exception>([&floatDatum, &c] {floatDatum.Set(c, 10); });
			floatDatum.Set(d, 1);
			Assert::AreEqual(d, floatDatum.Get<float>(1));
			Assert::AreEqual(2U, floatDatum.Size());

			glm::vec4 vector, otherVector;
			Datum vectorDatum;
			auto vecExpression = [&vectorDatum, &vector] {vectorDatum.Set(vector, 2); };
			Assert::ExpectException<exception>(vecExpression);
			vectorDatum.SetType(Datum::DatumType::Vector);
			vectorDatum.Reserve(2);
			vectorDatum.PushBack(vector);
			vectorDatum.PushBack(vector);
			Assert::ExpectException<exception>([&vectorDatum, &vector] {vectorDatum.Set(vector, 10); });
			vectorDatum.Set(otherVector, 1);
			Assert::IsTrue(otherVector == vectorDatum.Get<glm::vec4>(1));
			Assert::AreEqual(2U, vectorDatum.Size());

			glm::mat4x4 matrix, otherMatrix;
			Datum matrixDatum;
			auto matExpression = [&matrixDatum, &matrix] {matrixDatum.Set(matrix, 2); };
			Assert::ExpectException<exception>(matExpression);
			matrixDatum.SetType(Datum::DatumType::Matrix);
			matrixDatum.Reserve(2);
			matrixDatum.PushBack(matrix);
			matrixDatum.PushBack(matrix);
			Assert::ExpectException<exception>([&matrixDatum, &matrix] {matrixDatum.Set(matrix, 10); });
			matrixDatum.Set(otherMatrix, 1);
			Assert::IsTrue(otherMatrix == matrixDatum.Get<glm::mat4x4>(1));
			Assert::AreEqual(2U, matrixDatum.Size());

			string baseString = "bigstring", otherString = "notsmallstr";
			Datum stringDatum;
			auto strExpression = [&stringDatum, &baseString] {stringDatum.Set(baseString, 2); };
			Assert::ExpectException<exception>(strExpression);
			stringDatum.SetType(Datum::DatumType::String);
			stringDatum.Reserve(2);
			stringDatum.PushBack(baseString);
			stringDatum.PushBack(baseString);
			Assert::ExpectException<exception>([&stringDatum, &baseString] {stringDatum.Set(baseString, 10); });
			stringDatum.Set(otherString, 1);
			Assert::AreEqual(otherString, stringDatum.Get<string>(1));
			Assert::AreEqual(2U, stringDatum.Size());

			Scope * newScopePointer = new Scope(10);
			Scope * otherScopePointer = new Scope(20);
			Datum ScopeDatum;
			auto ScopeExpression = [&ScopeDatum, &newScopePointer] {ScopeDatum.Set(newScopePointer, 2); };
			Assert::ExpectException<exception>(ScopeExpression);
			ScopeDatum.SetType(Datum::DatumType::Table);
			ScopeDatum.Reserve(2);
			ScopeDatum.PushBack(newScopePointer);
			ScopeDatum.PushBack(newScopePointer);
			Assert::ExpectException<exception>([&ScopeDatum, &newScopePointer] {ScopeDatum.Set(newScopePointer, 10); });
			ScopeDatum.Set(otherScopePointer, 1);
			Assert::IsTrue(otherScopePointer == ScopeDatum.Get<Scope*>(1));
			Assert::AreEqual(2U, ScopeDatum.Size());

			RTTI * newPointer = new TesterClass(10);
			RTTI * otherPointer = new TesterClass(20);
			Datum pointerDatum;
			auto pointExpression = [&pointerDatum, &newPointer] {pointerDatum.Set(newPointer, 2); };
			Assert::ExpectException<exception>(pointExpression);
			pointerDatum.SetType(Datum::DatumType::Pointer);
			pointerDatum.Reserve(2);
			pointerDatum.PushBack(newPointer);
			pointerDatum.PushBack(newPointer);
			Assert::ExpectException<exception>([&pointerDatum, &newPointer] {pointerDatum.Set(newPointer, 10); });
			pointerDatum.Set(otherPointer, 1);
			Assert::IsTrue(otherPointer == pointerDatum.Get<RTTI*>(1));
			Assert::AreEqual(2U, pointerDatum.Size());

			auto intnewExpression = [&intDatum, &c] {intDatum.Set(c); };
			Assert::ExpectException<exception>(intnewExpression);
			auto floatnewExpression = [&floatDatum, &a] {floatDatum.Set(a); };
			Assert::ExpectException<exception>(floatnewExpression);
			auto pointnewExpression = [&pointerDatum, &baseString] {pointerDatum.Set(baseString); };
			Assert::ExpectException<exception>(pointnewExpression);
			auto vecnewExpression = [&vectorDatum, &matrix] {vectorDatum.Set(matrix); };
			Assert::ExpectException<exception>(vecnewExpression);
			auto strnewExpression = [&stringDatum, &newPointer] {stringDatum.Set(newPointer); };
			Assert::ExpectException<exception>(strnewExpression);
			auto matnewExpression = [&matrixDatum, &vector] {matrixDatum.Set(vector); };
			Assert::ExpectException<exception>(matnewExpression);
			auto scopenewExpression = [&matrixDatum, &otherScopePointer] {matrixDatum.Set(otherScopePointer); };
			Assert::ExpectException<exception>(scopenewExpression);

			delete newPointer;
			delete otherPointer;
			delete newScopePointer;
			delete otherScopePointer;
		}

		TEST_METHOD(DatumGetTest)
		{
			Datum intDatum;
			int a = 10;
			intDatum.PushBack(a);
			Assert::AreEqual(a, intDatum.Get<int>(0));
			auto intExpression = [&intDatum] {intDatum.Get<int>(2); };
			Assert::ExpectException<exception>(intExpression);

			float b = 10.0;
			Datum floatDatum;
			floatDatum.PushBack(b);
			Assert::AreEqual(b, floatDatum.Get<float>(0));
			auto floatExpression = [&floatDatum] {floatDatum.Get<float>(2); };
			Assert::ExpectException<exception>(floatExpression);

			glm::vec4 vector;
			Datum vectorDatum;
			vectorDatum.PushBack(vector);
			Assert::IsTrue(vector == vectorDatum.Get<glm::vec4>(0));
			auto vecExpression = [&vectorDatum] {vectorDatum.Get<glm::vec4>(2); };
			Assert::ExpectException<exception>(vecExpression);

			glm::mat4x4 matrix;
			Datum matrixDatum;
			matrixDatum.PushBack(matrix);
			Assert::IsTrue(matrix == matrixDatum.Get<glm::mat4x4>(0));
			auto matExpression = [&matrixDatum] {matrixDatum.Get<glm::mat4x4>(2); };
			Assert::ExpectException<exception>(matExpression);

			string baseString = "bigstring";
			Datum stringDatum;
			stringDatum.PushBack(baseString);
			Assert::AreEqual(baseString, stringDatum.Get<string>(0));
			auto strExpression = [&stringDatum] {stringDatum.Get<string>(2); };
			Assert::ExpectException<exception>(strExpression);

			RTTI * newPointer = new TesterClass(10);
			Datum pointerDatum;
			pointerDatum.PushBack(newPointer);
			Assert::IsTrue(newPointer == pointerDatum.Get<RTTI *>(0));
			auto pointExpression = [&pointerDatum] {pointerDatum.Get<RTTI *>(2); };
			Assert::ExpectException<exception>(pointExpression);
			delete newPointer;
		}

		TEST_METHOD(DatumEqualityAndInequality)
		{
			int a = 10, c =20;
			Datum intDatum(a);
			intDatum.PushBack(a);
			Datum copyIntDatum(a);
			Assert::IsFalse(copyIntDatum == intDatum);
			copyIntDatum.PushBack(c);
			Assert::IsTrue(copyIntDatum != intDatum);
			copyIntDatum = (intDatum);
			Assert::IsTrue(copyIntDatum == intDatum);

			float b = 10.0, d =20;
			Datum floatDatum(b);
			floatDatum.PushBack(b);
			Datum copyfloatDatum(b);
			Assert::IsFalse(copyfloatDatum == floatDatum);
			copyfloatDatum.PushBack(d);
			Assert::IsTrue(copyfloatDatum != floatDatum);
			copyfloatDatum = floatDatum;
			Assert::IsTrue(copyfloatDatum == floatDatum);

			glm::vec4 vector(5), otherVec;
			Datum vectorDatum(vector);
			vectorDatum.PushBack(vector);
			Datum copyvectorDatum(vector);
			Assert::IsFalse(copyvectorDatum == vectorDatum);
			copyvectorDatum.PushBack(otherVec);
			Assert::IsTrue(copyvectorDatum != vectorDatum);
			copyvectorDatum = vectorDatum;
			Assert::IsTrue(copyvectorDatum == vectorDatum);

			glm::mat4x4 matrix(10), othermatrix;
			Datum matrixDatum(matrix);
			matrixDatum.PushBack(matrix);
			Datum copymatrixDatum(matrix);
			Assert::IsFalse(copymatrixDatum == matrixDatum);
			copymatrixDatum.PushBack(othermatrix);
			Assert::IsTrue(copymatrixDatum != matrixDatum);
			copymatrixDatum = matrixDatum;
			Assert::IsTrue(copymatrixDatum == matrixDatum);

			string baseString = "bigstring", otherStr;
			Datum stringDatum(baseString);
			stringDatum.PushBack(baseString);
			Datum copystringDatum(baseString);
			Assert::IsFalse(copystringDatum == stringDatum);
			copystringDatum.PushBack(otherStr);
			Assert::IsTrue(copystringDatum != stringDatum);
			copystringDatum = stringDatum;
			Assert::IsTrue(copystringDatum == stringDatum);

			RTTI * newPointer = new TesterClass(10);
			RTTI * otherPtr = new TesterClass(20);
			Datum pointerDatum(newPointer);
			pointerDatum.PushBack(newPointer);
			Datum copypointerDatum(newPointer);
			Assert::IsFalse(copypointerDatum == pointerDatum);
			copypointerDatum.PushBack(otherPtr);
			Assert::IsTrue(copypointerDatum != pointerDatum);
			copypointerDatum = pointerDatum;
			Assert::IsTrue(copypointerDatum == pointerDatum);
			delete newPointer;
			delete otherPtr;
		}

		TEST_METHOD(DatumGetFromAndSetToString)
		{
			Datum intDatum;
			int a = 10, d= 50;
			intDatum.PushBack(a);
			intDatum.PushBack(d);
			intDatum.SetFromString(intDatum.ToString(0), 1);
			Assert::AreEqual(a, intDatum.Get<int>(1));
			Assert::AreEqual(2U, intDatum.Size());

			float b = 10.0, c= 20.25;
			Datum floatDatum;
			floatDatum.PushBack(b);
			floatDatum.PushBack(c);
			floatDatum.SetFromString(floatDatum.ToString(0), 1);
			Assert::AreEqual(b, floatDatum.Get<float>(0));
			Assert::AreEqual(2U, floatDatum.Size());

			glm::vec4 vector , otherVec;
			Datum vectorDatum;
			vectorDatum.PushBack(vector);
			vectorDatum.PushBack(otherVec);
			vectorDatum.SetFromString(vectorDatum.ToString(0), 1);
			Assert::IsTrue(vector == vectorDatum.Get<glm::vec4>(0));
			Assert::AreEqual(2U, vectorDatum.Size());

			glm::mat4x4 matrix , otherMat;
			Datum matrixDatum;
			matrixDatum.PushBack(matrix);
			matrixDatum.PushBack(otherMat);
			matrixDatum.SetFromString(matrixDatum.ToString(0), 1);
			Assert::IsTrue(matrix == matrixDatum.Get<glm::mat4x4>(0));
			Assert::AreEqual(2U, matrixDatum.Size());

			string baseString = "bigstring", otherStr;
			Datum stringDatum;
			stringDatum.PushBack(baseString);
			stringDatum.PushBack(otherStr);
			stringDatum.SetFromString(stringDatum.ToString(0), 1);
			Assert::AreEqual(baseString, stringDatum.Get<string>(0));
			Assert::AreEqual(2U, stringDatum.Size());

			RTTI * newPointer = new TesterClass(10);
			RTTI * otherPointer = new TesterClass(20);
			Datum pointerDatum;
			pointerDatum.PushBack(newPointer);
			Assert::IsTrue(newPointer->ToString() == pointerDatum.ToString(0));
			Assert::IsFalse(newPointer->Is(10));
			Assert::IsFalse(newPointer->Is("TesrterClass"));
			Assert::IsFalse(newPointer->Equals(otherPointer));

			Datum RandomDatum;
			auto firstExpression = [&RandomDatum] {RandomDatum.SetFromString("HelloWorld"); };
			Assert::ExpectException<exception>(firstExpression);
			auto secondExpression = [&RandomDatum] {RandomDatum.ToString(); };
			Assert::ExpectException<exception>(secondExpression);

			delete newPointer;
			delete otherPointer;
		}

		TEST_METHOD(DatumAssignmentInternall)
		{
			int a = 10;
			Datum intDatum(a);
			intDatum.PushBack(a);
			Datum copyIntDatum(intDatum);
			Assert::IsTrue(copyIntDatum == intDatum);
			Assert::AreEqual(intDatum.Size(), copyIntDatum.Size());

			float b = 10.0;
			Datum floatDatum(b);
			floatDatum.PushBack(b);
			Datum copyfloatDatum(floatDatum);
			Assert::IsTrue(copyfloatDatum == floatDatum);
			Assert::AreEqual(floatDatum.Size(), copyfloatDatum.Size());

			glm::vec4 vector;
			Datum vectorDatum(vector);
			vectorDatum.PushBack(vector);
			Datum copyvectorDatum(vectorDatum);
			Assert::IsTrue(copyvectorDatum == vectorDatum);
			Assert::AreEqual(vectorDatum.Size(), copyvectorDatum.Size());

			glm::mat4x4 matrix;
			Datum matrixDatum(matrix);
			matrixDatum.PushBack(matrix);
			Datum copymatrixDatum(matrixDatum);
			Assert::IsTrue(copymatrixDatum == matrixDatum);
			Assert::AreEqual(matrixDatum.Size(), matrixDatum.Size());

			string baseString = "bigstring";
			Datum stringDatum(baseString);
			stringDatum.PushBack(baseString);
			Datum copystringDatum(stringDatum);
			Assert::IsTrue(copystringDatum == stringDatum);
			Assert::AreEqual(stringDatum.Size(), copystringDatum.Size());

			RTTI * newPointer = new TesterClass(10);
			Datum pointerDatum(newPointer);
			pointerDatum.PushBack(newPointer);
			Datum copypointerDatum(pointerDatum);
			Assert::IsTrue(copypointerDatum == pointerDatum);
			Assert::AreEqual(pointerDatum.Size(), copypointerDatum.Size());
			delete newPointer;
		}

		TEST_METHOD(DatumAssignmentExternal)
		{

			Datum intDatum, newIntDat;
			int32_t a = 10, b[] = { 20, 30, 40 };
			newIntDat.SetStorage(b, 3);
			intDatum.PushBack(a);
			intDatum.SetStorage(b,3);
			Assert::AreEqual(b[2], intDatum.Get<int32_t>(2));
			auto intfirstExpression = [&intDatum, &a] {intDatum.PushBack(a); };
			Assert::ExpectException<exception>(intfirstExpression);
			//auto intSecondExpression = [&intDatum] {intDatum.SetSize(2); };
			//Assert::ExpectException<exception>(intSecondExpression);
			auto intThirdExpression = [&intDatum] {intDatum.Reserve(20); };
			Assert::ExpectException<exception>(intThirdExpression);
			auto intZeroExpression = [&intDatum] {intDatum.PopBack(); };
			Assert::ExpectException<exception>(intZeroExpression);
			Datum copyDatum;
			copyDatum = intDatum;

			float c = 10.0f, d[] = { 20.5f, 34.876f };
			Datum floatDatum, newFloatDat;
			newFloatDat.SetStorage(d, 2);
			floatDatum.PushBack(c);
			floatDatum.SetStorage(d, 2);
			Assert::AreEqual(d[1], floatDatum.Get<float>(1));
			auto floatfirstExpression = [&floatDatum, &c] {floatDatum.PushBack(c); };
			Assert::ExpectException<exception>(floatfirstExpression);
			//auto floatSecondExpression = [&floatDatum] {floatDatum.SetSize(2); };
			//Assert::ExpectException<exception>(floatSecondExpression);
			auto floatThirdExpression = [&floatDatum] {floatDatum.Reserve(20); };
			Assert::ExpectException<exception>(floatThirdExpression);

			glm::vec4 vector, otherVector, newVector[] = {vector, otherVector};
			Datum vectorDatum, newVectorDat;
			newVectorDat.SetStorage(newVector, 2);
			vectorDatum.PushBack(vector);
			vectorDatum.SetStorage(newVector, 2);
			Assert::IsTrue(newVector[1] == vectorDatum.Get<glm::vec4>(1));
			auto vectorfirstExpression = [&vectorDatum, &vector] {vectorDatum.PushBack(vector); };
			Assert::ExpectException<exception>(vectorfirstExpression);
			//auto vectorSecondExpression = [&vectorDatum] {vectorDatum.SetSize(2); };
			//Assert::ExpectException<exception>(vectorSecondExpression);
			auto vectorThirdExpression = [&vectorDatum] {vectorDatum.Reserve(20); };
			Assert::ExpectException<exception>(vectorThirdExpression);

			glm::mat4x4 matrix, otherMatrix, arrayMatrix[] = {matrix, otherMatrix};
			Datum matrixDatum, newMatrixDat;
			newMatrixDat.SetStorage(arrayMatrix, 2);
			matrixDatum.PushBack(matrix);
			matrixDatum.SetStorage(arrayMatrix, 2);
			Assert::IsTrue(arrayMatrix[1] == matrixDatum.Get<glm::mat4x4>(1));
			auto matrixfirstExpression = [&matrixDatum, &matrix] {matrixDatum.PushBack(matrix); };
			Assert::ExpectException<exception>(matrixfirstExpression);
			//auto matrixSecondExpression = [&matrixDatum] {matrixDatum.SetSize(2); };
			//Assert::ExpectException<exception>(matrixSecondExpression);
			auto matrixThirdExpression = [&matrixDatum] {matrixDatum.Reserve(20); };
			Assert::ExpectException<exception>(matrixThirdExpression);

			string baseString = "bigstring", otherString = "notsmallstr";
			string arrayStr[] = { baseString, otherString };
			Datum stringDatum, newStrDat;
			newStrDat.SetStorage(arrayStr, 2);
			stringDatum.PushBack(baseString);
			stringDatum.SetStorage(arrayStr, 2);
			Assert::AreEqual(arrayStr[1], stringDatum.Get<string>(1));
			auto stringfirstExpression = [&stringDatum, &baseString] {stringDatum.PushBack(baseString); };
			Assert::ExpectException<exception>(stringfirstExpression);
			//auto stringSecondExpression = [&stringDatum] {stringDatum.SetSize(2); };
			//Assert::ExpectException<exception>(stringSecondExpression);
			auto stringThirdExpression = [&stringDatum] {stringDatum.Reserve(20); };
			Assert::ExpectException<exception>(stringThirdExpression);

			RTTI * newPointer = new TesterClass(10);
			RTTI * otherPointer = new TesterClass(20);
			RTTI * ArrayPointer[] = { newPointer, otherPointer };
			Datum pointerDatum, newPtrDat;
			newPtrDat.SetStorage(ArrayPointer, 2);
			pointerDatum.PushBack(newPointer);
			pointerDatum.SetStorage(ArrayPointer, 2);
			Assert::IsTrue(ArrayPointer[1] == pointerDatum.Get<RTTI*>(1));
			auto pointerfirstExpression = [&pointerDatum, &newPointer] {pointerDatum.PushBack(newPointer); };
			Assert::ExpectException<exception>(pointerfirstExpression);
			//auto pointerSecondExpression = [&pointerDatum] {pointerDatum.SetSize(2); };
			//Assert::ExpectException<exception>(pointerSecondExpression);
			auto pointerThirdExpression = [&pointerDatum] {pointerDatum.Reserve(20); };
			Assert::ExpectException<exception>(pointerThirdExpression);

			auto intExpression = [&intDatum, &d] {intDatum.SetStorage(d, 2); };
			Assert::ExpectException<exception>(intExpression);
			auto floatExpression = [&floatDatum, &b] {floatDatum.SetStorage(b, 3); };
			Assert::ExpectException<exception>(floatExpression);
			auto pointExpression = [&pointerDatum, &arrayStr] {pointerDatum.SetStorage(arrayStr, 2); };
			Assert::ExpectException<exception>(pointExpression);
			auto vecExpression = [&vectorDatum, &arrayMatrix] {vectorDatum.SetStorage(arrayMatrix, 2); };
			Assert::ExpectException<exception>(vecExpression);
			auto strExpression = [&stringDatum, &ArrayPointer] {stringDatum.SetStorage(ArrayPointer, 2); };
			Assert::ExpectException<exception>(strExpression);
			auto matExpression = [&matrixDatum, &newVector] {matrixDatum.SetStorage(newVector, 2); };
			Assert::ExpectException<exception>(matExpression);

			delete newPointer;
			delete otherPointer;
		}

		TEST_METHOD(DatumBaseChecks)
		{
			Datum intDatum, moveIntDatum;
			int a = 10;
			auto intExpression = [&intDatum] {intDatum.Reserve(2); };
			Assert::ExpectException<exception>(intExpression);
			
			intDatum.PushBack(a);
			intDatum.PushBack(a);

			auto intFirstExpression = [&intDatum] {intDatum.SetType(Datum::DatumType::Float); };
			Assert::ExpectException<exception>(intFirstExpression);

			moveIntDatum = std::move(intDatum);
			Assert::AreEqual(a, moveIntDatum.Get<int>(0));
			Assert::AreEqual(0u, intDatum.Size());
			Assert::IsTrue(moveIntDatum != intDatum);

			Datum moveConstructor = std::move(moveIntDatum);
			Assert::AreEqual(a, moveConstructor.Get<int>(0));
			Assert::AreEqual(0u, moveIntDatum.Size());
			Assert::IsTrue(moveConstructor != moveIntDatum);
			
		}

		TEST_METHOD(DatumScalarEqualityAndInequality)
		{
			int a = 10, c = 20;
			Datum intDatum;
			Assert::IsFalse(intDatum == a);
			intDatum = a;
			intDatum.PushBack(a);
			Assert::IsTrue(intDatum != c);
			intDatum = c;
			Assert::IsTrue(intDatum == c);

			float b = 10.0, d = 20;
			Datum floatDatum;
			Assert::IsFalse(floatDatum == b);
			floatDatum = b;
			floatDatum.PushBack(b);
			Assert::IsTrue(floatDatum != d);
			floatDatum = d;
			Assert::IsTrue(floatDatum == d);

			glm::vec4 vector(5), otherVec;
			Datum vectorDatum;
			Assert::IsFalse(vectorDatum == vector);
			vectorDatum = vector;
			vectorDatum.PushBack(vector);
			Assert::IsTrue(vectorDatum != otherVec);
			vectorDatum = otherVec;
			Assert::IsTrue(vectorDatum == otherVec);

			glm::mat4x4 matrix(10), othermatrix;
			Datum matrixDatum;
			Assert::IsFalse(matrixDatum == matrix);
			matrixDatum = matrix;
			matrixDatum.PushBack(matrix);
			Assert::IsTrue(matrixDatum != othermatrix);
			matrixDatum = othermatrix;
			Assert::IsTrue(matrixDatum == othermatrix);

			string baseString = "bigstring", otherStr;
			Datum stringDatum;
			Assert::IsFalse(stringDatum == baseString);
			stringDatum = baseString;
			stringDatum.PushBack(baseString);
			Assert::IsTrue(stringDatum != otherStr);
			stringDatum = otherStr;
			Assert::IsTrue(stringDatum == otherStr);

			RTTI * newPointer = new TesterClass(10);
			RTTI * otherPtr = new TesterClass(20);
			Datum pointerDatum;
			Assert::IsFalse(pointerDatum == newPointer);
			pointerDatum = newPointer;
			pointerDatum.PushBack(newPointer);
			Assert::IsTrue(pointerDatum != otherPtr);
			pointerDatum = otherPtr;
			Assert::IsTrue(pointerDatum == otherPtr);

			auto intExpression = [&intDatum, &b] {intDatum = b; };
			Assert::ExpectException<exception>(intExpression);
			auto floatExpression = [&floatDatum, &a] {floatDatum = a; };
			Assert::ExpectException<exception>(floatExpression);
			auto pointExpression = [&pointerDatum, &baseString] {pointerDatum= (baseString); };
			Assert::ExpectException<exception>(pointExpression);
			auto vecExpression = [&vectorDatum, &matrix] {vectorDatum=(matrix); };
			Assert::ExpectException<exception>(vecExpression);
			auto strExpression = [&stringDatum, &newPointer] {stringDatum=(newPointer); };
			Assert::ExpectException<exception>(strExpression);
			auto matExpression = [&matrixDatum, &vector] {matrixDatum=(vector); };
			Assert::ExpectException<exception>(matExpression);

			delete newPointer;
			delete otherPtr;
		}
	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState DatumTest::sStartMemState;
}