#include "pch.h"
#include "AttributedFoo.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace FieaGameEngine;
using namespace std;

namespace UnitTestLibraryDesktop
{
	TEST_CLASS(AttributedTest)
	{
	public:

		AttributedFoo Foo;

		TEST_METHOD_INITIALIZE(Initialize)
		{
#ifdef _DEBUG
			_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
			_CrtMemCheckpoint(&sStartMemState);
#endif
		}

		TEST_METHOD_CLEANUP(Cleanup)
		{
#ifdef _DEBUG
			_CrtMemState endMemState, diffMemState;
			_CrtMemCheckpoint(&endMemState);
			if (_CrtMemDifference(&diffMemState, &sStartMemState, &endMemState))
			{
				_CrtMemDumpStatistics(&diffMemState);
				Assert::Fail(L"Memory Leaks!");
			}
#endif
		}

		TEST_METHOD(AttributedInitialisation)
		{
			AttributedFoo Foo1;
			Assert::AreEqual(10, (Foo1.Find("InternalInt"))->Get<int32_t>(0));
			Assert::IsTrue(Foo1.mOtherVector == (Foo1.Find("InternalVector"))->Get<glm::vec4>(0));
			Assert::AreEqual(Foo1.mOtherString, (Foo1.Find("ExternalStr"))->Get<string>(1));
			Assert::IsTrue(Foo1.mMatrix == (Foo1.Find("Externalmatrix"))->Get<glm::mat4x4>(0));
			Assert::IsFalse(Foo1.IsAuxiliaryAttributed("ExternalPtr"));
			Assert::IsTrue(Foo1.IsPrescribedAttribute("ExternalStr"));
		}

		TEST_METHOD(AttributedAuxilaryTest)
		{
			AttributedFoo Foo1;
			Foo1.AppendAuxiliaryAttribute("AuxilaryInt") = 50;
			Assert::AreEqual(50, (Foo1.Find("AuxilaryInt"))->Get<int32_t>(0));
			Scope *S1 = new Scope();
			Foo1.AppendAuxiliaryAttribute("AuxilaryScope") = S1;
			Assert::IsTrue(S1 == (Foo1.Find("AuxilaryScope"))->Get<Scope*>(0));
			Assert::IsTrue(Foo1.IsAttribute("AuxilaryInt"));
			Assert::IsTrue(Foo1.IsAuxiliaryAttributed("AuxilaryInt"));
			auto Expression = [&Foo1] {Foo1.AppendAuxiliaryAttribute("ExternalStr"); };
			Assert::ExpectException<exception>(Expression);
		}

		TEST_METHOD(AttributedGetVector)
		{
			AttributedFoo Foo1;
			Foo1.AppendAuxiliaryAttribute("AuxilaryInt") = 50;
			Scope *S1 = new Scope();
			Foo1.AppendAuxiliaryAttribute("AuxilaryScope") = S1;

			Vector<std::pair<std::string, Datum>*> Attributes = Foo1.GetAttributes();
			Vector<std::pair<std::string, Datum>*> PrescribedAttributes = Foo1.GetPrescribedAttributes();
			Vector<std::pair<std::string, Datum>*> AuxiliaryAttributes = Foo1.GetAuxiliaryAttributes();

			Assert::AreEqual(AuxiliaryAttributes.Size() + PrescribedAttributes.Size(), Attributes.Size());
			Assert::AreEqual(17U, Attributes.Size());
			Assert::AreEqual(2U, AuxiliaryAttributes.Size());
			Assert::AreEqual(15U, PrescribedAttributes.Size());
		}

		TEST_METHOD(AttributedRTTI)
		{
			RTTI* X = new TesterClass(15);
			RTTI* Y = X;
			AttributedFoo *Foo1 = new AttributedFoo();
			uint64_t a = 1645316856;
			Foo1->RTTI::QueryInterface(a);
			Foo1->TestHelper();
			X->As<Attributed>();
			delete Foo1;
			delete Y;
		}

		TEST_METHOD(AttributedCopyAndMove)
		{
			AttributedFoo Foo1;
			Foo1.AppendAuxiliaryAttribute("AuxilaryInt") = 50;
			Scope *S1 = new Scope();
			Foo1.AppendAuxiliaryAttribute("AuxilaryScope") = S1;

			AttributedFoo Foo2;
			Foo2 = Foo1;
			Foo2.mInt = 3;
			Assert::AreEqual(3, (Foo2.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreNotEqual(Foo1.mInt, (Foo2.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreSame(Foo2.mInt, (Foo2.Find("ExternalInt"))->Get<int32_t>(0));

			AttributedFoo Foo3(Foo1);
			Foo3.mInt = 5;
			Assert::AreEqual(5, (Foo3.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreNotEqual(Foo1.mInt, (Foo3.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreSame(Foo3.mInt, (Foo3.Find("ExternalInt"))->Get<int32_t>(0));
			
			AttributedFoo Foo4(std::move(Foo1));
			Foo4.mInt = 8;
			Assert::AreEqual(8, (Foo4.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreNotEqual(Foo1.mInt, (Foo4.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreSame(Foo4.mInt, (Foo4.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::IsFalse(Foo4 == Foo1);

			AttributedFoo Foo5;
			Foo5 = std::move(Foo2);
			Foo5.mInt = 5;
			Assert::AreEqual(5, (Foo5.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreNotEqual(Foo2.mInt, (Foo5.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::AreSame(Foo5.mInt, (Foo5.Find("ExternalInt"))->Get<int32_t>(0));
			Assert::IsFalse(Foo5 == Foo2);
		}

	private:
		static _CrtMemState sStartMemState;
	};

	_CrtMemState AttributedTest::sStartMemState;
}