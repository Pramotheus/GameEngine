#pragma once

namespace FieaGameEngine
{
	class Renderer
	{
	public:
		Renderer();

		IDXGISwapChain *swapChain;				//swap chain interface pointer
		ID3D11Device *dev;						//device pointer
		ID3D11DeviceContext *devcon;			//device context pointer
		ID3D11RenderTargetView *backBuffer;		//render target pointer
		
		void InitD3D(HWND hWnd);
		void CleanD3D(void);
		void RenderFrame(void);

		~Renderer();
	};
}

