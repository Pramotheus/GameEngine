#pragma once

//windows headers
#include <windows.h>
#include <windowsx.h>

//DirectX headers
#include <d3d11.h>

