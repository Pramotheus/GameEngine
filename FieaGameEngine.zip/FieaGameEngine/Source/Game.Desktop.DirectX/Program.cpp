// Game.Desktop.DirectX.cpp : Defines the entry point for the console application.
//

#include "pch.h"
#include "Renderer.h"
#include "SList.h"

using namespace std;
using namespace FieaGameEngine;

LRESULT CALLBACK WindowProc(HWND hWnd,
	UINT message,
	WPARAM wParam,
	LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	SList<int> SListObject;

	Renderer D3DObject;

	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);
	
	HWND hWnd;						//window handle
	WNDCLASSEX wc;					//window info struct

	ZeroMemory(&wc, sizeof(WNDCLASSEX));

	//struct values
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WindowProc;
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)COLOR_WINDOW;
	wc.lpszClassName = L"GameWindow";

	RegisterClassEx(&wc);

	hWnd = CreateWindowEx(NULL, L"GameWindow", L"Game Window", WS_OVERLAPPEDWINDOW, 100, 100, 800, 600, nullptr, nullptr, hInstance, nullptr);

	ShowWindow(hWnd, nCmdShow);

	D3DObject.InitD3D(hWnd);

	MSG msg;						//message structure

	while (true)
	{
		if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);

			DispatchMessage(&msg);

			if (msg.message == WM_QUIT)
			{
				break;
			}
		}

		D3DObject.RenderFrame();
	}

	D3DObject.CleanD3D();

	return 0;
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT message, WPARAM wparam, LPARAM lParam)
{
	switch (message)
	{
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 0;
	} break;

	default:
		return DefWindowProc(hWnd, message, wparam, lParam);
		break;
	}
}