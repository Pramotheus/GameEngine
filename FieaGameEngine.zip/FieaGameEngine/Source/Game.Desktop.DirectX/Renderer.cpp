#include "pch.h"
#include "Renderer.h"

namespace FieaGameEngine
{
	void Renderer::InitD3D(HWND hWnd)
	{
		DXGI_SWAP_CHAIN_DESC scd;						//swap chain description

		ZeroMemory(&scd, sizeof(DXGI_SWAP_CHAIN_DESC));

		scd.BufferCount = 1;
		scd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		scd.OutputWindow = hWnd;
		scd.SampleDesc.Count = 4;
		scd.Windowed = TRUE;

		D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, NULL, nullptr, NULL, D3D11_SDK_VERSION, &scd, &swapChain, &dev, nullptr, &devcon);

		ID3D11Texture2D *pBackBuffer;
		swapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
		dev->CreateRenderTargetView(pBackBuffer, nullptr, &backBuffer);
		pBackBuffer->Release();
		devcon->OMSetRenderTargets(1, &backBuffer, nullptr);

		D3D11_VIEWPORT viewport;
		ZeroMemory(&viewport, sizeof(D3D11_VIEWPORT));

		viewport.TopLeftX = 0;
		viewport.TopLeftY = 0;
		viewport.Width = 800;
		viewport.Height = 600;

		devcon->RSSetViewports(1, &viewport);
	}

	void Renderer::CleanD3D(void)
	{
		swapChain->Release();
		backBuffer->Release();
		dev->Release();
		devcon->Release();
	}

	void Renderer::RenderFrame(void)
	{
		float color[4] = { 0.0f, 0.4f, 0.2f, 1.0f };
		devcon->ClearRenderTargetView(backBuffer, color);
		swapChain->Present(0, 0);
	}

	Renderer::Renderer()
	{
	}

	Renderer::~Renderer()
	{
	}
}